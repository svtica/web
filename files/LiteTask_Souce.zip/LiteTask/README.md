# LiteTask

LiteTask is a lightweight task scheduling application for Windows that provides a flexible and secure alternative to Windows Task Scheduler.

## Features

- **Multiple Task Types**
  - PowerShell scripts with module support
  - Batch files
  - SQL scripts
  - Remote execution
  - Executable files

- **Action System**
  - Multiple actions per task
  - Action dependencies and ordering
  - Retry mechanisms with configurable delays
  - Error handling and continuation options
  - Parallel execution support
  - Action-level elevation control

- **Advanced Scheduling**
  - One-time execution
  - Interval-based scheduling
  - Daily scheduling with multiple time slots
  - Task chaining

- **Security**
  - Secure credential management
  - Windows authentication
  - SQL authentication
  - Service account support
  - Elevation control

- **PowerShell Integration**
  - Built-in module management
  - Isolated module environment
  - Support for popular modules (Azure, AWS, VMware, etc.)
  - Remote execution support

- **Remote Execution**
  - SecureChannel implementation
  - PowerShell remoting
  - CredSSP support
  - OSQL remote execution

- **Tool Management**
  - Automatic tool detection
  - Built-in updating system
  - Process monitoring
  - Diagnostic utilities

## Installation

1. Download the latest release from the releases page
2. Extract the files to your desired location
3. Run LiteTask.exe
4. Optional: Install as a Windows service using `LiteTask.exe -register`

## Configuration

1. **First Launch**
   - The application will create necessary directories
   - Initial configuration will be generated
   - Default logging will be enabled

2. **Tool Setup**
   - Go to Tools > Check Tools to verify required utilities
   - Use Tools > Update Tools to download missing components

3. **PowerShell Module Setup**
   - Go to Tools > Install PowerShell Modules
   - Select desired modules from the list
   - Modules will be installed to LiteTaskData\Modules

4. **Credential Management**
   - Open File > Credential Manager
   - Add necessary credentials for task execution

## Managing Tasks and Actions

1. **Creating Tasks**
   - Click "Create Task" button
   - Configure basic task settings
   - Add one or more actions
   - Set scheduling options
   - Save task

2. **Managing Actions**
   - Define multiple actions within tasks
   - Set dependencies between actions
   - Configure retry and timeout settings
   - Enable/disable elevation per action
   - Arrange action execution order
   - Set error handling behavior

3. **Action Configuration**
   - PowerShell scripts
   - Batch files
   - SQL scripts
   - Remote execution
   - Executable files
   - Set dependency chains
   - Configure parallel execution

4. **Task Management**
   - View all tasks in the main window
   - Edit, delete, or run tasks as needed
   - Monitor action status and history
   - Chain tasks for sequential execution

## Directory Structure

```
LiteTaskData/
├── logs/           # Application, task, and action logs
├── Modules/        # PowerShell modules
├── temp/           # Temporary files
├── tools/          # Required utilities
└── settings.xml    # Application configuration
```

## Command Line Interface

```
LiteTask.exe [options]
  -register          Register Windows service
  -unregister        Unregister Windows service
  -start             Start service
  -stop              Stop service
  -runtask <name>    Run specified task
  -debug             Run in debug mode
  -console           Run in console mode
  -runas <user>      Run as specific user
```

## Troubleshooting

1. Check app_log.txt for error messages
2. Verify tool installation status
3. Check module installation logs
4. Verify file permissions
5. Check network connectivity for remote tasks
6. Verify credential configuration
7. Check action-specific logs
8. Verify action dependencies
9. Monitor action execution order
10. Check timeout settings for long-running actions


## Support

- Submit issues on GitHub
- Check documentation for common solutions
- Contact support for enterprise assistance

## License

This software is provided under [LICENSE] terms.

## Contributing

1. Fork the repository
2. Create a feature branch
3. Submit a pull request
4. Follow coding standards
5. Include tests when applicable