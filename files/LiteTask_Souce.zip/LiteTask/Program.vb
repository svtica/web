Imports System.Reflection

Namespace LiteTask

        Module Program
        Private _mutex As Mutex = Nothing
        Private Const MutexName As String = "Global\LiteTaskApplication"
        Private ReadOnly LogBasePath As String = Path.Combine(Application.StartupPath, "LiteTaskData", "logs")


        <STAThread()>
        Public Sub Main(args As String())
            Try
                ' Ensure log directory exists
                EnsureLogDirectory()

                ' Set up assembly resolution before anything else
                AddHandler AppDomain.CurrentDomain.AssemblyResolve, AddressOf ResolveAssembly

                Application.EnableVisualStyles()
                Application.SetCompatibleTextRenderingDefault(False)

                ' Initialize container
                InitializeContainer()

                ' Set up global exception handlers
                AddHandler Application.ThreadException, AddressOf Application_ThreadException
                AddHandler AppDomain.CurrentDomain.UnhandledException, AddressOf CurrentDomain_UnhandledException

                ' Check for single instance
                Dim createdNew As Boolean
                _mutex = New Mutex(True, MutexName, createdNew)
                If Not createdNew Then
                    MessageBox.Show("Another instance of LiteTask is already running.", "LiteTask",
                          MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Return
                End If

                ' Process command line or start UI
                If args.Length > 0 Then
                    HandleCommandLineArguments(args)
                Else
                    ' Create and show the main application context
                    Dim context = New ApplicationContext()

                    ' Get the MainForm instance
                    Dim mainForm = DirectCast(context.GetType().GetField("_mainForm",
                System.Reflection.BindingFlags.NonPublic Or
                System.Reflection.BindingFlags.Instance).GetValue(context), MainForm)

                    ' Show the MainForm
                    If mainForm IsNot Nothing Then
                        mainForm.Show()
                    End If

                    Application.Run(context)
                End If

            Catch ex As Exception
                ShowDetailedError(ex)
            Finally
                If _mutex IsNot Nothing Then
                    _mutex.Close()
                    _mutex.Dispose()
                End If
            End Try
        End Sub

        Private Sub Application_ThreadException(sender As Object, e As ThreadExceptionEventArgs)
            ShowDetailedError(e.Exception)
        End Sub

        Private Sub CurrentDomain_UnhandledException(sender As Object, e As UnhandledExceptionEventArgs)
            ShowDetailedError(DirectCast(e.ExceptionObject, Exception))
        End Sub

        Private Sub EnsureLogDirectory()
            Try
                ' Create base LiteTaskData directory first
                Dim dataPath = Path.Combine(Application.StartupPath, "LiteTaskData")
                If Not Directory.Exists(dataPath) Then
                    Directory.CreateDirectory(dataPath)
                End If

                ' Create logs directory
                If Not Directory.Exists(LogBasePath) Then
                    Directory.CreateDirectory(LogBasePath)
                End If
            Catch ex As Exception
                ' If we can't create log directory, we'll fall back to app directory
                Console.WriteLine($"Warning: Could not create log directory: {ex.Message}")
            End Try
        End Sub

        Private Function GetLogPath(logName As String) As String
            Try
                Return Path.Combine(LogBasePath, logName)
            Catch
                ' Fallback to application directory if there's any issue
                Return Path.Combine(Application.StartupPath, logName)
            End Try
        End Function

        Private Sub HandleCommandLineArguments(args As String())
            Select Case args(0).ToLower()
                Case "-service"
                    RunAsService()
                Case "-register"
                    RegisterService()
                Case "-unregister"
                    UnregisterService()
                Case "-runtask"
                    If args.Length > 1 Then
                        RunTaskFromCommandLine(args(1))
                    Else
                        ShowHelp()
                    End If
                Case "-debug"
                    RunInDebugMode()
                Case Else
                    ShowHelp()
            End Select
        End Sub

        Private Sub HandleCriticalError(ex As Exception)
            Try
                ' Attempt to get logger if available
                Dim logger = TryGetService(Of Logger)()
                logger?.LogCritical($"Critical application error: {ex.Message}", ex)

                If Environment.UserInteractive Then
                    MessageBox.Show($"A critical error occurred: {ex.Message}{Environment.NewLine}{Environment.NewLine}Error Details: {ex.ToString()}",
                                  "Critical Error",
                                  MessageBoxButtons.OK, MessageBoxIcon.Error)
                End If
            Catch criticalEx As Exception
                ' Last resort error handling
                Console.WriteLine($"Critical Error: {criticalEx.Message}")
                MessageBox.Show($"Critical Error: {criticalEx.Message}", "Critical Error",
                              MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End Sub

        Private Sub LogAssemblyResolution(message As String)
            Try
                Dim logPath = GetLogPath("assembly_resolution.log")
                File.AppendAllText(logPath, $"{DateTime.Now:yyyy-MM-dd HH:mm:ss} - {message}{Environment.NewLine}")
            Catch
                ' Ignore logging errors
            End Try
        End Sub

        Private Sub InitializeContainer()
            Try
                ApplicationContainer.Initialize()
            Catch ex As Exception
                LogAssemblyResolution($"Container initialization failed: {ex.Message}")
                If ex.InnerException IsNot Nothing Then
                    LogAssemblyResolution($"Inner exception: {ex.InnerException.Message}")
                End If
                Throw New Exception("Failed to initialize application services", ex)
            End Try
        End Sub

        Private Sub RegisterService()
            Try
                Dim logger = ApplicationContainer.GetService(Of Logger)()
                Dim toolManager = ApplicationContainer.GetService(Of ToolManager)()
                Dim serviceName As String = "LiteTaskService"
                Dim exePath As String = System.Reflection.Assembly.GetEntryAssembly().Location

                ' Ensure we're using the .exe file
                If Not exePath.EndsWith(".exe", StringComparison.OrdinalIgnoreCase) Then
                    exePath = Path.ChangeExtension(exePath, ".exe")
                End If

                If Not File.Exists(exePath) Then
                    Throw New FileNotFoundException($"Executable not found: {exePath}")
                End If

                Dim installUtilPath As String = Path.Combine(System.Runtime.InteropServices.RuntimeEnvironment.GetRuntimeDirectory(), "InstallUtil.exe")

                Dim process As New Process()
                process.StartInfo.FileName = installUtilPath
                process.StartInfo.Arguments = $"""{exePath}"""
                process.StartInfo.UseShellExecute = False
                process.StartInfo.RedirectStandardOutput = True
                process.StartInfo.CreateNoWindow = True
                process.Start()

                Dim output As String = process.StandardOutput.ReadToEnd()
                process.WaitForExit()

                If process.ExitCode = 0 Then
                    Console.WriteLine("Service registered successfully.")
                    Console.WriteLine(output)
                Else
                    Console.WriteLine($"Error registering service. Exit code: {process.ExitCode}")
                    Console.WriteLine(output)
                End If
            Catch ex As Exception
                HandleCriticalError(ex)
            End Try
        End Sub

        Private Function ResolveAssembly(sender As Object, args As ResolveEventArgs) As Assembly
            Try
                ' Get the assembly name
                Dim assemblyName = New AssemblyName(args.Name)

                ' Skip resource assembly resolution attempts
                If assemblyName.Name.EndsWith(".resources", StringComparison.OrdinalIgnoreCase) Then
                    Return Nothing
                End If

                ' First try the lib folder
                Dim libPath As String = Path.Combine(Application.StartupPath, "lib")
                Dim assemblyPath As String = Path.Combine(libPath, assemblyName.Name & ".dll")

                'LogAssemblyResolution($"Trying to resolve assembly: {assemblyName.Name}")
                'LogAssemblyResolution($"Looking in lib folder: {assemblyPath}")

                If File.Exists(assemblyPath) Then
                    'LogAssemblyResolution($"Found assembly in lib folder: {assemblyPath}")
                    Return Assembly.LoadFrom(assemblyPath)
                End If

                ' If not found in lib, try the application root
                assemblyPath = Path.Combine(Application.StartupPath, assemblyName.Name & ".dll")
                'LogAssemblyResolution($"Looking in root folder: {assemblyPath}")

                If File.Exists(assemblyPath) Then
                    'LogAssemblyResolution($"Found assembly in root folder: {assemblyPath}")
                    Return Assembly.LoadFrom(assemblyPath)
                End If

                ' Log failure to find assembly
                'LogAssemblyResolution($"Failed to find assembly: {assemblyName.Name}")
                Return Nothing

            Catch ex As Exception
                LogAssemblyResolution($"Error resolving assembly: {ex.Message}")
                Return Nothing
            End Try
        End Function

        Private Sub RunAsService()
            Dim service = ApplicationContainer.GetService(Of LiteTaskService)()
            ServiceBase.Run(service)
        End Sub

        Private Sub RunInDebugMode()

            Try
                Console.WriteLine("Running in debug mode...")
                Dim service As New ServiceController("LiteTaskService")
                Dim logger = ApplicationContainer.GetService(Of Logger)()
                logger.LogInfo("Starting debug mode")
                If service.Status = ServiceControllerStatus.Stopped Then
                    service.Start()
                    service.WaitForStatus(ServiceControllerStatus.Running, TimeSpan.FromSeconds(10))
                    Console.WriteLine("Service started successfully.")
                Else
                    Console.WriteLine("Service is already running.")
                End If
            Catch ex As Exception
                HandleCriticalError(ex)
            End Try

        End Sub

        Private Sub RunTaskFromCommandLine(taskName As String)
            Try
                Dim scheduler = ApplicationContainer.GetService(Of CustomScheduler)()
                Dim logger = ApplicationContainer.GetService(Of Logger)()

                Dim task = scheduler.GetTask(taskName)
                If task Is Nothing Then
                    logger.LogError($"Task '{taskName}' not found")
                    Environment.Exit(1)
                    Return
                End If

                scheduler.RunTaskAsync(task).Wait()
                Environment.Exit(0)
            Catch ex As Exception
                Dim logger = ApplicationContainer.GetService(Of Logger)()
                logger.LogError($"Error running task from command line: {ex.Message}")
                Environment.Exit(1)
            End Try
        End Sub

        Private Sub ShowDetailedError(ex As Exception)
            Dim errorBuilder As New System.Text.StringBuilder()
            errorBuilder.AppendLine("A fatal error occurred while starting the application:")
            errorBuilder.AppendLine()
            errorBuilder.AppendLine($"Error: {ex.Message}")

            If ex.InnerException IsNot Nothing Then
                errorBuilder.AppendLine()
                errorBuilder.AppendLine($"Details: {ex.InnerException.Message}")
            End If

            errorBuilder.AppendLine()
            errorBuilder.AppendLine("Stack Trace:")
            errorBuilder.AppendLine(ex.StackTrace)

            If ex.InnerException IsNot Nothing Then
                errorBuilder.AppendLine()
                errorBuilder.AppendLine("Inner Exception Stack Trace:")
                errorBuilder.AppendLine(ex.InnerException.StackTrace)
            End If

            errorBuilder.AppendLine()
            errorBuilder.AppendLine("The application will now close.")

            ' Log error to file
            Try
                Dim logPath = GetLogPath("startup_error.log")
                File.WriteAllText(logPath, errorBuilder.ToString())
            Catch
                ' Ignore logging errors
            End Try

            MessageBox.Show(errorBuilder.ToString(), "Fatal Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Environment.Exit(1)
        End Sub

        Private Sub ShowHelp()
            Console.WriteLine("LiteTask - Command Line Options:")
            Console.WriteLine("  -service    - Run as Windows service")
            Console.WriteLine("  -register   - Register the Windows service")
            Console.WriteLine("  -unregister - Unregister the Windows service")
            Console.WriteLine("  -runtask    - Run a specific task (e.g., -runtask TaskName)")
            Console.WriteLine("  -debug      - Run in debug mode")
            Console.WriteLine("  -help       - Show this help message")
        End Sub

        Private Sub ShowFatalError(ex As Exception)
            Dim errorMessage = $"A fatal error occurred while starting the application:{Environment.NewLine}{Environment.NewLine}" &
                             $"Error: {ex.Message}{Environment.NewLine}{Environment.NewLine}"

            If ex.InnerException IsNot Nothing Then
                errorMessage &= $"Details: {ex.InnerException.Message}{Environment.NewLine}"
            End If

            errorMessage &= $"{Environment.NewLine}The application will now close."

            MessageBox.Show(errorMessage, "Fatal Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Environment.Exit(1)
        End Sub

        Private Function TryGetService(Of T)() As T
            Try
                Return ApplicationContainer.GetService(Of T)()
            Catch
                Return Nothing
            End Try
        End Function

        Private Sub UnregisterService()
                Try
                    Dim installUtilPath As String = System.Runtime.InteropServices.RuntimeEnvironment.GetRuntimeDirectory() & "InstallUtil.exe"
                    Dim executablePath As String = Environment.GetCommandLineArgs()(0)
                    Dim process As New Process()
                    process.StartInfo.FileName = installUtilPath
                    process.StartInfo.Arguments = $"/u ""{executablePath}"""
                    process.StartInfo.UseShellExecute = False
                    process.StartInfo.RedirectStandardOutput = True
                    process.Start()
                    process.WaitForExit()
                    Console.WriteLine(process.StandardOutput.ReadToEnd())
                    Console.WriteLine("Service unregistered successfully.")
                Catch ex As Exception
                HandleCriticalError(ex)
            End Try
            End Sub

        End Module
    End Namespace
