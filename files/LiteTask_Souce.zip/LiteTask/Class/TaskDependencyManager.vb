Imports LiteTask.LiteTask.ScheduledTask

Namespace LiteTask
    ' Task Dependency Management
    Public Class TaskDependencyManager
        Private ReadOnly _logger As Logger
        Private ReadOnly _xmlManager As XMLManager
        Private ReadOnly _customScheduler As CustomScheduler

        Public Sub New(logger As Logger, xmlManager As XMLManager, customScheduler As CustomScheduler)
            _logger = logger
            _xmlManager = xmlManager
            _customScheduler = customScheduler
        End Sub

        Public Function ValidateDependencies(task As ScheduledTask) As List(Of String)
            Dim errors As New List(Of String)
            Try
                ' Check for circular dependencies
                Dim visitedTasks As New HashSet(Of String)
                If HasCircularDependency(task.Name, visitedTasks) Then
                    errors.Add($"Circular dependency detected for task {task.Name}")
                End If

                ' Check if dependent tasks exist
                For Each action In task.Actions.Where(Function(a) a.DependsOn IsNot Nothing)
                    Dim dependentTask = _customScheduler.GetTask(action.DependsOn)
                    If dependentTask Is Nothing Then
                        errors.Add($"Dependent task {action.DependsOn} not found for action {action.Order}")
                    End If
                Next

                ' Validate execution order based on dependencies
                ValidateExecutionOrder(task, errors)

            Catch ex As Exception
                _logger.LogError($"Error validating dependencies for task {task.Name}", ex)
                errors.Add($"Error validating dependencies: {ex.Message}")
            End Try

            Return errors
        End Function

        Private Function HasCircularDependency(taskName As String, visitedTasks As HashSet(Of String)) As Boolean
            If visitedTasks.Contains(taskName) Then
                Return True
            End If

            visitedTasks.Add(taskName)
            Dim task = _customScheduler.GetTask(taskName)

            If task IsNot Nothing Then
                For Each action In task.Actions
                    If action.DependsOn IsNot Nothing Then
                        If HasCircularDependency(action.DependsOn, New HashSet(Of String)(visitedTasks)) Then
                            Return True
                        End If
                    End If
                Next
            End If

            visitedTasks.Remove(taskName)
            Return False
        End Function

        Private Sub ValidateExecutionOrder(task As ScheduledTask, errors As List(Of String))
            Dim dependencyGraph As New Dictionary(Of Integer, HashSet(Of Integer))

            ' Build dependency graph for actions
            For i As Integer = 0 To task.Actions.Count - 1
                dependencyGraph(i) = New HashSet(Of Integer)
                Dim currentAction = task.Actions(i)

                ' Add dependencies based on DependsOn property
                If currentAction.DependsOn IsNot Nothing Then
                    For j As Integer = 0 To task.Actions.Count - 1
                        If i <> j AndAlso task.Actions(j).Name = currentAction.DependsOn Then
                            dependencyGraph(i).Add(j)
                        End If
                    Next
                End If
            Next

            ' Verify no action depends on a later action
            For i As Integer = 0 To task.Actions.Count - 1
                For Each dependency In dependencyGraph(i)
                    If dependency > i Then
                        errors.Add($"Action {i + 1} depends on action {dependency + 1} which comes later in the sequence")
                    End If
                Next
            Next
        End Sub

        Public Function GetExecutionOrder(task As ScheduledTask) As List(Of TaskAction)
            Try
                Dim sortedActions As New List(Of TaskAction)
                Dim visited As New HashSet(Of String)
                Dim processing As New HashSet(Of String)

                For Each action In task.Actions
                    If Not visited.Contains(action.Name) Then
                        If Not TopologicalSort(action, task, visited, processing, sortedActions) Then
                            _logger.LogError($"Circular dependency detected in task {task.Name}")
                            Return task.Actions.ToList() ' Return original order if circular dependency found
                        End If
                    End If
                Next

                Return sortedActions

            Catch ex As Exception
                _logger.LogError($"Error determining execution order for task {task.Name}", ex)
                Return task.Actions.ToList() ' Return original order on error
            End Try
        End Function

        Private Function TopologicalSort(
            action As TaskAction,
            task As ScheduledTask,
            visited As HashSet(Of String),
            processing As HashSet(Of String),
            sortedActions As List(Of TaskAction)) As Boolean

            If processing.Contains(action.Name) Then
                Return False ' Circular dependency
            End If

            If visited.Contains(action.Name) Then
                Return True ' Already processed
            End If

            processing.Add(action.Name)

            ' Process dependencies
            If action.DependsOn IsNot Nothing Then
                Dim dependentAction = task.Actions.FirstOrDefault(Function(a) a.Name = action.DependsOn)
                If dependentAction IsNot Nothing Then
                    If Not TopologicalSort(dependentAction, task, visited, processing, sortedActions) Then
                        Return False
                    End If
                End If
            End If

            processing.Remove(action.Name)
            visited.Add(action.Name)
            sortedActions.Add(action)
            Return True
        End Function

        Public Function GetDependentTasks(taskName As String) As List(Of String)
            Dim dependentTasks As New List(Of String)
            Try
                For Each task In _customScheduler.GetAllTasks()
                    For Each action In task.Actions
                        If action.DependsOn = taskName Then
                            dependentTasks.Add(task.Name)
                            Exit For
                        End If
                    Next
                Next
            Catch ex As Exception
                _logger.LogError($"Error getting dependent tasks for {taskName}", ex)
            End Try
            Return dependentTasks
        End Function
    End Class

    Public Class TaskAction

        ' Basic properties
        Public Property Order As Integer
        Public Property Name As String
        Public Property Type As TaskType
        Public Property Target As String
        Public Property Parameters As String
        Public Property RequiresElevation As Boolean

        ' Dependency properties
        Public Property DependsOn As String
        Public Property WaitForCompletion As Boolean = True
        Public Property TimeoutMinutes As Integer = 60
        Public Property RetryCount As Integer = 0
        Public Property RetryDelayMinutes As Integer = 5
        Public Property ContinueOnError As Boolean = False
        Public Property Status As TaskActionStatus = TaskActionStatus.Pending
        Public Property LastResult As TaskActionResult
        Public Property LastRunTime As DateTime?
        Public Property NextRetryTime As DateTime?

        Public Function Clone() As TaskAction
            Return DirectCast(Me.MemberwiseClone(), TaskAction)
        End Function
    End Class

    Public Enum TaskActionStatus
        Pending
        Running
        Completed
        Failed
        Retrying
        TimedOut
        Skipped
    End Enum

    Public Class TaskActionResult
        Public Property Success As Boolean
        Public Property Message As String
        Public Property StartTime As DateTime
        Public Property EndTime As DateTime
        Public Property RetryCount As Integer
        Public Property ErrorDetails As Exception

        Public ReadOnly Property Duration As TimeSpan
            Get
                Return EndTime - StartTime
            End Get
        End Property

    End Class
End Namespace