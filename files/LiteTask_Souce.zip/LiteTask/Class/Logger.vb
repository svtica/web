Imports System.Collections.Concurrent
Imports System.IO.Compression
Imports System.Threading
Imports System.Xml


Namespace LiteTask
    Public Class Logger
        Implements IDisposable

        Private ReadOnly _logQueue As New ConcurrentQueue(Of LogEntry)
        Private ReadOnly _processorCancellation As New CancellationTokenSource()
        Private _processorTask As Task
        Private _logFile As String
        Private _logFolder As String
        Private _logLevel As LogLevel
        Private _maxLogSize As Long = 10 * 1024 * 1024  ' 10MB default
        Private _maxLogAge As TimeSpan = TimeSpan.FromDays(30)
        Private ReadOnly _lock As New Object()
        Private _disposed As Boolean = False
        Private Shared _instance As Logger


        Public Enum LogLevel
            [Info]
            [Warning]
            [Error]
            [Critical]
            [Debug]
        End Enum

        Public Sub New(xmlManager As XMLManager, defaultLogFilePath As String)
            SetLogFile(xmlManager.ReadValue("Logging", "LogFilePath", defaultLogFilePath))
            SetLogLevel(DirectCast([Enum].Parse(GetType(LogLevel), xmlManager.ReadValue("Logging", "LogLevel", "Info")), LogLevel))
            StartLogProcessor()
            InitializeLogRotation()
        End Sub

        Private Sub CleanupOldLogs()
            Try
                Dim directory = New DirectoryInfo(_logFolder)
                Dim cutoffDate = DateTime.Now.Subtract(_maxLogAge)

                For Each file In directory.GetFiles($"{Path.GetFileNameWithoutExtension(_logFile)}_*.log*")
                    If file.CreationTime < cutoffDate Then
                        file.Delete()
                    End If
                Next
            Catch ex As Exception
                Debug.WriteLine($"Error cleaning up old logs: {ex.Message}")
            End Try
        End Sub

        Private Shared Sub CompressLog(logPath As String)
            Try
                Using originalFile As FileStream = File.OpenRead(logPath)
                    Using compressedFile As FileStream = File.Create($"{logPath}.gz")
                        Using gzipStream As New GZipStream(compressedFile, CompressionLevel.Optimal)
                            originalFile.CopyTo(gzipStream)
                        End Using
                    End Using
                End Using
                File.Delete(logPath)
            Catch ex As Exception
                Debug.WriteLine($"Error compressing log: {ex.Message}")
            End Try
        End Sub

        Protected Overridable Sub Dispose(disposing As Boolean)
            If Not _disposed Then
                If disposing Then
                    _processorCancellation.Cancel()
                    Try
                        _processorTask?.Wait(TimeSpan.FromSeconds(5))
                    Catch ex As Exception
                        Debug.WriteLine($"Error waiting for log processor to complete: {ex.Message}")
                    End Try
                    _processorCancellation.Dispose()
                End If
                _disposed = True
            End If
        End Sub

        Public Sub Dispose() Implements IDisposable.Dispose
            Dispose(True)
            GC.SuppressFinalize(Me)
        End Sub

        Private Sub InitializeLogRotation()
            Task.Run(Async Function()
                         While Not _processorCancellation.Token.IsCancellationRequested
                             Try
                                 RotateLogs()
                                 CleanupOldLogs()
                                 Await Task.Delay(TimeSpan.FromHours(1), _processorCancellation.Token)
                             Catch ex As Exception
                                 Debug.WriteLine($"Error in log rotation: {ex.Message}")
                             End Try
                         End While
                     End Function, _processorCancellation.Token)
        End Sub

        Public Event LogEntryAdded As EventHandler(Of LogEntryEventArgs)

        Public Sub LogDebug(message As String, Optional exception As Exception = Nothing)
            QueueLogEntry(LogLevel.Debug, message, exception)
        End Sub

        Public Sub LogInfo(message As String, Optional exception As Exception = Nothing)
            QueueLogEntry(LogLevel.Info, message, exception)
        End Sub


        Public Sub LogError(message As String, Optional exception As Exception = Nothing)
            QueueLogEntry(LogLevel.Error, message, exception)
        End Sub

        Public Sub LogCritical(message As String, Optional exception As Exception = Nothing)
            QueueLogEntry(LogLevel.Critical, message, exception)
        End Sub

        Public Sub LogWarning(message As String, Optional exception As Exception = Nothing)
            QueueLogEntry(LogLevel.Warning, message, exception)
        End Sub
        Private Sub RotateLogs()
            SyncLock _lock
                Try
                    If Not File.Exists(_logFile) Then Return

                    Dim fileInfo = New FileInfo(_logFile)
                    If fileInfo.Length >= _maxLogSize Then
                        Dim timestamp = DateTime.Now.ToString("yyyyMMddHHmmss")
                        Dim archivePath = Path.Combine(_logFolder,
                                $"{Path.GetFileNameWithoutExtension(_logFile)}_{timestamp}{Path.GetExtension(_logFile)}")
                        File.Move(_logFile, archivePath)
                        CompressLog(archivePath)
                    End If
                Catch ex As Exception
                    Debug.WriteLine($"Error rotating logs: {ex.Message}")
                End Try
            End SyncLock
        End Sub

        Public Sub SetLogFile(logFilePath As String)
            _logFile = logFilePath
            _logFolder = Path.GetDirectoryName(_logFile)
            If Not Directory.Exists(_logFolder) Then
                Directory.CreateDirectory(_logFolder)
            End If
        End Sub

        Public Sub SetLogFolder(folder As String)
            _logFolder = folder
            _logFile = Path.Combine(_logFolder, Path.GetFileName(_logFile))
        End Sub

        Public Sub SetLogLevel(level As LogLevel)
            _logLevel = level
        End Sub

        Private Sub StartLogProcessor()
            _processorTask = Task.Run(Async Function()
                                          While Not _processorCancellation.Token.IsCancellationRequested
                                              Try
                                                  Dim entry As LogEntry = Nothing
                                                  If _logQueue.TryDequeue(entry) Then
                                                      Await WriteLogEntryAsync(entry)
                                                  Else
                                                      Await Task.Delay(100, _processorCancellation.Token)
                                                  End If
                                              Catch ex As Exception
                                                  ' Last resort error handling
                                                  Debug.WriteLine($"Error processing log entry: {ex.Message}")
                                              End Try
                                          End While
                                      End Function, _processorCancellation.Token)
        End Sub

        Private Sub QueueLogEntry(level As LogLevel, message As String, exception As Exception)
            If level >= _logLevel Then
                _logQueue.Enqueue(New LogEntry With {
                        .Level = level,
                        .Message = message,
                        .Exception = exception,
                        .Timestamp = DateTime.Now
                    })
            End If
        End Sub

        Private Async Function WriteLogEntryAsync(entry As LogEntry) As Task
            Dim logEntry = $"{entry.Timestamp:yyyy-MM-dd HH:mm:ss.fff} [{entry.Level}] {entry.Message}"
            If entry.Exception IsNot Nothing Then
                logEntry &= $"{Environment.NewLine}Exception: {entry.Exception.Message}"
                logEntry &= $"{Environment.NewLine}StackTrace: {entry.Exception.StackTrace}"
            End If
            logEntry &= Environment.NewLine

            Try
                SyncLock _lock
                    Using writer As New StreamWriter(_logFile, True, Encoding.UTF8)
                        ' Use sync write inside lock
                        writer.Write(logEntry)
                    End Using
                End SyncLock

                ' Write to debug output for development
                Debug.WriteLine(logEntry)

                ' Notify UI if needed
                RaiseEvent LogEntryAdded(Me, New LogEntryEventArgs(entry))

            Catch ex As Exception
                Debug.WriteLine($"Error writing log entry: {ex.Message}")
            End Try
        End Function

    End Class

    Public Class LogEntry
        Public Property Timestamp As DateTime
        Public Property Level As Logger.LogLevel
        Public Property Message As String
        Public Property Exception As Exception
    End Class

    Public Class LogEntryEventArgs
        Inherits EventArgs

        Public Property LogEntry As LogEntry

        Public Sub New(entry As LogEntry)
            LogEntry = entry
        End Sub
    End Class

End Namespace

