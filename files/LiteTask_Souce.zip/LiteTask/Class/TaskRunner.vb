Imports System.Collections.ObjectModel
Imports System.Data
Imports System.Data.SqlClient

Namespace LiteTask
    Public Class TaskRunner

        Private ReadOnly _logger As Logger
        Private ReadOnly _credentialManager As CredentialManager
        Private ReadOnly _runspace As Runspace
        Private ReadOnly _impersonation As Impersonation
        Private ReadOnly _liteRunConfig As LiteRunConfig
        Private ReadOnly _toolManager As ToolManager
        Private ReadOnly _logPath As String
        Private ReadOnly _powerShellPathManager As PowerShellPathManager
        Private _connectionStringBase As String
        Public Event OutputReceived(sender As Object, e As DataAddedEventArgs)
        Public Event ErrorReceived(sender As Object, e As DataAddedEventArgs)

        Public Sub New(logger As Logger, credentialManager As CredentialManager, toolManager As ToolManager, logPath As String)
            If logger Is Nothing Then
                Throw New ArgumentNullException(NameOf(logger))
            End If
            If credentialManager Is Nothing Then
                Throw New ArgumentNullException(NameOf(credentialManager))
            End If
            If toolManager Is Nothing Then
                Throw New ArgumentNullException(NameOf(toolManager))
            End If
            If String.IsNullOrEmpty(logPath) Then
                Throw New ArgumentNullException(NameOf(logPath))
            End If

            _logger = logger
            _credentialManager = credentialManager
            _toolManager = toolManager
            _logPath = logPath
            _powerShellPathManager = New PowerShellPathManager(logger)

            ' Ensure required directories exist
            Directory.CreateDirectory(_logPath)
            Directory.CreateDirectory(_toolManager.ToolsPath)

            ' Verify required tools exist
            VerifyRequiredTools()

            ' Initialize PowerShell environment
            _powerShellPathManager.EnsureModulePathExists()
            Dim initialSessionState As InitialSessionState = InitialSessionState.CreateDefault2()
            initialSessionState.ExecutionPolicy = ExecutionPolicy.Bypass
            initialSessionState.ImportPSModule(Directory.GetDirectories(_powerShellPathManager.GetModulePath()))
            _runspace = RunspaceFactory.CreateRunspace(initialSessionState)
            _runspace.Open()
        End Sub

        Private Function CreateThreadSafeLogger(logFilePath As String) As Action(Of String, String)
            Dim lockObj As New Object()
            Return Sub(message As String, level As String)
                       SyncLock lockObj
                           Try
                               File.AppendAllText(logFilePath,
                           $"{DateTime.Now:yyyy-MM-dd HH:mm:ss} [{level}] {message}{Environment.NewLine}")
                           Catch ex As Exception
                               _logger.LogError($"Failed to write to log file: {ex.Message}")
                           End Try
                       End SyncLock
                   End Sub
        End Function

        Public Sub Dispose()
            If _runspace IsNot Nothing Then
                _runspace.Dispose()
            End If
        End Sub

        Public Async Function ExecuteStoredProcedureWithOSQL(
            storedProcedureName As String,
            server As String,
            database As String,
            credential As CredentialInfo) As Task(Of String)

            Dim tempSqlFile As String = Nothing

            Try

                ' Create log file path with timestamp
                Dim logFileName = $"SP_{storedProcedureName}_{DateTime.Now:yyyyMMddHHmmss}.log"
                Dim logFilePath = Path.Combine(_logPath, logFileName)
                Dim writeLog = CreateThreadSafeLogger(logFilePath)


                ' Validate inputs
                If String.IsNullOrEmpty(storedProcedureName) Then
                    Throw New ArgumentNullException(NameOf(storedProcedureName))
                End If
                If String.IsNullOrEmpty(server) Then
                    Throw New ArgumentNullException(NameOf(server))
                End If
                If String.IsNullOrEmpty(database) Then
                    Throw New ArgumentNullException(NameOf(database))
                End If

                ' Create temp directory in LiteTaskData
                Dim tempDir = Path.Combine(Application.StartupPath, "LiteTaskData", "temp")
                If Not Directory.Exists(tempDir) Then
                    Directory.CreateDirectory(tempDir)
                    _logger.LogInfo($"Created temp directory: {tempDir}")
                End If


                ' Create a temporary SQL file in LiteTaskData\temp directory
                tempSqlFile = Path.Combine(tempDir, $"sp_{DateTime.Now:yyyyMMddHHmmss}.sql")
                _logger.LogInfo($"Creating SQL file at: {tempSqlFile}")

                ' Create SQL script with correct database usage
                Dim sqlScript =
                    $"USE [{database}]{Environment.NewLine}" &
                    "GO" & Environment.NewLine &
                    $"SET NOCOUNT ON{Environment.NewLine}" &
                    "GO" & Environment.NewLine &
                    $"DECLARE @return_value int{Environment.NewLine}" &
                    $"EXEC @return_value = {storedProcedureName}{Environment.NewLine}" &
                    $"SELECT 'Return Value' = @return_value{Environment.NewLine}" &
                    "GO"


                ' Write SQL script and verify it was created
                Await File.WriteAllTextAsync(tempSqlFile, sqlScript)
                If Not File.Exists(tempSqlFile) Then
                    Throw New FileNotFoundException("Failed to create SQL script file", tempSqlFile)
                End If
                _logger.LogInfo($"SQL script file created successfully: {Environment.NewLine}{sqlScript}")

                ' Get and verify tool paths
                Dim psExecPath = Path.Combine(_toolManager.ToolsPath, "PsExec.exe")
                Dim osqlPath = Path.Combine(_toolManager.ToolsPath, "OSQL.exe")

                If Not File.Exists(psExecPath) Then
                    Throw New FileNotFoundException("PsExec.exe not found in tools directory", psExecPath)
                End If
                _logger.LogInfo($"Found PsExec at: {psExecPath}")

                If Not File.Exists(osqlPath) Then
                    Throw New FileNotFoundException("OSQL.exe not found in tools directory", osqlPath)
                End If
                _logger.LogInfo($"Found OSQL at: {osqlPath}")

                ' Build command for local execution
                Dim command = New StringBuilder()
                command.Append($"""{psExecPath}"" -h -accepteula -nobanner -i ")

                If credential IsNot Nothing Then
                    command.Append($"-u ""{credential.Username}"" -p ""{credential.Password}"" ")
                End If

                command.Append($"""{osqlPath}"" -D {server} -S -E -i ""{tempSqlFile}""")

                ' OSQL arguments:
                ' -S: Server name
                ' -d: Database name
                ' -E: Trusted connection
                ' -n: Remove numbering
                ' -b: Terminate batch job if there is an error
                ' -r: Messages to stderr

                ' Create masked command for logging
                Dim maskedCommand = command.ToString()
                If credential IsNot Nothing Then
                    maskedCommand = maskedCommand.Replace(credential.Password, "********")
                End If
                _logger.LogInfo($"Executing command: {maskedCommand}")

                ' Write initial log entry
                writeLog("Stored procedure execution started", "START")

                ' Set up process to run PsExec directly
                Dim startInfo = New ProcessStartInfo(psExecPath) With {
            .Arguments = command.ToString().Replace($"""{psExecPath}"" ", ""),
            .RedirectStandardOutput = True,
            .RedirectStandardError = True,
            .UseShellExecute = False,
            .CreateNoWindow = True,
            .WorkingDirectory = _toolManager.ToolsPath
            }

                _logger.LogInfo($"Process working directory: {startInfo.WorkingDirectory}")
                _logger.LogInfo($"Process arguments: {maskedCommand}")

                Dim outputBuilder As New StringBuilder()
                Dim errorBuilder As New StringBuilder()

                Using process As New Process()
                    process.StartInfo = startInfo

                    AddHandler process.OutputDataReceived, Sub(sender, e)
                                                               If e.Data IsNot Nothing Then
                                                                   outputBuilder.AppendLine(e.Data)
                                                                   writeLog(e.Data, "OUTPUT")
                                                                   _logger.LogInfo($"Process output: {e.Data}")
                                                               End If
                                                           End Sub

                    AddHandler process.ErrorDataReceived, Sub(sender, e)
                                                              If e.Data IsNot Nothing Then
                                                                  errorBuilder.AppendLine(e.Data)
                                                                  writeLog(e.Data, "ERROR")
                                                                  _logger.LogError($"Process error: {e.Data}")
                                                              End If
                                                          End Sub

                    process.Start()
                    process.BeginOutputReadLine()
                    process.BeginErrorReadLine()
                    Await process.WaitForExitAsync()

                    Dim output = outputBuilder.ToString()
                    Dim errorOutput = errorBuilder.ToString()

                    If process.ExitCode <> 0 Then
                        Dim errorMessage = $"Process exited with code {process.ExitCode}. Error: {errorOutput}"
                        _logger.LogError(errorMessage)
                        writeLog(errorMessage, "ERROR")
                        Return $"Error: {errorMessage}"
                    End If

                    ' Let the process fully complete before returning
                    Threading.Thread.Sleep(1000)
                    Return output
                End Using

            Catch ex As Exception
                _logger.LogError($"Error executing stored procedure: {ex.Message}")
                _logger.LogError($"StackTrace: {ex.StackTrace}")
                Return $"Error: {ex.Message}"
            Finally
                ' Clean up temp file
                Threading.Thread.Sleep(1000)
                If tempSqlFile IsNot Nothing AndAlso File.Exists(tempSqlFile) Then
                    Try
                        File.Delete(tempSqlFile)
                        _logger.LogInfo($"Deleted temporary SQL file: {tempSqlFile}")
                    Catch ex As Exception
                        _logger.LogWarning($"Failed to delete temporary file {tempSqlFile}: {ex.Message}")
                    End Try
                End If
            End Try
        End Function

        Public Async Function ExecuteQueryAsync(query As String, Optional parameters As Dictionary(Of String, Object) = Nothing, Optional credentialTarget As String = Nothing) As Task(Of SqlExecutionResult)
            Try
                _logger.LogInfo($"Attempting to execute query using SQL Client")
                Dim connectionString = GetConnectionString(credentialTarget)
                Using connection As New SqlConnection(connectionString)
                    Await connection.OpenAsync()
                    Using command As New SqlCommand(query, connection)
                        If parameters IsNot Nothing Then
                            For Each param In parameters
                                command.Parameters.AddWithValue(param.Key, param.Value)
                            Next
                        End If

                        Dim result As New SqlExecutionResult()
                        If query.Trim().ToUpper().StartsWith("SELECT") Then
                            Using reader = Await command.ExecuteReaderAsync()
                                Dim dataTable As New DataTable()
                                dataTable.Load(reader)
                                result.Data = dataTable
                                result.RowsAffected = dataTable.Rows.Count
                            End Using
                        Else
                            result.RowsAffected = Await command.ExecuteNonQueryAsync()
                        End If

                        result.Success = True
                        result.Message = $"Query executed successfully. Rows affected: {result.RowsAffected}"
                        _logger.LogInfo(result.Message)
                        Return result
                    End Using
                End Using
            Catch ex As Exception
                _logger.LogError($"Error executing SQL query: {ex.Message}")
                Return New SqlExecutionResult With {
                    .Success = False,
                    .Message = $"Error executing SQL query: {ex.Message}"
                }
            End Try
        End Function

        Private Function GetConnectionString(credentialTarget As String) As String
            If String.IsNullOrEmpty(credentialTarget) Then
                Return _connectionStringBase
            End If

            Dim credential = _credentialManager.GetCredential(credentialTarget, "Current User")
            If credential Is Nothing Then
                _logger.LogWarning($"Credential not found for target: {credentialTarget}. Using default connection string.")
                Return _connectionStringBase
            End If

            Dim builder = New SqlConnectionStringBuilder(_connectionStringBase)
            builder.UserID = credential.Username
            builder.Password = credential.Password
            Return builder.ConnectionString
        End Function

        Private Sub OnErrorReceived(sender As Object, e As DataAddedEventArgs)
            Dim errorRecord As ErrorRecord = CType(sender, PSDataCollection(Of ErrorRecord))(e.Index)
            _logger.LogError($"PowerShell Error: {errorRecord.Exception.Message}")
        End Sub

        Private Sub OnInformationReceived(sender As Object, e As DataAddedEventArgs)
            Dim informationRecord As InformationRecord = CType(sender, PSDataCollection(Of InformationRecord))(e.Index)
            _logger.LogInfo($"PowerShell Output: {informationRecord.MessageData}")
        End Sub

        Public Async Function RunProcessAsync(fileName As String, arguments As String) As Task(Of String)
            Dim output As New System.Text.StringBuilder()
            Dim err As New System.Text.StringBuilder()

            Dim startInfo As New ProcessStartInfo(fileName) With {
            .Arguments = arguments,
            .RedirectStandardOutput = True,
            .RedirectStandardError = True,
            .UseShellExecute = False,
            .CreateNoWindow = True
        }

            Using process As New Process() With {.StartInfo = startInfo}
                AddHandler process.OutputDataReceived, Sub(sender, e)
                                                           If e.Data IsNot Nothing Then
                                                               output.AppendLine(e.Data)
                                                           End If
                                                       End Sub
                AddHandler process.ErrorDataReceived, Sub(sender, e)
                                                          If e.Data IsNot Nothing Then
                                                              err.AppendLine(e.Data)
                                                          End If
                                                      End Sub
                process.Start()
                process.BeginOutputReadLine()
                process.BeginErrorReadLine()
                Await process.WaitForExitAsync()

                If process.ExitCode <> 0 Then
                    Dim exitCode As LiteRunExitCode = CType(process.ExitCode, LiteRunExitCode)
                    Throw New LiteRunException(exitCode, $"Process exited with code {process.ExitCode}. Error: {err}")
                End If
            End Using

            Return output.ToString()
        End Function

        Public Async Function RunScriptAsync(scriptPath As String, parameters As Hashtable, Optional useRemoting As Boolean = False, Optional credential As PSCredential = Nothing) As Task(Of Collection(Of PSObject))
            Try
                _logger.LogInfo($"Preparing to run script: {scriptPath}")

                Using powerShell As PowerShell = _powerShellPathManager.CreatePowerShellInstance()
                    powerShell.Runspace = _runspace

                    ' Add initialization script
                    powerShell.AddScript(_powerShellPathManager.CreateInitializationScript())

                    ' Add the actual script
                    If File.Exists(scriptPath) Then
                        powerShell.AddScript(File.ReadAllText(scriptPath))
                    Else
                        powerShell.AddScript(scriptPath)
                    End If

                    For Each param In parameters
                        powerShell.AddParameter(param.Key.ToString(), param.Value)
                    Next

                    If useRemoting Then
                        powerShell.AddCommand("Invoke-Command")
                        If parameters.ContainsKey("ComputerName") Then
                            powerShell.AddParameter("ComputerName", parameters("ComputerName"))
                        End If
                        If credential IsNot Nothing Then
                            powerShell.AddParameter("Credential", credential)
                        End If
                    End If

                    AddHandler powerShell.Streams.Error.DataAdded, AddressOf OnErrorReceived
                    AddHandler powerShell.Streams.Information.DataAdded, AddressOf OnInformationReceived

                    Dim result = Await Task.Run(Function() powerShell.Invoke())

                    If powerShell.HadErrors Then
                        Throw New Exception("PowerShell execution encountered errors. Check the error log for details.")
                    End If

                    Return result
                End Using
            Catch ex As Exception
                _logger.LogError($"Error in RunScriptAsync: {ex.Message}")
                _logger.LogError($"StackTrace: {ex.StackTrace}")
                Throw
            End Try
        End Function

        Public Sub UpdateConnectionString(newConnectionString As String)
            _connectionStringBase = newConnectionString
        End Sub

        Private Sub VerifyRequiredTools()
            ' Check for required tools
            Dim requiredTools = New String() {"PsExec.exe", "OSQL.exe", "osql.rll"}
            Dim missingTools = New List(Of String)

            For Each tool In requiredTools
                Dim toolPath = Path.Combine(_toolManager.ToolsPath, tool)
                If Not File.Exists(toolPath) Then
                    missingTools.Add(tool)
                End If
            Next

            If missingTools.Any() Then
                Throw New Exception($"Required tools missing: {String.Join(", ", missingTools)}. Please ensure all required tools are in the tools directory: {_toolManager.ToolsPath}")
            End If
        End Sub

    End Class

    Public Class SqlExecutionResult
        Public Property Success As Boolean
        Public Property Message As String
        Public Property Data As DataTable
        Public Property RowsAffected As Integer
    End Class

End Namespace
