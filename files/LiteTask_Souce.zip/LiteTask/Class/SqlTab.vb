Imports System.Data
Imports System.Data.SqlClient

Namespace LiteTask
    Public Class SqlTab
        ' Values
        Private _connectionStringBase As String
        Private ReadOnly _logPath As String
        Private _tabPageInitialized As Boolean = False
        ' Components
        Private ReadOnly _credentialManager As CredentialManager
        Private ReadOnly _logger As Logger
        Private ReadOnly _taskRunner As TaskRunner
        Private ReadOnly _powerShellManager As RunTab
        Private ReadOnly _xmlManager As XMLManager
        Private ReadOnly _emailUtils As EmailUtils
        Private ReadOnly _liteRunConfig As LiteRunConfig
        ' Controls
        Private _queryTextBox As TextBox
        Private _outputTextBox As TextBox
        Private _runButton As Button
        Private _queryTypeComboBox As ComboBox
        Private _credentialComboBox As ComboBox
        Private WithEvents _serverTextBox As TextBox
        Private _databaseComboBox As ComboBox
        Private _queryLabel As Label
        Private _outputLabel As Label
        Private _serverLabel As Label
        Private _databaseLabel As Label
        Private _credentialLabel As Label
        Private _tabPage As TabPage
        Private _tableLayoutPanel As TableLayoutPanel
        Private WithEvents _connectButton As Button
        Private _objectListComboBox As ComboBox
        Private _objectListLabel As Label
        Private _selectAllButton As Button
        Private _returnLastEntryButton As Button

        Private Enum SqlExecutionMethod
            Direct
            taskRunner
            PowerShellRemoting
            CredSSP
        End Enum

        Public Sub New(credentialManager As CredentialManager, logger As Logger, taskRunner As TaskRunner, xmlManager As XMLManager, logPath As String)
            If credentialManager Is Nothing Then
                Throw New ArgumentNullException(NameOf(credentialManager))
            End If
            If logger Is Nothing Then
                Throw New ArgumentNullException(NameOf(logger))
            End If
            If taskRunner Is Nothing Then
                Throw New ArgumentNullException(NameOf(taskRunner))
            End If
            If xmlManager Is Nothing Then
                Throw New ArgumentNullException(NameOf(xmlManager))
            End If
            If String.IsNullOrEmpty(logPath) Then
                Throw New ArgumentNullException(NameOf(logPath))
            End If

            _credentialManager = credentialManager
            _logger = logger
            _taskRunner = taskRunner
            _xmlManager = xmlManager
            _logPath = logPath
            _emailUtils = New EmailUtils(logger, xmlManager)
            _liteRunConfig = New LiteRunConfig(xmlManager.GetLiteRunDefaults())

            InitializeComponent()
            PopulateCredentialComboBox()
            PopulateQueryTypeComboBox()
        End Sub

        Private Sub AddHandlers()
            AddHandler _runButton.Click, AddressOf RunButton_Click
            AddHandler _selectAllButton.Click, AddressOf SelectAllButton_Click
            AddHandler _returnLastEntryButton.Click, AddressOf ReturnLastEntryButton_Click
            AddHandler _queryTypeComboBox.SelectedIndexChanged, AddressOf QueryTypeComboBox_SelectedIndexChanged
            AddHandler _objectListComboBox.SelectedIndexChanged, AddressOf ObjectListComboBox_SelectedIndexChanged
            AddHandler _connectButton.Click, AddressOf ConnectButton_Click
        End Sub

        Private Sub ConnectButton_Click(sender As Object, e As EventArgs) Handles _connectButton.Click
            PopulateDatabaseComboBox()
        End Sub

        Private Function DataTableToString(dt As DataTable) As String
            Dim result As New StringBuilder()
            ' Add headers
            result.AppendLine(String.Join(vbTab, dt.Columns.Cast(Of DataColumn)().Select(Function(c) c.ColumnName)))
            ' Add rows
            For Each row As DataRow In dt.Rows
                result.AppendLine(String.Join(vbTab, row.ItemArray.Select(Function(item) If(item IsNot Nothing, item.ToString(), "NULL"))))
            Next
            Return result.ToString()
        End Function

        Private Async Function ExecuteQueryAsync(query As String, credentialTarget As String, server As String, database As String) As Task(Of SqlExecutionResult)
            Try
                _logger.LogInfo($"Executing query: {query}")
                _logger.LogInfo($"Server: {server}, Database: {database}, Credential: {credentialTarget}")

                Dim taskRunner = ApplicationContainer.GetService(Of TaskRunner)()
                If taskRunner Is Nothing Then
                    Throw New InvalidOperationException("taskRunner is not initialized.")
                End If

                ' Construct a proper connection string
                Dim connectionString = $"Server={server};Database={database};Integrated Security=True;"
                taskRunner.UpdateConnectionString(connectionString)

                ' Execute the query
                Return Await taskRunner.ExecuteQueryAsync(query, Nothing, credentialTarget)
            Catch ex As Exception
                _logger.LogError($"Error in ExecuteQueryAsync: {ex.Message}")
                _logger.LogError($"StackTrace: {ex.StackTrace}")
                Return New SqlExecutionResult With {
                    .Success = False,
                    .Message = $"Error executing query: {ex.Message}"
                }
            End Try
        End Function

        Public Function ExtractStoredProcedureName(sqlContent As String) As String
            sqlContent = sqlContent.Trim()

            If sqlContent.StartsWith("EXEC ", StringComparison.OrdinalIgnoreCase) Then
                sqlContent = sqlContent.Substring(5)
            ElseIf sqlContent.StartsWith("EXECUTE ", StringComparison.OrdinalIgnoreCase) Then
                sqlContent = sqlContent.Substring(8)
            End If

            If sqlContent.StartsWith("[") AndAlso sqlContent.Contains("]") Then
                sqlContent = sqlContent.Substring(1, sqlContent.IndexOf("]") - 1)
            End If

            Dim spaceIndex = sqlContent.IndexOf(" "c)
            Dim parenIndex = sqlContent.IndexOf("("c)

            If spaceIndex > 0 AndAlso parenIndex > 0 Then
                Return sqlContent.Substring(0, Math.Min(spaceIndex, parenIndex))
            ElseIf spaceIndex > 0 Then
                Return sqlContent.Substring(0, spaceIndex)
            ElseIf parenIndex > 0 Then
                Return sqlContent.Substring(0, parenIndex)
            End If

            Return sqlContent
        End Function

        Private Async Function ExecuteAndDisplayQuery(selectAll As Boolean, lastEntry As Boolean) As Task
            Try
                _logger.LogInfo("Starting query execution")
                If _outputTextBox Is Nothing Then
                    MessageBox.Show("Output TextBox is not initialized.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return
                End If

                _outputTextBox.Clear()

                If String.IsNullOrWhiteSpace(_queryTextBox.Text) Then
                    MessageBox.Show("Please enter a valid SQL query.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return
                End If

                Dim query = _queryTextBox.Text
                If Not query.Trim().ToUpper().StartsWith("SELECT") AndAlso (selectAll OrElse lastEntry) Then
                    MessageBox.Show("This option is only available for SELECT queries.", "Invalid Query", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                    Return
                End If

                Dim selectedCredential = If(_credentialComboBox?.SelectedItem?.ToString(), "(None)")
                Dim server = If(_serverTextBox?.Text, "XSQLVS1")
                Dim database = If(_databaseComboBox?.SelectedItem?.ToString(), "SIVTII")

                _logger.LogInfo($"Executing query on server: {server}, database: {database}, credential: {selectedCredential}")

                ' Execute the original query first
                Dim result = Await ExecuteQueryAsync(query, selectedCredential, server, database)

                If result.Success Then
                    If result.Data IsNot Nothing AndAlso result.Data.Rows.Count > 0 Then
                        Dim displayData As DataTable

                        If lastEntry Then
                            ' Create a new DataTable with just the last row
                            displayData = result.Data.Clone() ' This creates an empty DataTable with the same structure
                            displayData.Rows.Add(result.Data.Rows(result.Data.Rows.Count - 1).ItemArray)
                            _logger.LogInfo("Retrieved last entry successfully.")
                        Else
                            displayData = result.Data
                        End If

                        _outputTextBox.Text = DataTableToString(displayData)
                        _logger.LogInfo($"Query executed successfully. Rows returned: {displayData.Rows.Count}")

                        If selectAll Then
                            ' Offer to save as CSV
                            If MessageBox.Show("Would you like to save the results as a CSV file?", "Save Results", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = DialogResult.Yes Then
                                Await SaveResultsAsCsv(result.Data) ' Save all data, not just displayed data
                            End If
                        End If
                    Else
                        _outputTextBox.Text = "Query executed successfully, but no data was returned."
                        _logger.LogInfo("Query executed successfully, but no data was returned.")
                    End If
                Else
                    _outputTextBox.Text = result.Message
                    _logger.LogError($"Query execution failed: {result.Message}")
                End If
            Catch ex As Exception
                _outputTextBox.Text = "Error executing query: " & ex.Message
                _logger.LogError($"Error in ExecuteAndDisplayQuery: {ex.Message}")
                _logger.LogError($"StackTrace: {ex.StackTrace}")
            End Try
        End Function

        Public Function GetTabPage() As TabPage
            If Not _tabPageInitialized Then
                InitializeComponent()
                PopulateCredentialComboBox()
                PopulateDatabaseComboBox()
                PopulateQueryTypeComboBox()
                _tabPageInitialized = True
            End If
            Return _tabPage
        End Function

        Private Sub InitializeComponent()
            _tabPage = New TabPage("SQL")
            _tableLayoutPanel = New TableLayoutPanel()
            _tableLayoutPanel.Dock = DockStyle.Fill
            _tableLayoutPanel.ColumnCount = 3
            _tableLayoutPanel.RowCount = 8 ' Increased row count to accommodate new dropdown
            _tableLayoutPanel.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 20))
            _tableLayoutPanel.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 60))
            _tableLayoutPanel.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 20))

            ' Add rows with appropriate sizing
            _tableLayoutPanel.RowStyles.Add(New RowStyle(SizeType.Absolute, 30))  ' Server
            _tableLayoutPanel.RowStyles.Add(New RowStyle(SizeType.Absolute, 30))  ' Database
            _tableLayoutPanel.RowStyles.Add(New RowStyle(SizeType.Absolute, 30))  ' Query Type
            _tableLayoutPanel.RowStyles.Add(New RowStyle(SizeType.Absolute, 30))  ' Object List (new)
            _tableLayoutPanel.RowStyles.Add(New RowStyle(SizeType.Percent, 40))   ' Query
            _tableLayoutPanel.RowStyles.Add(New RowStyle(SizeType.Percent, 40))   ' Output
            _tableLayoutPanel.RowStyles.Add(New RowStyle(SizeType.Absolute, 30))  ' Credential
            _tableLayoutPanel.RowStyles.Add(New RowStyle(SizeType.Absolute, 40))  ' Run Button

            ' Server controls
            _serverTextBox = New TextBox With {
                .Dock = DockStyle.Fill
            }
            _connectButton = New Button With {
                .Text = "Connect",
                .Dock = DockStyle.Fill
            }

            ' Database control
            _databaseComboBox = New ComboBox With {
                .Dock = DockStyle.Fill,
                .DropDownStyle = ComboBoxStyle.DropDownList
            }

            ' Query Type control
            _queryTypeComboBox = New ComboBox With {
                .Dock = DockStyle.Fill,
                .DropDownStyle = ComboBoxStyle.DropDownList
            }

            ' Object List control (new)
            _objectListComboBox = New ComboBox With {
                .Dock = DockStyle.Fill,
                .DropDownStyle = ComboBoxStyle.DropDownList
            }

            ' Query control
            _queryTextBox = New TextBox With {
                .Multiline = True,
                .ScrollBars = ScrollBars.Vertical,
                .Dock = DockStyle.Fill
            }

            ' Output control
            _outputTextBox = New TextBox With {
                .Multiline = True,
                .ScrollBars = ScrollBars.Vertical,
                .Dock = DockStyle.Fill,
                .ReadOnly = True
            }

            ' Credential control
            _credentialComboBox = New ComboBox With {
                .Dock = DockStyle.Fill,
                .DropDownStyle = ComboBoxStyle.DropDownList
            }

            ' Select All Button
            _selectAllButton = New Button With {
                .Text = "Select All (Save as CSV)",
                .Dock = DockStyle.Fill
            }


            ' Return Last Entry Button
            _returnLastEntryButton = New Button With {
                .Text = "Return Last Entry",
                .Dock = DockStyle.Fill
            }

            ' Run Button
            _runButton = New Button With {
                .Text = "Run Query",
                .Dock = DockStyle.Fill,
                .Height = 30
            }

            ' Add controls to the TableLayoutPanel
            _tableLayoutPanel.Controls.Add(New Label With {.Text = "Server:", .Dock = DockStyle.Fill}, 0, 0)
            _tableLayoutPanel.Controls.Add(_serverTextBox, 1, 0)
            _tableLayoutPanel.Controls.Add(_connectButton, 2, 0)
            _tableLayoutPanel.Controls.Add(New Label With {.Text = "Database:", .Dock = DockStyle.Fill}, 0, 1)
            _tableLayoutPanel.Controls.Add(_databaseComboBox, 1, 1)
            _tableLayoutPanel.Controls.Add(New Label With {.Text = "Query Type:", .Dock = DockStyle.Fill}, 0, 2)
            _tableLayoutPanel.Controls.Add(_queryTypeComboBox, 1, 2)
            _tableLayoutPanel.Controls.Add(New Label With {.Text = "Object:", .Dock = DockStyle.Fill}, 0, 3)
            _tableLayoutPanel.Controls.Add(_objectListComboBox, 1, 3)
            _tableLayoutPanel.Controls.Add(New Label With {.Text = "Query:", .Dock = DockStyle.Fill}, 0, 4)
            _tableLayoutPanel.Controls.Add(_queryTextBox, 1, 4)
            _tableLayoutPanel.SetColumnSpan(_queryTextBox, 2)
            _tableLayoutPanel.Controls.Add(New Label With {.Text = "Output:", .Dock = DockStyle.Fill}, 0, 5)
            _tableLayoutPanel.Controls.Add(_outputTextBox, 1, 5)
            _tableLayoutPanel.SetColumnSpan(_outputTextBox, 2)
            _tableLayoutPanel.Controls.Add(New Label With {.Text = "Credential:", .Dock = DockStyle.Fill}, 0, 6)
            _tableLayoutPanel.Controls.Add(_credentialComboBox, 1, 6)
            _tableLayoutPanel.Controls.Add(_selectAllButton, 1, 7)
            _tableLayoutPanel.Controls.Add(_returnLastEntryButton, 2, 7)
            _tableLayoutPanel.Controls.Add(_runButton, 1, 8)
            _tabPage.Controls.Add(_tableLayoutPanel)

            ' Add event handlers
            AddHandlers()
        End Sub

        Private Sub ObjectListComboBox_SelectedIndexChanged(sender As Object, e As EventArgs)
            If _objectListComboBox.SelectedIndex > 0 Then
                Dim selectedObject As String = _objectListComboBox.SelectedItem.ToString()
                Dim queryType As String = _queryTypeComboBox.SelectedItem.ToString()

                Select Case queryType
                    Case "Table", "View"
                        _queryTextBox.Text = $"SELECT * FROM [{selectedObject}]"
                    Case "Stored Procedure"
                        _queryTextBox.Text = $"EXEC [{selectedObject}]"
                End Select
            End If
        End Sub

        Private Sub PopulateCredentialComboBox()
            _credentialComboBox.Items.Clear()
            _credentialComboBox.Items.Add("(None)")
            Dim targets = _credentialManager.GetAllCredentialTargets()
            For Each target In targets
                _credentialComboBox.Items.Add(target)
            Next
            _credentialComboBox.SelectedIndex = 0
        End Sub

        Private Sub PopulateDatabaseComboBox()
            _databaseComboBox.Items.Clear()
            _databaseComboBox.Items.Add("(Select a database)")

            Dim server As String = _serverTextBox.Text.Trim()
            If String.IsNullOrEmpty(server) Then
                _databaseComboBox.SelectedIndex = 0
                Return
            End If

            Dim connectionString As String = $"Server={server};Integrated Security=True;Connect Timeout=5"

            Try
                Using connection As New SqlConnection(connectionString)
                    connection.Open()

                    Dim command As New SqlCommand("SELECT name FROM sys.databases WHERE database_id > 4 ORDER BY name", connection)
                    Using reader As SqlDataReader = command.ExecuteReader()
                        While reader.Read()
                            _databaseComboBox.Items.Add(reader("name").ToString())
                        End While
                    End Using
                End Using

                If _databaseComboBox.Items.Count > 1 Then
                    _databaseComboBox.SelectedIndex = 0
                End If
            Catch ex As Exception
                MessageBox.Show($"Error connecting to server: {ex.Message}", "Connection Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                _logger?.LogError($"Error populating database list: {ex.Message}")
            End Try
        End Sub

        Private Sub PopulateObjectListComboBox()
            _objectListComboBox.Items.Clear()
            _objectListComboBox.Items.Add("(Select an object)")

            If _databaseComboBox.SelectedIndex <= 0 Then
                _objectListComboBox.SelectedIndex = 0
                Return
            End If

            Dim server As String = _serverTextBox.Text.Trim()
            Dim database As String = _databaseComboBox.SelectedItem.ToString()
            Dim queryType As String = _queryTypeComboBox.SelectedItem.ToString()

            Dim connectionString As String = $"Server={server};Database={database};Integrated Security=True;Connect Timeout=5"

            Try
                Using connection As New SqlConnection(connectionString)
                    connection.Open()

                    Dim query As String = ""
                    Select Case queryType
                        Case "Table"
                            query = "SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_TYPE = 'BASE TABLE' ORDER BY TABLE_NAME"
                        Case "View"
                            query = "SELECT TABLE_NAME FROM INFORMATION_SCHEMA.VIEWS ORDER BY TABLE_NAME"
                        Case "Stored Procedure"
                            query = "SELECT ROUTINE_NAME FROM INFORMATION_SCHEMA.ROUTINES WHERE ROUTINE_TYPE = 'PROCEDURE' ORDER BY ROUTINE_NAME"
                    End Select

                    If Not String.IsNullOrEmpty(query) Then
                        Dim command As New SqlCommand(query, connection)
                        Using reader As SqlDataReader = command.ExecuteReader()
                            While reader.Read()
                                _objectListComboBox.Items.Add(reader(0).ToString())
                            End While
                        End Using
                    End If
                End Using

                If _objectListComboBox.Items.Count > 1 Then
                    _objectListComboBox.SelectedIndex = 0
                End If
            Catch ex As Exception
                MessageBox.Show($"Error populating object list: {ex.Message}", "Population Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                _logger?.LogError($"Error populating object list: {ex.Message}")
            End Try
        End Sub

        Private Sub PopulateQueryTypeComboBox()
            If _queryTypeComboBox IsNot Nothing Then
                _queryTypeComboBox.Items.AddRange({"Select", "Table", "View", "Stored Procedure"})
                _queryTypeComboBox.SelectedIndex = 0
            End If
        End Sub

        Private Sub QueryTypeComboBox_SelectedIndexChanged(sender As Object, e As EventArgs)
            PopulateObjectListComboBox()
        End Sub

        Private Async Sub ReturnLastEntryButton_Click(sender As Object, e As EventArgs)
            Await ExecuteAndDisplayQuery(False, True)
        End Sub

        Private Async Sub RunButton_Click(sender As Object, e As EventArgs)
            Try
                _logger.LogInfo("Starting execution")

                If String.IsNullOrWhiteSpace(_queryTextBox.Text) Then
                    MessageBox.Show("Please enter a valid SQL query.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return
                End If

                Dim query = _queryTextBox.Text
                Dim selectedCredential = If(_credentialComboBox?.SelectedItem?.ToString(), "(None)")
                Dim server = If(_serverTextBox?.Text, "XSQLVS1")
                Dim database = If(_databaseComboBox?.SelectedItem?.ToString(), "SIVTII")

                _logger.LogInfo($"Executing query on server: {server}, database: {database}, credential: {selectedCredential}")

                Dim credential As CredentialInfo = Nothing
                If selectedCredential <> "(None)" Then
                    credential = _credentialManager.GetCredential(selectedCredential, "Windows Vault")
                End If

                Dim result As String
                ' Check if it's a stored procedure call
                If query.Trim().StartsWith("EXEC ", StringComparison.OrdinalIgnoreCase) OrElse
           query.Trim().StartsWith("EXECUTE ", StringComparison.OrdinalIgnoreCase) Then

                    _logger.LogInfo("Executing as stored procedure")
                    Dim spName = ExtractStoredProcedureName(query)
                    ' Use TaskRunner's implementation
                    result = Await _taskRunner.ExecuteStoredProcedureWithOSQL(spName, server, database, credential)
                Else
                    ' For regular queries, use the existing ExecuteQueryAsync method
                    Dim sqlResult = Await _taskRunner.ExecuteQueryAsync(query, Nothing, selectedCredential)
                    result = If(sqlResult.Success,
                       DataTableToString(sqlResult.Data),
                       $"Error executing query: {sqlResult.Message}")
                End If

                _outputTextBox.Text = result
                _logger.LogInfo("Execution completed successfully")

                ' Send email report if enabled
                If _xmlManager.GetEmailSettings()("NotificationsEnabled") = "True" Then
                    Dim emailSubject = "SQL Execution Report"
                    Dim emailBody = $"SQL execution completed.{Environment.NewLine}{Environment.NewLine}Output:{Environment.NewLine}{result}"
                    SendEmailReport(emailSubject, emailBody)
                End If

            Catch ex As Exception
                Dim errorMessage = $"Error during execution: {ex.Message}"
                _outputTextBox.Text = errorMessage
                _logger.LogError($"Error in RunButton_Click: {ex.Message}")
                _logger.LogError($"StackTrace: {ex.StackTrace}")

                ' Send error email report if enabled
                If _xmlManager.GetEmailSettings()("NotificationsEnabled") = "True" Then
                    Dim emailSubject = "ERROR: SQL Execution Failed"
                    Dim emailBody = $"SQL execution failed.{Environment.NewLine}{Environment.NewLine}Error:{Environment.NewLine}{errorMessage}"
                    SendEmailReport(emailSubject, emailBody)
                End If
            End Try
        End Sub

        Private Async Function SaveDataTableToCsvAsync(dataTable As DataTable, filePath As String) As Task
            Using writer As New StreamWriter(filePath, False, Encoding.UTF8)
                ' Write headers
                Await writer.WriteLineAsync(String.Join(",", dataTable.Columns.Cast(Of DataColumn).Select(Function(column) $"""{column.ColumnName}""")))

                ' Write rows
                For Each row As DataRow In dataTable.Rows
                    Await writer.WriteLineAsync(String.Join(",", row.ItemArray.Select(Function(field) $"""{field?.ToString().Replace("""", """""")}""")))
                Next
            End Using
        End Function

        Private Async Function SaveResultsAsCsv(data As DataTable) As Task
            Try
                Using saveFileDialog As New SaveFileDialog()
                    saveFileDialog.Filter = "CSV files (*.csv)|*.csv"
                    saveFileDialog.DefaultExt = "csv"
                    saveFileDialog.AddExtension = True

                    If saveFileDialog.ShowDialog() = DialogResult.OK Then
                        Await SaveDataTableToCsvAsync(data, saveFileDialog.FileName)
                        MessageBox.Show("Data saved successfully.", "Save Complete", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    End If
                End Using
            Catch ex As Exception
                MessageBox.Show($"Error saving CSV: {ex.Message}", "Save Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                _logger.LogError($"Error saving CSV: {ex.Message}")
            End Try
        End Function

        Private Async Sub SelectAllButton_Click(sender As Object, e As EventArgs)
            Await ExecuteAndDisplayQuery(True, False)
        End Sub

        Private Sub SendEmailReport(subject As String, body As String)
            _emailUtils.SendEmailReport(subject, body)
        End Sub

    End Class
End Namespace