Imports System.Timers

Namespace LiteTask
    Public Class LiteTaskService
        Inherits ServiceBase
        Private WithEvents _timer As Timer
        Private _customScheduler As CustomScheduler
        Private _credentialManager As CredentialManager
        Private _xmlManager As XMLManager
        Private _logger As Logger
        Private ReadOnly _toolManager As ToolManager

        Private Const SC_MANAGER_ALL_ACCESS As Integer = &HF003F
        Private Const SERVICE_ALL_ACCESS As Integer = &HF01FF
        Private Const SC_STATUS_PROCESS_INFO As Integer = 0
        Private Const PROCESS_ALL_ACCESS As Integer = &H1F0FFF
        Private Const TOKEN_ADJUST_PRIVILEGES As Integer = &H20
        Private Const TOKEN_QUERY As Integer = &H8
        Private Const SE_PRIVILEGE_ENABLED As Integer = &H2
        Private Const SE_IMPERSONATE_NAME As String = "SeImpersonatePrivilege"
        Private Const ERROR_NOT_ALL_ASSIGNED As Integer = 1300

        <DllImport("advapi32.dll", SetLastError:=True, CharSet:=CharSet.Unicode)>
        Public Shared Function OpenService(hSCManager As IntPtr, lpServiceName As String, dwDesiredAccess As Integer) As IntPtr
        End Function

        <DllImport("advapi32.dll", SetLastError:=True)>
        Private Shared Function QueryServiceStatusEx(hService As IntPtr, infoLevel As Integer, ByRef lpBuffer As SERVICE_STATUS_PROCESS, dwBufSize As Integer, ByRef pcbBytesNeeded As Integer) As Boolean
        End Function

        <DllImport("advapi32.dll", SetLastError:=True, CharSet:=CharSet.Auto)>
        Private Shared Function OpenProcessToken(ByVal ProcessHandle As IntPtr, ByVal DesiredAccess As Integer, ByRef TokenHandle As IntPtr) As Boolean
        End Function

        <DllImport("kernel32.dll", SetLastError:=True)>
        Private Shared Function OpenProcess(ByVal dwDesiredAccess As Integer, ByVal bInheritHandle As Boolean, ByVal dwProcessId As Integer) As IntPtr
        End Function
        <DllImport("kernel32.dll", SetLastError:=True)>
        Private Shared Function CloseHandle(hObject As IntPtr) As Boolean
        End Function

        <DllImport("advapi32.dll", SetLastError:=True, CharSet:=CharSet.Unicode)>
        Private Shared Function OpenSCManager(
        ByVal machineName As String,
        ByVal databaseName As String,
        ByVal desiredAccess As Integer
    ) As IntPtr
        End Function

        <DllImport("advapi32.dll", SetLastError:=True, CharSet:=CharSet.Unicode)>
        Private Shared Function LookupPrivilegeValue(
        ByVal lpSystemName As String,
        ByVal lpName As String,
        ByRef lpLuid As LUID
    ) As Boolean
        End Function

        <DllImport("advapi32.dll", SetLastError:=True)>
        Private Shared Function AdjustTokenPrivileges(
        ByVal TokenHandle As IntPtr,
        ByVal DisableAllPrivileges As Boolean,
        ByRef NewState As TOKEN_PRIVILEGES,
        ByVal BufferLength As Integer,
        ByRef PreviousState As TOKEN_PRIVILEGES,
        ByRef ReturnLength As Integer
    ) As Boolean
        End Function

        <StructLayout(LayoutKind.Sequential)>
        Private Structure LUID
            Public LowPart As UInteger
            Public HighPart As Integer
        End Structure

        <StructLayout(LayoutKind.Sequential)>
        Private Structure TOKEN_PRIVILEGES
            Public PrivilegeCount As Integer
            Public Privileges As LUID_AND_ATTRIBUTES
            Public Luid As LUID
            Public Attributes As UInteger
        End Structure


        <StructLayout(LayoutKind.Sequential)>
        Private Structure SERVICE_STATUS_PROCESS
            Public dwServiceType As Integer
            Public dwCurrentState As Integer
            Public dwControlsAccepted As Integer
            Public dwWin32ExitCode As Integer
            Public dwServiceSpecificExitCode As Integer
            Public dwCheckPoint As Integer
            Public dwWaitHint As Integer
            Public dwProcessId As Integer
            Public dwServiceFlags As Integer
        End Structure


        <StructLayout(LayoutKind.Sequential)>
        Private Structure LUID_AND_ATTRIBUTES
            Public Luid As LUID
            Public Attributes As Integer
        End Structure

        Public Sub New(customScheduler As CustomScheduler, credentialManager As CredentialManager, xmlManager As XMLManager, toolManager As ToolManager)
            InitializeComponent()
            _customScheduler = customScheduler
            _credentialManager = credentialManager
            _xmlManager = xmlManager
            _logger = ApplicationContainer.GetService(Of Logger)()
            _toolManager = toolManager
        End Sub

        Private Sub EnsureElevatedPrivileges()
            If Not IsUserAdmin() Then
                Dim result = MessageBox.Show("This operation requires elevated privileges. Do you want to restart the application with administrator rights?", "Elevation Required", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                If result = DialogResult.Yes Then
                    RestartAsAdmin()
                Else
                    Throw New UnauthorizedAccessException("This operation requires elevated privileges.")
                End If
            End If
        End Sub

        Private Sub EnsureImpersonationRights()
            Try
                Dim identity = WindowsIdentity.GetCurrent()
                Dim principal = New WindowsPrincipal(identity)

                If Not principal.IsInRole(WindowsBuiltInRole.Administrator) Then
                    _logger.LogWarning("Service is not running with administrative privileges. Impersonation may fail.")
                End If

                ' You might need to add more specific checks here depending on your Windows environment
                ' For example, checking for specific privileges like SE_IMPERSONATE_NAME

            Catch ex As Exception
                _logger.LogError($"Error checking impersonation rights: {ex.Message}")
            End Try
        End Sub

        Public Sub EnsureRequiredPermissions()
            Try
                Dim identity = WindowsIdentity.GetCurrent()
                Dim principal = New WindowsPrincipal(identity)

                If Not principal.IsInRole(WindowsBuiltInRole.Administrator) Then
                    Throw New UnauthorizedAccessException("The application requires administrative privileges.")
                End If

                If Not HasImpersonatePrivilege() Then
                    RequestImpersonatePrivilege()
                End If

            Catch ex As Exception
                MessageBox.Show($"Error: {ex.Message}{Environment.NewLine}Please run the application as an administrator and ensure it has the necessary permissions in Local Security Policy.", "Insufficient Permissions", MessageBoxButtons.OK, MessageBoxIcon.Error)
                ShowManualInstructions()
                Environment.Exit(1)
            End Try
        End Sub

        Private Sub GrantServiceImpersonatePrivilege(serviceName As String)
            Const SE_PRIVILEGE_ENABLED As Integer = &H2
            Const SE_IMPERSONATE_NAME As String = "SeImpersonatePrivilege"

            Try
                ' Open the service
                Dim scManager = OpenSCManager(Nothing, Nothing, SC_MANAGER_ALL_ACCESS)
                If scManager = IntPtr.Zero Then
                    Throw New ComponentModel.Win32Exception(Marshal.GetLastWin32Error())
                End If

                Dim service = OpenService(scManager, serviceName, SERVICE_ALL_ACCESS)
                If service = IntPtr.Zero Then
                    Throw New ComponentModel.Win32Exception(Marshal.GetLastWin32Error())
                End If

                ' Get the service process ID
                Dim serviceStatus As New SERVICE_STATUS_PROCESS()
                Dim bytesNeeded As UInteger
                If Not QueryServiceStatusEx(service, SC_STATUS_PROCESS_INFO, serviceStatus, Marshal.SizeOf(serviceStatus), bytesNeeded) Then
                    Throw New ComponentModel.Win32Exception(Marshal.GetLastWin32Error())
                End If

                ' Open the service process
                Dim processHandle = OpenProcess(PROCESS_ALL_ACCESS, False, serviceStatus.dwProcessId)
                If processHandle = IntPtr.Zero Then
                    Throw New ComponentModel.Win32Exception(Marshal.GetLastWin32Error())
                End If

                ' Get the process token
                Dim tokenHandle As IntPtr
                If Not OpenProcessToken(processHandle, TOKEN_ADJUST_PRIVILEGES Or TOKEN_QUERY, tokenHandle) Then
                    Throw New System.ComponentModel.Win32Exception(Marshal.GetLastWin32Error())
                End If

                ' Enable the SeImpersonatePrivilege
                Dim tp As New TOKEN_PRIVILEGES()
                tp.PrivilegeCount = 1
                tp.Privileges.Attributes = SE_PRIVILEGE_ENABLED
                If Not LookupPrivilegeValue(Nothing, SE_IMPERSONATE_NAME, tp.Privileges.Luid) Then
                    Throw New Win32Exception(Marshal.GetLastWin32Error())
                End If

                Dim previousState As TOKEN_PRIVILEGES
                Dim returnLength As Integer

                If Not AdjustTokenPrivileges(tokenHandle, False, tp, Marshal.SizeOf(tp), previousState, returnLength) Then
                    Throw New Win32Exception(Marshal.GetLastWin32Error())
                End If

                ' Check if the privilege was actually adjusted
                If Marshal.GetLastWin32Error() = ERROR_NOT_ALL_ASSIGNED Then
                    Throw New Win32Exception(ERROR_NOT_ALL_ASSIGNED, "The token does not have the specified privilege.")
                End If

                _logger.LogInfo($"SeImpersonatePrivilege granted to service: {serviceName}")
            Catch ex As Exception
                _logger.LogError($"Failed to grant SeImpersonatePrivilege to service {serviceName}: {ex.Message}")
                Throw
            End Try
        End Sub

        Private Function HasImpersonatePrivilege() As Boolean
            Dim tokenHandle As IntPtr = IntPtr.Zero
            Try
                If Not OpenProcessToken(Process.GetCurrentProcess().Handle, TOKEN_QUERY, tokenHandle) Then
                    Return False
                End If

                Dim tp As New TOKEN_PRIVILEGES()
                Dim luid As New LUID()

                If Not LookupPrivilegeValue(Nothing, SE_IMPERSONATE_NAME, luid) Then
                    Return False
                End If

                tp.PrivilegeCount = 1
                tp.Luid = luid
                tp.Attributes = SE_PRIVILEGE_ENABLED

                Dim retLength As Integer = 0
                Dim result = AdjustTokenPrivileges(tokenHandle, False, tp, Marshal.SizeOf(tp), Nothing, retLength)

                Return result AndAlso Marshal.GetLastWin32Error() = 0
            Finally
                If tokenHandle <> IntPtr.Zero Then
                    CloseHandle(tokenHandle)
                End If
            End Try
        End Function

        Private Sub InitializeComponent()
            ServiceName = "LiteTaskService"
            CanStop = True
            CanPauseAndContinue = False
            AutoLog = True
        End Sub


        Private Function IsUserAdmin() As Boolean
            Dim identity = WindowsIdentity.GetCurrent()
            Dim principal = New WindowsPrincipal(identity)
            Return principal.IsInRole(WindowsBuiltInRole.Administrator)
        End Function

        Protected Overrides Sub OnStart(ByVal args() As String)
            _logger.LogInfo("LiteTaskService is starting.")

            ' Ensure the service has the necessary rights for impersonation
            EnsureImpersonationRights()

            _customScheduler.LoadTasks()
            _timer = New Timer(60000) ' Check every minute
            AddHandler _timer.Elapsed, AddressOf Timer_Elapsed
            _timer.Start()
            _logger.LogInfo("LiteTaskService started successfully.")
        End Sub

        Protected Overrides Sub OnStop()
            _logger.LogInfo("LiteTaskService is stopping.")
            If _timer IsNot Nothing Then
                _timer.Stop()
                RemoveHandler _timer.Elapsed, AddressOf Timer_Elapsed
            End If
            _customScheduler.SaveTasks()
            _logger.LogInfo("LiteTaskService stopped successfully.")
        End Sub

        Private Sub RequestImpersonatePrivilege()
            Dim tokenHandle As IntPtr = IntPtr.Zero
            Try
                If Not OpenProcessToken(Process.GetCurrentProcess().Handle, TOKEN_ADJUST_PRIVILEGES Or TOKEN_QUERY, tokenHandle) Then
                    Throw New Win32Exception(Marshal.GetLastWin32Error())
                End If

                Dim tp As New TOKEN_PRIVILEGES()
                Dim luid As New LUID()

                If Not LookupPrivilegeValue(Nothing, SE_IMPERSONATE_NAME, luid) Then
                    Throw New Win32Exception(Marshal.GetLastWin32Error())
                End If

                tp.PrivilegeCount = 1
                tp.Luid = luid
                tp.Attributes = SE_PRIVILEGE_ENABLED

                If Not AdjustTokenPrivileges(tokenHandle, False, tp, 0, Nothing, 0) Then
                    Throw New Win32Exception(Marshal.GetLastWin32Error())
                End If

                If Marshal.GetLastWin32Error() <> 0 Then
                    Throw New Win32Exception(Marshal.GetLastWin32Error())
                End If
            Finally
                If tokenHandle <> IntPtr.Zero Then
                    CloseHandle(tokenHandle)
                End If
            End Try
        End Sub

        Private Sub RestartAsAdmin()
            Dim startInfo As New ProcessStartInfo() With {
        .UseShellExecute = True,
        .WorkingDirectory = Environment.CurrentDirectory,
        .FileName = Application.ExecutablePath,
        .Verb = "runas"
    }

            Try
                Process.Start(startInfo)
            Catch ex As Exception
                MessageBox.Show("Failed to restart with elevated privileges.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try

            Application.Exit()
        End Sub

        Private Sub ShowManualInstructions()
            Dim instructions As String = "To manually grant the required permissions:" & Environment.NewLine & Environment.NewLine &
                "1. Open 'Local Security Policy' (secpol.msc)" & Environment.NewLine &
                "2. Navigate to 'Local Policies' > 'User Rights Assignment'" & Environment.NewLine &
                "3. Double-click on 'Impersonate a client after authentication'" & Environment.NewLine &
                "4. Add the user or group that will run this application" & Environment.NewLine &
                "5. Restart the application"

            MessageBox.Show(instructions, "Manual Permission Instructions", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End Sub

        Private Sub Timer_Elapsed(sender As Object, e As ElapsedEventArgs)
            Try
                _customScheduler.CheckAndExecuteTasks()
            Catch ex As Exception
                _logger.LogError($"Error in Timer_Elapsed: {ex.Message}")
                EventLog.WriteEntry("LiteTaskService", $"Error in Timer_Elapsed: {ex.Message}", EventLogEntryType.Error)
            End Try
        End Sub

    End Class
End Namespace
