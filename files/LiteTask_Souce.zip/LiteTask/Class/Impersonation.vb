Namespace LiteTask
    Public Class Impersonation
        Private Const LOGON32_LOGON_INTERACTIVE As Integer = 2
        Private Const LOGON32_PROVIDER_DEFAULT As Integer = 0
        Private Const TOKEN_DUPLICATE As Integer = &H2
        Private Const TOKEN_QUERY As Integer = &H8
        Private Const TOKEN_ADJUST_DEFAULT As Integer = &H80
        Private Const TOKEN_ASSIGN_PRIMARY As Integer = &H1
        Private Const TOKEN_ALL_ACCESS As Integer = &HF01FF

        <DllImport("advapi32.dll", SetLastError:=True, CharSet:=CharSet.Unicode)>
        Private Shared Function LogonUser(lpszUsername As String, lpszDomain As String, lpszPassword As String, dwLogonType As Integer, dwLogonProvider As Integer, ByRef phToken As IntPtr) As Boolean
        End Function

        <DllImport("kernel32.dll", CharSet:=CharSet.Auto)>
        Private Shared Function CloseHandle(handle As IntPtr) As Boolean
        End Function

        <DllImport("advapi32.dll", SetLastError:=True, CharSet:=CharSet.Unicode)>
        Private Shared Function CreateProcessWithLogonW(
            userName As String,
            domain As String,
            password As String,
            logonFlags As Integer,
            applicationName As String,
            commandLine As String,
            creationFlags As Integer,
            environment As IntPtr,
            currentDirectory As String,
            ByRef startupInfo As STARTUPINFO,
            ByRef processInformation As PROCESS_INFORMATION) As Boolean
        End Function

        <StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Unicode)>
        Private Structure PROFILEINFO
            Public dwSize As UInteger
            Public dwFlags As UInteger
            Public lpUserName As String
            Public lpProfilePath As String
            Public lpDefaultPath As String
            Public lpServerName As String
            Public lpPolicyPath As String
            Public hProfile As IntPtr
        End Structure

        <StructLayout(LayoutKind.Sequential)>
        Private Structure PROCESS_INFORMATION
            Public hProcess As IntPtr
            Public hThread As IntPtr
            Public dwProcessId As Integer
            Public dwThreadId As Integer
        End Structure


        <StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Unicode)>
        Private Structure STARTUPINFO
            Public cb As Integer
            Public lpReserved As String
            Public lpDesktop As String
            Public lpTitle As String
            Public dwX As Integer
            Public dwY As Integer
            Public dwXSize As Integer
            Public dwYSize As Integer
            Public dwXCountChars As Integer
            Public dwYCountChars As Integer
            Public dwFillAttribute As Integer
            Public dwFlags As Integer
            Public wShowWindow As Short
            Public cbReserved2 As Short
            Public lpReserved2 As IntPtr
            Public hStdInput As IntPtr
            Public hStdOutput As IntPtr
            Public hStdError As IntPtr
        End Structure

        Private Const LOGON_WITH_PROFILE As Integer = 1
        Private Const CREATE_UNICODE_ENVIRONMENT As Integer = &H400
        Private ReadOnly _credentialManager As CredentialManager
        Private ReadOnly _logger As Logger
        Private ReadOnly _toolsPath As String

        Public Sub New(credentialManager As CredentialManager, logger As Logger, toolsPath As String)
            _credentialManager = credentialManager
            _logger = logger
            _toolsPath = toolsPath
        End Sub

        Public Function CreateProcessAsImpersonatedUser(username As String, domain As String, password As String, applicationName As String, commandLine As String, Optional workingDirectory As String = Nothing) As Boolean
            Try
                _logger.LogInfo($"Attempting to create process as user: {username}")

                Dim liteRunPath = Path.Combine(_toolsPath, "LiteRun.exe")
                If Not File.Exists(liteRunPath) Then
                    Throw New FileNotFoundException("LiteRun.exe not found in tools directory", liteRunPath)
                End If

                Dim tempLogFile = Path.GetTempFileName()

                Dim arguments = $"-u {username} -p {password} "
                If Not String.IsNullOrEmpty(domain) Then
                    arguments += $"-d {domain} "
                End If
                arguments += $"-lo ""{tempLogFile}"" "
                If Not String.IsNullOrEmpty(workingDirectory) Then
                    arguments += $"-w ""{workingDirectory}"" "
                End If
                arguments += $"""{applicationName}"" {commandLine}"

                Dim startInfo = New ProcessStartInfo(liteRunPath, arguments) With {
                    .UseShellExecute = False,
                    .CreateNoWindow = True
                }

                Using process As New Process()
                    process.StartInfo = startInfo
                    process.Start()
                    process.WaitForExit()

                    Dim output = File.ReadAllText(tempLogFile)
                    File.Delete(tempLogFile)

                    _logger.LogInfo($"LiteRun output: {output}")

                    If process.ExitCode = 0 Then
                        _logger.LogInfo($"Successfully executed process as user: {username}")
                        Return True
                    Else
                        _logger.LogError($"LiteRun exited with code: {process.ExitCode}")
                        Return False
                    End If
                End Using
            Catch ex As Exception
                _logger.LogError($"Error creating process as user {username}: {ex.Message}")
                Return False
            End Try
        End Function

        Public Function ExecutePowerShellScriptAsUser(username As String, domain As String, password As String, scriptPath As String, arguments As String) As Boolean
            Dim powershellPath = "powershell.exe"
            Dim commandLine = $"-ExecutionPolicy Bypass -File ""{scriptPath}"" {arguments}"
            Return CreateProcessAsImpersonatedUser(username, domain, password, powershellPath, commandLine)
        End Function

        Public Function ExecuteSqlAsUser(username As String, domain As String, password As String, sqlQuery As String, serverName As String, databaseName As String) As Boolean
            Dim osqlPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), "osql.exe")
            Dim commandLine = $"-S {serverName} -d {databaseName} -Q ""{sqlQuery}"" -E"
            Return CreateProcessAsImpersonatedUser(username, domain, password, osqlPath, commandLine)
        End Function

    End Class

End Namespace