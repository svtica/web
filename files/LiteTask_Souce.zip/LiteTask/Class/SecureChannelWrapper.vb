Imports System.Net.Security
Imports System.Security.Cryptography.X509Certificates

Namespace LiteTask

    Public Class SecureChannelWrapper
        Private ReadOnly _certificateValidator As Func(Of X509Certificate, X509Chain, SslPolicyErrors, Boolean)
        Private _logger As Logger
        Private _sslStreams As New Dictionary(Of String, SslStream)


        Public Sub New(logger As Logger)
            _logger = logger
            ' Create a new function that captures the logger and passes it to CustomCertificateValidator
            Dim certificateValidator As Func(Of X509Certificate, X509Chain, SslPolicyErrors, Boolean) =
        Function(cert, chain, errors) CustomCertificateValidator(logger, cert, chain, errors)

            _certificateValidator = certificateValidator
        End Sub

        Public Shared Function CustomCertificateValidator(logger As Logger, certificate As X509Certificate, chain As X509Chain, sslPolicyErrors As SslPolicyErrors) As Boolean
            Try
                ' Use the provided logger
                If sslPolicyErrors = SslPolicyErrors.None Then
                    Return True ' Certificate is valid
                End If

                ' Check for specific policy errors
                If (sslPolicyErrors And SslPolicyErrors.RemoteCertificateNameMismatch) <> 0 Then
                    logger.LogWarning("Certificate name mismatch.")
                    Return False
                End If

                If (sslPolicyErrors And SslPolicyErrors.RemoteCertificateNotAvailable) <> 0 Then
                    logger.LogWarning("Remote certificate not available.")
                    Return False
                End If

                ' Validate certificate chain
                If Not chain.Build(New X509Certificate2(certificate)) Then
                    For Each status In chain.ChainStatus
                        If status.Status <> X509ChainStatusFlags.RevocationStatusUnknown Then
                            chain.ChainPolicy.RevocationFlag = X509RevocationFlag.EntireChain
                            chain.ChainPolicy.RevocationMode = X509RevocationMode.Online
                            chain.ChainPolicy.UrlRetrievalTimeout = New TimeSpan(0, 1, 0)
                            chain.ChainPolicy.VerificationFlags = X509VerificationFlags.AllFlags
                            If Not chain.Build(New X509Certificate2(certificate)) Then
                                logger.LogWarning($"Certificate chain validation failed: {status.StatusInformation}")
                                Return False
                            End If
                        End If
                    Next
                End If

                Return True ' Certificate passed all checks
            Catch ex As Exception
                logger.LogError($"Error validating server certificate: {ex.Message}")
                Return False
            End Try
        End Function

    End Class

End Namespace