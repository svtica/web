Imports System.Security.Cryptography

Namespace LiteTask
    Public Class CredentialManager
        Private ReadOnly _logger As Logger
        Private ReadOnly _storedCredentialsPath As String
        Private _userToken As IntPtr = IntPtr.Zero

        ' Windows API structures and functions
        <StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Unicode)>
        Private Structure CREDENTIAL
            Public Flags As UInteger
            Public Type As UInteger
            Public TargetName As String
            Public Comment As String
            Public LastWritten As System.Runtime.InteropServices.ComTypes.FILETIME
            Public CredentialBlobSize As UInteger
            Public CredentialBlob As IntPtr
            Public Persist As UInteger
            Public AttributeCount As UInteger
            Public Attributes As IntPtr
            Public TargetAlias As String
            Public UserName As String
        End Structure

        Private Const CRED_TYPE_GENERIC As Integer = 1
        Private Const CRED_PERSIST_LOCAL_MACHINE As Integer = 2

        Public Enum ServiceAccountType
            LocalSystem
            LocalService
            NetworkService
        End Enum


        <DllImport("Advapi32.dll", SetLastError:=True, EntryPoint:="CredReadW", CharSet:=CharSet.Unicode)>
        Private Shared Function CredRead(target As String, type As Integer, reservedFlag As Integer, ByRef credentialPtr As IntPtr) As Boolean
        End Function

        <DllImport("Advapi32.dll", SetLastError:=True, EntryPoint:="CredWriteW", CharSet:=CharSet.Unicode)>
        Private Shared Function CredWrite(ByRef credential As CREDENTIAL, flags As Integer) As Boolean
        End Function

        <DllImport("Advapi32.dll", SetLastError:=True, EntryPoint:="CredFree")>
        Private Shared Sub CredFree(cred As IntPtr)
        End Sub

        <DllImport("Advapi32.dll", SetLastError:=True, EntryPoint:="CredDeleteW", CharSet:=CharSet.Unicode)>
        Private Shared Function CredDelete(target As String, type As Integer, flags As Integer) As Boolean
        End Function

        <DllImport("Advapi32.dll", SetLastError:=True, EntryPoint:="CredEnumerateW", CharSet:=CharSet.Unicode)>
        Private Shared Function CredEnumerate(filter As String, flags As Integer, ByRef count As Integer, ByRef credentials As IntPtr) As Boolean
        End Function

        Private Const LOGON32_LOGON_INTERACTIVE As Integer = 2
        Private Const LOGON32_PROVIDER_DEFAULT As Integer = 0

        Public Sub New(logger As Logger)
            _logger = logger
            _storedCredentialsPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "LiteTask", "StoredCredentials.dat")
            EnsureDirectoryExists(Path.GetDirectoryName(_storedCredentialsPath))
        End Sub

        Private Function DecryptString(encryptedInput As String) As String
            Dim entropy As Byte() = Encoding.Unicode.GetBytes("LiteTaskApplicationSpecificEntropy")
            Dim decryptedData As Byte() = ProtectedData.Unprotect(Convert.FromBase64String(encryptedInput), entropy, DataProtectionScope.CurrentUser)
            Return Encoding.Unicode.GetString(decryptedData)
        End Function

        Public Function GetAllCredentialTargets() As List(Of String)
            Dim targets As New List(Of String)

            ' Add system accounts
            targets.Add("(Service Account, NT AUTHORITY\SYSTEM)")
            targets.Add("(Service Account, NT AUTHORITY\LOCAL SERVICE)")
            targets.Add("(Service Account, NT AUTHORITY\NETWORK SERVICE)")

            ' Get Current User credentials
            Dim regKey = Registry.CurrentUser.OpenSubKey("SOFTWARE\LiteTask\Credentials")
            If regKey IsNot Nothing Then
                For Each target In regKey.GetValueNames()
                    targets.Add($"(Current User, {target})")
                Next
            End If

            ' Get Service Account credentials
            Dim serviceFilePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "ServiceCredentials.dat")
            If File.Exists(serviceFilePath) Then
                For Each line In File.ReadAllLines(serviceFilePath)
                    Dim parts = line.Split("|"c)
                    If parts.Length >= 1 Then
                        targets.Add($"(Service Account, {parts(0)})")
                    End If
                Next
            End If

            ' Get Windows Vault credentials
            Dim count As Integer = 0
            Dim pCredentials As IntPtr = IntPtr.Zero
            If CredEnumerate(Nothing, 0, count, pCredentials) Then
                Dim credentialPtrs(count - 1) As IntPtr
                Marshal.Copy(pCredentials, credentialPtrs, 0, count)
                For i As Integer = 0 To count - 1
                    Dim credential As CREDENTIAL = Marshal.PtrToStructure(Of CREDENTIAL)(credentialPtrs(i))
                    If credential.Type = CRED_TYPE_GENERIC Then
                        targets.Add($"(Windows Vault, {credential.TargetName})")
                    End If
                Next
                CredFree(pCredentials)
            End If

            ' Get Stored Account credentials
            Dim storedFilePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "StoredCredentials.dat")
            If File.Exists(storedFilePath) Then
                For Each line In File.ReadAllLines(storedFilePath)
                    Dim parts = line.Split("|"c)
                    If parts.Length >= 1 Then
                        targets.Add($"(Stored Account, {parts(0)})")
                    End If
                Next
            End If

            Return targets
        End Function

        Public Sub DeleteCredential(target As String, accountType As String)
            Try
                Select Case accountType.ToLower()
                    Case "windows vault"
                        DeleteFromWindowsVault(target)
                    Case "stored account"
                        DeleteStoredCredential(target)
                    Case "current user"
                        DeleteCurrentUserCredential(target)
                    Case "service account"
                        ' For service accounts, you might not need to delete anything
                        ' or you might have a special handling
                    Case Else
                        Throw New ArgumentException("Invalid account type", NameOf(accountType))
                End Select
                _logger.LogInfo($"Credential deleted successfully for target: {target}, account type: {accountType}")
            Catch ex As Exception
                _logger.LogError($"Error deleting credential: {ex.Message}")
                Throw
            End Try
        End Sub

        Private Sub DeleteCurrentUserCredential(target As String)
            Dim regKey = Microsoft.Win32.Registry.CurrentUser.OpenSubKey("SOFTWARE\LiteTask\Credentials", True)
            regKey?.DeleteValue(target, False)
        End Sub
        Private Sub DeleteFromWindowsVault(target As String)
            If Not CredDelete(target, CRED_TYPE_GENERIC, 0) Then
                Throw New Win32Exception(Marshal.GetLastWin32Error())
            End If
        End Sub

        Private Sub DeleteStoredCredential(target As String)
            If File.Exists(_storedCredentialsPath) Then
                Dim lines = File.ReadAllLines(_storedCredentialsPath).Where(Function(line) Not line.StartsWith(target & "|")).ToArray()
                File.WriteAllLines(_storedCredentialsPath, lines)
            End If
        End Sub

        Private Function EncryptString(input As String) As String
            Dim entropy As Byte() = Encoding.Unicode.GetBytes("LiteTaskApplicationSpecificEntropy")
            Dim encryptedData As Byte() = ProtectedData.Protect(Encoding.Unicode.GetBytes(input), entropy, DataProtectionScope.CurrentUser)
            Return Convert.ToBase64String(encryptedData)
        End Function

        Private Sub EnsureDirectoryExists(path As String)
            If Not Directory.Exists(path) Then
                Directory.CreateDirectory(path)
            End If
        End Sub

        Public Function GetCredential(target As String, accountType As String) As CredentialInfo
            Try
                ' Split the target if it's in the format "(AccountType, Target)"
                Dim parts = target.Trim("()".ToCharArray()).Split(",")
                If parts.Length = 2 Then
                    accountType = parts(0).Trim()
                    target = parts(1).Trim()
                End If

                ' Try different methods to retrieve the credential
                Dim credential As CredentialInfo = Nothing

                ' Method 1: Windows Vault
                credential = GetFromWindowsVault(target)
                If credential IsNot Nothing Then
                    Return credential
                End If

                ' Method 2: Stored Account
                credential = GetStoredCredential(target)
                If credential IsNot Nothing Then
                    Return credential
                End If

                ' Method 3: Current User (Registry)
                credential = GetCurrentUserCredential(target)
                If credential IsNot Nothing Then
                    Return credential
                End If

                ' Method 4: Service Account
                If accountType.Equals("Service Account", StringComparison.OrdinalIgnoreCase) Then
                    Return GetServiceAccountCredential(target)
                End If

                _logger.LogWarning($"No credential found for target: {target}")
                Return Nothing
            Catch ex As Exception
                _logger.LogError($"Error getting credential: {ex.Message}")
                Return Nothing
            End Try
        End Function

        Private Function GetCurrentUserCredential(target As String) As CredentialInfo
            Try
                Dim regKey = Microsoft.Win32.Registry.CurrentUser.OpenSubKey("SOFTWARE\LiteTask\Credentials")
                Dim value = TryCast(regKey?.GetValue(target), String)
                If value IsNot Nothing Then
                    Dim parts = value.Split("|"c)
                    If parts.Length = 2 Then
                        Return New CredentialInfo() With {
                            .Target = target,
                            .Username = parts(0),
                            .Password = DecryptString(parts(1)),
                            .AccountType = "Current User",
                            .SecurePassword = New NetworkCredential("", DecryptString(parts(1))).SecurePassword
                        }
                    End If
                End If
                Return Nothing
            Catch ex As Exception
                _logger.LogError($"Error getting current user credential: {ex.Message}")
                Return Nothing
            End Try
        End Function

        Private Function GetFromWindowsVault(target As String) As CredentialInfo
            Dim credentialPtr As IntPtr = IntPtr.Zero
            Try
                If Not CredRead(target, CRED_TYPE_GENERIC, 0, credentialPtr) Then
                    Return Nothing
                End If

                Dim credential As CREDENTIAL = Marshal.PtrToStructure(Of CREDENTIAL)(credentialPtr)
                If credential.CredentialBlobSize = 0 OrElse credential.CredentialBlob = IntPtr.Zero Then
                    Return Nothing
                End If

                Dim passwordBytes(credential.CredentialBlobSize - 1) As Byte
                Marshal.Copy(credential.CredentialBlob, passwordBytes, 0, credential.CredentialBlobSize)
                Dim password As String = Encoding.Unicode.GetString(passwordBytes)

                Return New CredentialInfo() With {
                    .Target = target,
                    .Username = credential.UserName,
                    .Password = password,
                    .AccountType = "Windows Vault",
                    .SecurePassword = New NetworkCredential("", password).SecurePassword
                    }
            Catch ex As Exception
                _logger.LogError($"Error reading credential from Windows Vault: {ex.Message}")
                Return Nothing
            Finally
                If credentialPtr <> IntPtr.Zero Then
                    CredFree(credentialPtr)
                End If
            End Try
        End Function

        Private Function GetStoredCredential(target As String) As CredentialInfo
            Try
                If File.Exists(_storedCredentialsPath) Then
                    For Each line In File.ReadAllLines(_storedCredentialsPath)
                        Dim parts = line.Split("|"c)
                        If parts.Length = 3 AndAlso parts(0) = target Then
                            Return New CredentialInfo() With {
                                .Target = parts(0),
                                .Username = parts(1),
                                .Password = DecryptString(parts(2)),
                                .AccountType = "Stored Account",
                                .SecurePassword = New NetworkCredential("", DecryptString(parts(2))).SecurePassword
                                 }
                        End If
                    Next
                End If
                Return Nothing
            Catch ex As Exception
                _logger.LogError($"Error getting stored credential: {ex.Message}")
                Return Nothing
            End Try
        End Function

        Public Function GetServiceAccountCredential(target As String) As CredentialInfo
            ' Handle system accounts
            If target = "NT AUTHORITY\SYSTEM" OrElse
           target = "NT AUTHORITY\LOCAL SERVICE" OrElse
           target = "NT AUTHORITY\NETWORK SERVICE" Then
                Return New CredentialInfo() With {
                    .Target = target,
                    .Username = target,
                    .AccountType = "Service Account",
                    .Password = "",
                    .SecurePassword = New SecureString()
                }
            End If
            Return Nothing
        End Function

        Public Shared Function GetUserSidByName(username As String) As String
            Try
                Dim ntAccount = New NTAccount(username)
                Dim sid = CType(ntAccount.Translate(GetType(SecurityIdentifier)), SecurityIdentifier)
                Return sid.Value
            Catch ex As Exception
                '_logger.LogError($"Error getting Sid: {ex.Message}")'
                Return String.Empty
            End Try
        End Function
        Public Sub SaveCredential(credInfo As CredentialInfo, password As SecureString)
            Try
                Select Case credInfo.AccountType.ToLower()
                    Case "windows vault"
                        SaveToWindowsVault(credInfo, password)
                    Case "stored account"
                        SaveStoredCredential(credInfo, password)
                    Case "current user"
                        SaveCurrentUserCredential(credInfo, password)
                    Case "service account"
                        ' For service accounts, you not need to save anything
                    Case Else
                        Throw New ArgumentException("Invalid account type", NameOf(credInfo.AccountType))
                End Select
                _logger.LogInfo($"Credential saved successfully for target: {credInfo.Target}, account type: {credInfo.AccountType}")
            Catch ex As Exception
                _logger.LogError($"Error saving credential: {ex.Message}")
                Throw
            End Try
        End Sub

        Private Sub SaveCurrentUserCredential(credInfo As CredentialInfo, password As SecureString)
            Dim encryptedPassword = EncryptString(New NetworkCredential(String.Empty, password).Password)
            Dim regKey = Microsoft.Win32.Registry.CurrentUser.CreateSubKey("SOFTWARE\LiteTask\Credentials")
            regKey.SetValue(credInfo.Target, $"{credInfo.Username}|{encryptedPassword}")
        End Sub

        Private Sub SaveStoredCredential(credInfo As CredentialInfo, password As SecureString)
            Dim encryptedPassword = EncryptString(New NetworkCredential(String.Empty, password).Password)
            File.AppendAllText(_storedCredentialsPath, $"{credInfo.Target}|{credInfo.Username}|{encryptedPassword}{Environment.NewLine}")
        End Sub

        Private Sub SaveToWindowsVault(credInfo As CredentialInfo, password As SecureString)
            Dim credential As New CREDENTIAL With {
            .Type = CRED_TYPE_GENERIC,
            .TargetName = credInfo.Target,
            .UserName = credInfo.Username,
            .Persist = CRED_PERSIST_LOCAL_MACHINE
        }

            Dim passwordBytes As Byte() = Encoding.Unicode.GetBytes(New NetworkCredential(String.Empty, password).Password)
            credential.CredentialBlobSize = CUInt(passwordBytes.Length)
            credential.CredentialBlob = Marshal.AllocHGlobal(passwordBytes.Length)
            Marshal.Copy(passwordBytes, 0, credential.CredentialBlob, passwordBytes.Length)

            Try
                If Not CredWrite(credential, 0) Then
                    Throw New Win32Exception(Marshal.GetLastWin32Error())
                End If
            Finally
                Marshal.FreeHGlobal(credential.CredentialBlob)
            End Try
        End Sub

    End Class
End Namespace
