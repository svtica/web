Imports System.Collections.Concurrent
Imports System.Data
Imports LiteTask.LiteTask.ScheduledTask


Namespace LiteTask
    Public Class CustomScheduler
        Implements IDisposable

        Private _disposed As Boolean
        Private ReadOnly _credentialManager As CredentialManager
        Private ReadOnly _xmlManager As XMLManager
        Private ReadOnly _logger As Logger
        Private ReadOnly _toolManager As ToolManager
        Private ReadOnly _tasks As New ConcurrentDictionary(Of String, ScheduledTask)
        Private ReadOnly _errorNotifier As ErrorNotifier
        Private ReadOnly _taskRunner As TaskRunner
        Private _secureChannelWrapper As SecureChannelWrapper
        Private disposedValue As Boolean
        Private ReadOnly _impersonation As Impersonation
        Private ReadOnly _liteRunConfig As LiteRunConfig
        Private ReadOnly _taskRunning As New ConcurrentDictionary(Of String, Boolean)
        Private ReadOnly _dependencyManager As TaskDependencyManager



        <StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Unicode)>
        Private Structure TASK_INFO
            Public InstanceCount As UInteger
            Public LastRunTime As System.Runtime.InteropServices.ComTypes.FILETIME
            Public NextRunTime As System.Runtime.InteropServices.ComTypes.FILETIME
            Public Status As TASK_STATUS
            <MarshalAs(UnmanagedType.LPWStr)>
            Public ApplicationName As String
            <MarshalAs(UnmanagedType.LPWStr)>
            Public Parameters As String
            <MarshalAs(UnmanagedType.LPWStr)>
            Public WorkingDirectory As String
            <MarshalAs(UnmanagedType.LPWStr)>
            Public Creator As String
            <MarshalAs(UnmanagedType.LPWStr)>
            Public Comment As String
        End Structure

        Private Enum TASK_STATUS
            TASK_STATUS_READY = 2
            TASK_STATUS_RUNNING = 4
            TASK_STATUS_DISABLED = 8
        End Enum

        Public Sub New(credentialManager As CredentialManager, xmlManager As XMLManager, toolManager As ToolManager, logger As Logger, taskRunner As TaskRunner)
            _credentialManager = credentialManager
            _xmlManager = xmlManager
            _toolManager = toolManager
            _logger = logger
            _taskRunner = taskRunner
            _impersonation = New Impersonation(_credentialManager, _logger, _toolManager.ToolsPath)
            _liteRunConfig = New LiteRunConfig(xmlManager.GetLiteRunDefaults())
            _secureChannelWrapper = New SecureChannelWrapper(_logger)
            _errorNotifier = New ErrorNotifier(xmlManager, logger)
            _dependencyManager = New TaskDependencyManager(logger, xmlManager, Me)
        End Sub

        Public Sub AddTask(task As ScheduledTask)
            Try
                If task Is Nothing Then
                    Throw New ArgumentNullException(NameOf(task))
                End If

                _logger.LogInfo($"Adding new task: {task.Name}")

                ' Validate task
                If String.IsNullOrWhiteSpace(task.Name) Then
                    Throw New ArgumentException("Task name is required")
                End If

                If _tasks.ContainsKey(task.Name) Then
                    Throw New ArgumentException($"Task with name '{task.Name}' already exists")
                End If

                ' Ensure collections are initialized
                If task.Actions Is Nothing Then
                    task.Actions = New List(Of TaskAction)()
                End If
                If task.DailyTimes Is Nothing Then
                    task.DailyTimes = New List(Of TimeSpan)()
                End If
                If task.Parameters Is Nothing Then
                    task.Parameters = New Hashtable()
                End If

                ' Calculate initial next run time
                task.NextRunTime = task.CalculateNextRunTime()

                ' Add task to collection
                _tasks(task.Name) = task

                ' Save to XML
                _xmlManager.SaveTask(task)

                _logger.LogInfo($"Task {task.Name} added successfully")
            Catch ex As Exception
                _logger.LogError($"Error adding task: {ex.Message}")
                Throw New Exception("Failed to add task", ex)
            End Try
        End Sub

        Public Sub CheckAndExecuteTasks()
            Dim now = DateTime.Now
            _logger.LogInfo($"Checking tasks at {now}")
            For Each task In _tasks.Values
                _logger.LogInfo($"Checking task: {task.Name}, Next run time: {task.NextRunTime}")
                If task.NextRunTime <= now Then
                    _logger.LogInfo($"Executing task: {task.Name}")
                    ExecuteTask(task)
                    task.UpdateNextRunTime()
                    _logger.LogInfo($"Updated next run time for task {task.Name}: {task.NextRunTime}")
                    SaveTasks() ' Save tasks after updating next run time
                End If
            Next
        End Sub

        Private Sub CleanupTaskResources(taskName As String)
            Try
                ' Clean up log files
                Dim logPattern = Path.Combine(_liteRunConfig.LogOutputPath, $"{taskName}_*.log")
                For Each logFile In Directory.GetFiles(Path.GetDirectoryName(logPattern), Path.GetFileName(logPattern))
                    Try
                        File.Delete(logFile)
                        _logger.LogInfo($"Deleted log file: {logFile}")
                    Catch ex As Exception
                        _logger.LogWarning($"Failed to delete log file {logFile}: {ex.Message}")
                    End Try
                Next

                ' Clean up temporary files if any
                Dim tempPattern = Path.Combine(Path.GetTempPath(), $"LiteTask_{taskName}_*")
                For Each tempFile In Directory.GetFiles(Path.GetDirectoryName(tempPattern), Path.GetFileName(tempPattern))
                    Try
                        File.Delete(tempFile)
                        _logger.LogInfo($"Deleted temp file: {tempFile}")
                    Catch ex As Exception
                        _logger.LogWarning($"Failed to delete temp file {tempFile}: {ex.Message}")
                    End Try
                Next

            Catch ex As Exception
                _logger.LogWarning($"Error cleaning up task resources: {ex.Message}")
                ' Don't throw here as this is cleanup code
            End Try
        End Sub

        Private Function CreateTemporaryTask(parentTask As ScheduledTask, action As TaskAction) As ScheduledTask
            Return New ScheduledTask With {
            .Name = parentTask.Name,
            .Type = action.Type,
            .FilePath = action.Target,
            .Arguments = action.Parameters,
            .RequiresElevation = action.RequiresElevation,
            .CredentialTarget = parentTask.CredentialTarget,
            .AccountType = parentTask.AccountType,
            .ExecutionMode = parentTask.ExecutionMode,
            .Parameters = parentTask.Parameters
        }
        End Function

        Protected Overridable Sub Dispose(disposing As Boolean)
            If Not _disposed Then
                If disposing Then
                    ' Clean up managed resources
                    For Each task In _tasks.Values
                        If TypeOf task Is IDisposable Then
                            DirectCast(task, IDisposable).Dispose()
                        End If
                    Next
                    _tasks.Clear()
                End If

                ' Clean up unmanaged resources
                _disposed = True
            End If
        End Sub

        Public Sub Dispose() Implements IDisposable.Dispose
            Dispose(True)
            GC.SuppressFinalize(Me)
        End Sub

        Private Async Function ExecuteAction(task As ScheduledTask, action As TaskAction) As Task(Of Boolean)
            Try
                ' Set action status to running
                action.Status = TaskActionStatus.Running
                action.LastResult = New TaskActionResult With {
            .StartTime = DateTime.Now
        }

                Dim success As Boolean = False
                Dim credential As CredentialInfo = Nothing

                ' Get credential if specified
                If Not String.IsNullOrEmpty(task.CredentialTarget) Then
                    credential = _credentialManager.GetCredential(task.CredentialTarget, task.AccountType)
                End If

                ' Execute based on type
                Select Case action.Type
                    Case TaskType.PowerShell
                        success = Await ExecutePowerShellTask(CreateTemporaryTask(task, action), credential)
                    Case TaskType.Batch
                        success = Await ExecuteBatchTask(CreateTemporaryTask(task, action), credential)
                    Case TaskType.SQL
                        success = Await ExecuteSqlTask(CreateTemporaryTask(task, action), credential)
                    Case TaskType.Executable
                        success = Await ExecuteExecutableTask(CreateTemporaryTask(task, action), credential)
                    Case Else
                        _logger.LogError($"Unsupported task type: {action.Type}")
                        success = False
                End Select

                action.LastResult.EndTime = DateTime.Now
                action.LastResult.Success = success
                action.Status = If(success, TaskActionStatus.Completed, TaskActionStatus.Failed)
                Return success

            Catch ex As Exception
                _logger.LogError($"Error executing action {action.Name}: {ex.Message}")
                action.Status = TaskActionStatus.Failed
                If action.LastResult Is Nothing Then
                    action.LastResult = New TaskActionResult()
                End If
                action.LastResult.ErrorDetails = ex
                action.LastResult.EndTime = DateTime.Now
                Return False
            End Try
        End Function

        Private Async Function ExecuteActionWithDependencies(_task As ScheduledTask,
                                                           action As TaskAction) As Task(Of Boolean)
            Try
                ' Check dependencies
                If Not String.IsNullOrEmpty(action.DependsOn) Then
                    Dim dependentTask = GetTask(action.DependsOn)
                    If dependentTask Is Nothing Then
                        _logger.LogError($"Dependent task {action.DependsOn} not found for action {action.Name}")
                        Return False
                    End If

                    ' Check if dependent task is currently running
                    If _taskRunning.ContainsKey(action.DependsOn) AndAlso _taskRunning(action.DependsOn) Then
                        _logger.LogWarning($"Dependent task {action.DependsOn} is currently running. Waiting...")
                        Await WaitForDependentTask(action.DependsOn, action.TimeoutMinutes)
                    End If

                    ' Verify dependent task completed successfully
                    If Not IsTaskCompletedSuccessfully(action.DependsOn) Then
                        If Not action.ContinueOnError Then
                            _logger.LogError($"Dependent task {action.DependsOn} failed or not completed")
                            Return False
                        End If
                        _logger.LogWarning($"Dependent task {action.DependsOn} failed but continuing due to ContinueOnError setting")
                    End If
                End If

                ' Execute the action
                Dim success = False
                Dim retryCount = 0
                action.Status = TaskActionStatus.Running
                action.LastResult = New TaskActionResult With {
                    .StartTime = DateTime.Now
                }

                Do
                    Try
                        success = Await ExecuteAction(_task, action)
                        If success Then
                            action.Status = TaskActionStatus.Completed
                            Exit Do
                        End If

                        retryCount += 1
                        If retryCount <= action.RetryCount Then
                            action.Status = TaskActionStatus.Retrying
                            _logger.LogWarning($"Retrying action {action.Name} (Attempt {retryCount} of {action.RetryCount})")
                            Await Task.Delay(TimeSpan.FromMinutes(action.RetryDelayMinutes))
                        End If
                    Catch ex As Exception
                        _logger.LogError($"Error executing action {action.Name}: {ex.Message}")
                        action.LastResult.ErrorDetails = ex
                        If Not action.ContinueOnError Then
                            Throw
                        End If
                    End Try
                Loop While retryCount <= action.RetryCount

                action.LastResult.EndTime = DateTime.Now
                action.LastResult.Success = success
                action.LastResult.RetryCount = retryCount - 1

                If Not success AndAlso Not action.ContinueOnError Then
                    action.Status = TaskActionStatus.Failed
                    Return False
                End If

                Return True

            Catch ex As Exception
                _logger.LogError($"Error executing action with dependencies: {ex.Message}")
                action.Status = TaskActionStatus.Failed
                action.LastResult.ErrorDetails = ex
                Return False
            End Try
        End Function

        Private Async Function ExecuteBatchTask(_task As ScheduledTask, credential As CredentialInfo) As Task(Of Boolean)
            Try
                _logger.LogInfo($"Executing Batch task: {_task.Name}")

                Dim domain As String = ""
                Dim username As String = credential?.Username

                If Not String.IsNullOrEmpty(username) AndAlso username.Contains("\") Then
                    Dim parts = username.Split("\"c)
                    domain = parts(0)
                    username = parts(1)
                End If

                Dim password As String = If(credential?.SecurePassword IsNot Nothing,
                                  New NetworkCredential("", credential.SecurePassword).Password,
                                  "")

                Dim result = Await Task.Run(Function() _impersonation.CreateProcessAsImpersonatedUser(
            username,
            domain,
            password,
            "cmd.exe",
            $"/c ""{_task.FilePath}"" {_task.Arguments}",
            Path.GetDirectoryName(_task.FilePath)))

                If result Then
                    _logger.LogInfo($"Batch task {_task.Name} executed successfully")
                Else
                    _logger.LogError($"Batch task {_task.Name} execution failed")
                End If

                Return result

            Catch ex As Exception
                _logger.LogError($"Error in ExecuteBatchTask: {ex.Message}")
                _logger.LogError($"StackTrace: {ex.StackTrace}")
                Return False
            End Try
        End Function

        Private Async Function ExecuteExecutableTask(task As ScheduledTask, credential As CredentialInfo) As Task(Of Boolean)
            Try
                _logger.LogInfo($"Executing Executable task: {task.Name}")

                Dim domain As String = ""
                Dim username As String = credential?.Username

                If Not String.IsNullOrEmpty(username) AndAlso username.Contains("\") Then
                    Dim parts = username.Split("\"c)
                    domain = parts(0)
                    username = parts(1)
                End If

                Dim password As String = If(credential?.SecurePassword IsNot Nothing,
                                  New NetworkCredential("", credential.SecurePassword).Password,
                                  "")

                Dim liteRunPath = Path.Combine(_toolManager.ToolsPath, "LiteRun.exe")
                Dim liteRunArgs = _liteRunConfig.GetCommandLineArguments()
                Dim taskArgs = $"-u {username} -p {password} {If(Not String.IsNullOrEmpty(domain), $"-d {domain}", "")} {liteRunArgs} ""{task.FilePath}"" {task.Arguments}"

                Dim result = Await RunProcessAsync(liteRunPath, taskArgs)

                ' If we get here without exceptions, the process completed successfully
                _logger.LogInfo($"Executable task {task.Name} executed successfully")
                Return True

            Catch ex As Exception
                _logger.LogError($"Error in ExecuteExecutableTask: {ex.Message}")
                _logger.LogError($"StackTrace: {ex.StackTrace}")
                Return False
            End Try
        End Function

        Private Async Function ExecutePowerShellTask(_task As ScheduledTask, credential As CredentialInfo) As Task(Of Boolean)
            Try
                _logger.LogInfo($"Executing PowerShell task: {_task.Name}")

                Dim domain As String = ""
                Dim username As String = credential.Username

                If username.Contains("\") Then
                    Dim parts = username.Split("\"c)
                    domain = parts(0)
                    username = parts(1)
                End If

                Dim password As String = If(TypeOf credential.SecurePassword Is SecureString,
                                    New NetworkCredential("", DirectCast(credential.SecurePassword, SecureString)).Password,
                                    credential.Password.ToString())

                Dim impersonation = New Impersonation(_credentialManager, _logger, _toolManager.ToolsPath)
                Dim result = Await Task.Run(Function() impersonation.ExecutePowerShellScriptAsUser(username, domain, password, _task.FilePath, _task.Arguments))

                If result Then
                    _logger.LogInfo($"PowerShell task {_task.Name} executed successfully")
                Else
                    _logger.LogError($"PowerShell task {_task.Name} execution failed")
                End If

                Return result
            Catch ex As Exception
                _logger.LogError($"Error in ExecutePowerShellTask: {ex.Message}")
                _logger.LogError($"StackTrace: {ex.StackTrace}")
                Return False
            End Try
        End Function

        Private Async Function ExecuteSqlTask(_task As ScheduledTask, credential As CredentialInfo) As Task(Of Boolean)
            Try
                _logger.LogInfo($"Executing SQL task: {_task.Name}")

                Dim domain As String = ""
                Dim username As String = credential.Username

                If username.Contains("\") Then
                    Dim parts = username.Split("\"c)
                    domain = parts(0)
                    username = parts(1)
                End If

                Dim password As String = If(TypeOf credential.SecurePassword Is SecureString,
                                    New NetworkCredential("", DirectCast(credential.SecurePassword, SecureString)).Password,
                                    credential.Password.ToString())

                ' Assume these values are stored in the task or can be retrieved from somewhere
                Dim serverName = "your_server_name"
                Dim databaseName = "your_database_name"

                Dim impersonation = New Impersonation(_credentialManager, _logger, _toolManager.ToolsPath)
                Dim result = Await Task.Run(Function() impersonation.ExecuteSqlAsUser(username, domain, password, File.ReadAllText(_task.FilePath), serverName, databaseName))

                If result Then
                    _logger.LogInfo($"SQL task {_task.Name} executed successfully")
                Else
                    _logger.LogError($"SQL task {_task.Name} execution failed")
                End If

                Return result
            Catch ex As Exception
                _logger.LogError($"Error in ExecuteSqlTask: {ex.Message}")
                _logger.LogError($"StackTrace: {ex.StackTrace}")
                Return False
            End Try
        End Function

        'Public Async Function ExecuteTask(task As ScheduledTask) As Task
        '    Try
        '        _logger.LogInfo($"Starting execution of task: {task.Name}")

        '        ' Execute each action in order
        '        For Each action In task.Actions.OrderBy(Function(a) a.Order)
        '            Try
        '                _logger.LogInfo($"Executing action {action.Order} of type {action.Type} for task {task.Name}")

        '                Dim credential As CredentialInfo = Nothing
        '                If Not String.IsNullOrEmpty(task.CredentialTarget) Then
        '                    credential = _credentialManager.GetCredential(task.CredentialTarget, task.AccountType)
        '                End If

        '                ' Use existing execution methods based on action type
        '                Select Case action.Type
        '                    Case TaskType.PowerShell
        '                        Await ExecutePowerShellTask(CreateTemporaryTask(task, action), credential)
        '                    Case TaskType.Batch
        '                        Await ExecuteBatchTask(CreateTemporaryTask(task, action), credential)
        '                    Case TaskType.SQL
        '                        Await ExecuteSqlTask(CreateTemporaryTask(task, action), credential)
        '                    Case TaskType.Executable
        '                        Await ExecuteExecutableTask(CreateTemporaryTask(task, action), credential)
        '                    Case Else
        '                        Throw New NotSupportedException($"Task type {action.Type} is not supported.")
        '                End Select

        '            Catch ex As Exception
        '                _logger.LogError($"Error executing action {action.Order} of task {task.Name}: {ex.Message}")
        '                Throw
        '            End Try
        '        Next

        '        task.UpdateNextRunTime()
        '        SaveTasks()

        '        ' Execute chained task if exists
        '        If task.NextTaskId.HasValue Then
        '            Dim nextTask = GetTask(task.NextTaskId.Value)
        '            If nextTask IsNot Nothing Then
        '                _logger.LogInfo($"Executing chained task: {nextTask.Name}")
        '                Await ExecuteTask(nextTask)
        '            End If
        '        End If

        '    Catch ex As Exception
        '        _logger.LogError($"Error executing task {task.Name}: {ex.Message}")
        '        _logger.LogError($"StackTrace: {ex.StackTrace}")
        '        Throw
        '    End Try
        'End Function

        Public Async Function ExecuteTask(task As ScheduledTask) As Task
            Try
                If _taskRunning.TryAdd(task.Name, True) Then
                    _logger.LogInfo($"Starting execution of task: {task.Name}")

                    ' Get sorted actions based on dependencies
                    Dim sortedActions = _dependencyManager.GetExecutionOrder(task)

                    For Each action In sortedActions
                        If Not Await ExecuteActionWithDependencies(task, action) Then
                            _logger.LogError($"Action {action.Name} failed in task {task.Name}")
                            If Not action.ContinueOnError Then
                                Exit For
                            End If
                        End If
                    Next

                    _taskRunning.TryRemove(task.Name, True)
                    task.UpdateNextRunTime()
                    SaveTasks()
                Else
                    _logger.LogWarning($"Task {task.Name} is already running")
                End If
            Catch ex As Exception
                _logger.LogError($"Error executing task {task.Name}: {ex.Message}")
                _taskRunning.TryRemove(task.Name, True)
                Throw
            End Try
        End Function

        Public Function GetAllTasks() As IEnumerable(Of ScheduledTask)
            Try
                _logger.LogInfo("Getting all tasks")

                ' First load all tasks from XML to ensure memory cache is up to date
                Dim taskNames = _xmlManager.GetAllTaskNames()
                For Each taskName In taskNames
                    If Not _tasks.ContainsKey(taskName) Then
                        Dim task = _xmlManager.LoadTask(taskName)
                        If task IsNot Nothing Then
                            _tasks(taskName) = task
                        End If
                    End If
                Next

                ' Return tasks from memory
                Return _tasks.Values.Where(Function(t) t IsNot Nothing).ToList()

            Catch ex As Exception
                _logger.LogError($"Error getting all tasks: {ex.Message}")
                _logger.LogError($"StackTrace: {ex.StackTrace}")
                Return New List(Of ScheduledTask)()
            End Try
        End Function

        Public Function GetTask(taskName As String) As ScheduledTask
            Try
                _logger.LogInfo($"Getting task: {taskName}")

                ' First try to get from memory
                Dim task As ScheduledTask = Nothing
                If _tasks.TryGetValue(taskName, task) Then
                    Return task
                End If

                ' If not in memory, try to load from XML
                task = _xmlManager.LoadTask(taskName)
                If task IsNot Nothing Then
                    ' Cache the task in memory
                    _tasks(taskName) = task
                    Return task
                End If

                _logger.LogWarning($"Task not found: {taskName}")
                Return Nothing

            Catch ex As Exception
                _logger.LogError($"Error getting task {taskName}: {ex.Message}")
                _logger.LogError($"StackTrace: {ex.StackTrace}")
                Return Nothing
            End Try
        End Function

        Private Function IsTaskCompletedSuccessfully(taskName As String) As Boolean
            Try
                Dim task = GetTask(taskName)
                If task Is Nothing OrElse task.Actions Is Nothing Then
                    Return False
                End If

                Return task.Actions.All(Function(a) _
            a IsNot Nothing AndAlso
            a.Status = TaskActionStatus.Completed AndAlso
            a.LastResult IsNot Nothing AndAlso
            a.LastResult.Success)

            Catch ex As Exception
                _logger.LogError($"Error checking task completion status for {taskName}: {ex.Message}")
                Return False
            End Try
        End Function

        Public Sub LoadTasks()
            Try
                _logger.LogInfo("Loading tasks from XML file")
                Dim taskNames = _xmlManager.GetAllTaskNames()
                If taskNames.Count = 0 Then
                    _logger.LogInfo("No tasks found in the XML file")
                    Return
                End If

                For Each taskName In taskNames
                    Dim task = _xmlManager.LoadTask(taskName)
                    If task IsNot Nothing Then
                        _tasks(taskName) = task
                    End If
                Next
                _logger.LogInfo($"Successfully loaded {_tasks.Count} tasks")
            Catch ex As Exception
                _logger.LogError($"Error loading tasks: {ex.Message}")
                _logger.LogError($"StackTrace: {ex.StackTrace}")
            End Try
        End Sub

        Public Sub RemoveTask(taskName As String)
            Try
                _logger.LogInfo($"Removing task: {taskName}")

                If String.IsNullOrEmpty(taskName) Then
                    Throw New ArgumentException("Task name cannot be null or empty", NameOf(taskName))
                End If

                ' Remove from memory
                Dim task As ScheduledTask = Nothing
                If _tasks.TryRemove(taskName, task) Then
                    _logger.LogInfo($"Task {taskName} removed from scheduler cache")
                Else
                    _logger.LogWarning($"Task {taskName} not found in scheduler cache")
                End If

                ' Remove from XML storage
                _xmlManager.DeleteTask(taskName)
                _logger.LogInfo($"Task {taskName} removed from XML storage")

                ' Clean up any associated resources
                CleanupTaskResources(taskName)

            Catch ex As Exception
                _logger.LogError($"Error removing task {taskName}: {ex.Message}")
                _logger.LogError($"StackTrace: {ex.StackTrace}")
                Throw
            End Try
        End Sub

        Public Async Function RunProcessAsync(fileName As String, arguments As String) As Task(Of String)
            Dim output As New System.Text.StringBuilder()
            Dim err As New System.Text.StringBuilder()

            Dim startInfo As New ProcessStartInfo(fileName) With {
            .Arguments = arguments,
            .RedirectStandardOutput = True,
            .RedirectStandardError = True,
            .UseShellExecute = False,
            .CreateNoWindow = True
        }

            Using process As New Process() With {.StartInfo = startInfo}
                AddHandler process.OutputDataReceived, Sub(sender, e)
                                                           If e.Data IsNot Nothing Then
                                                               output.AppendLine(e.Data)
                                                           End If
                                                       End Sub
                AddHandler process.ErrorDataReceived, Sub(sender, e)
                                                          If e.Data IsNot Nothing Then
                                                              err.AppendLine(e.Data)
                                                          End If
                                                      End Sub

                process.Start()
                process.BeginOutputReadLine()
                process.BeginErrorReadLine()
                Await process.WaitForExitAsync()

                If process.ExitCode <> 0 Then
                    Dim exitCode As LiteRunExitCode = CType(process.ExitCode, LiteRunExitCode)
                    Throw New LiteRunException(exitCode, $"Process exited with code {process.ExitCode}. Error: {err}")
                End If
            End Using

            Return output.ToString()
        End Function

        Public Async Function RunTaskAsync(_task As ScheduledTask) As Task
            Try
                _logger.LogInfo($"Starting execution of task: {_task.Name}")

                Dim credential As CredentialInfo = Nothing
                If _task.ServiceAccount.HasValue Then
                    credential = _credentialManager.GetServiceAccountCredential(_task.ServiceAccount.Value)
                ElseIf Not String.IsNullOrEmpty(_task.CredentialTarget) Then
                    credential = _credentialManager.GetCredential(_task.CredentialTarget, _task.AccountType)
                End If

                Dim liteRunPath = Path.Combine(_toolManager.ToolsPath, "LiteRun.exe")
                Dim liteRunArgs = _liteRunConfig.GetCommandLineArguments()

                Dim taskArgs As String
                If credential IsNot Nothing Then
                    taskArgs = $"-u {credential.Username} -p {credential.Password} {liteRunArgs} "
                Else
                    taskArgs = $"{liteRunArgs} "
                End If

                Select Case _task.Type
                    Case ScheduledTask.TaskType.PowerShell
                        taskArgs += $"powershell.exe -ExecutionPolicy Bypass -File ""{_task.FilePath}"" {_task.Arguments}"
                    Case ScheduledTask.TaskType.Batch
                        taskArgs += $"cmd.exe /c ""{_task.FilePath}"" {_task.Arguments}"
                    Case ScheduledTask.TaskType.SQL
                        Dim osqlPath = Path.Combine(_toolManager.ToolsPath, "OSQL.exe")
                        taskArgs += $"{osqlPath} -S {_task.Parameters("SQLServer")} -d {_task.Parameters("SQLDatabase")} -i ""{_task.FilePath}"" {_task.Arguments} -E"
                    Case ScheduledTask.TaskType.Executable
                        taskArgs += $"""{_task.FilePath}"" {_task.Arguments}"
                    Case Else
                        Throw New NotSupportedException($"Task type {_task.Type} is not supported.")
                End Select

                Dim output As String = Await RunProcessAsync(liteRunPath, taskArgs)

                _logger.LogInfo($"Task {_task.Name} executed successfully")
                _logger.LogInfo($"Output: {output}")

                ' Read the log file if it exists
                Dim logFilePath = Path.Combine(_liteRunConfig.LogOutputPath, $"{_task.Name}_{DateTime.Now:yyyyMMddHHmmss}.log")
                If File.Exists(logFilePath) Then
                    Dim logContent = Await File.ReadAllTextAsync(logFilePath)
                    _logger.LogInfo($"LiteRun Log: {logContent}")
                    File.Delete(logFilePath)
                End If

                _task.UpdateNextRunTime()
                SaveTasks()

                If _task.NextTaskId.HasValue Then
                    Dim nextTask = GetTask(_task.NextTaskId.Value)
                    If nextTask IsNot Nothing Then
                        _logger.LogInfo($"Executing chained task: {nextTask.Name}")
                        Await RunTaskAsync(nextTask)
                    End If
                End If

            Catch ex As LiteRunException
                _logger.LogError($"LiteRun error executing task {_task.Name}: {ex.Message}")
                _logger.LogError($"Exit Code: {ex.ExitCode}")
                Throw
            Catch ex As Exception
                _logger.LogError($"Error executing task {_task.Name}: {ex.Message}")
                _logger.LogError($"StackTrace: {ex.StackTrace}")
                Throw
            End Try
        End Function

        Public Sub SaveTasks()
            Try
                _logger.LogInfo("Starting to save tasks")

                If _xmlManager Is Nothing Then
                    Throw New InvalidOperationException("XMLManager is not initialized")
                End If

                ' Get current tasks
                Dim currentTasks = GetAllTasks()

                ' First, load existing task names from XML
                Dim existingTaskNames = _xmlManager.GetAllTaskNames()

                ' Find tasks to delete (tasks in XML but not in current tasks)
                For Each existingName In existingTaskNames
                    If Not currentTasks.Any(Function(t) t.Name = existingName) Then
                        _logger.LogInfo($"Deleting obsolete task from XML: {existingName}")
                        _xmlManager.DeleteTask(existingName)
                    End If
                Next

                ' Save current tasks
                For Each task In currentTasks
                    If task IsNot Nothing Then
                        _xmlManager.SaveTask(task)
                        _logger.LogInfo($"Saved task: {task.Name}")
                    End If
                Next

                _logger.LogInfo("Tasks saved successfully")
            Catch ex As Exception
                _logger.LogError($"Error saving tasks: {ex.Message}")
                _logger.LogError($"StackTrace: {ex.StackTrace}")
                Throw New Exception("Failed to save tasks", ex)
            End Try
        End Sub

        Public Sub UpdateTask(updatedTask As ScheduledTask)
            Try
                If updatedTask Is Nothing Then
                    Throw New ArgumentNullException(NameOf(updatedTask))
                End If

                _logger.LogInfo($"Updating task: {updatedTask.Name}")

                If Not _tasks.ContainsKey(updatedTask.Name) Then
                    Throw New ArgumentException($"Task '{updatedTask.Name}' not found")
                End If

                ' Update next run time
                updatedTask.NextRunTime = updatedTask.CalculateNextRunTime()

                ' Update task in collection
                _tasks(updatedTask.Name) = updatedTask

                ' Save to XML
                _xmlManager.SaveTask(updatedTask)

                _logger.LogInfo($"Task {updatedTask.Name} updated successfully")
            Catch ex As Exception
                _logger.LogError($"Error updating task: {ex.Message}")
                Throw New Exception("Failed to update task", ex)
            End Try
        End Sub

        Private Async Function WaitForDependentTask(taskName As String, timeoutMinutes As Integer) As Task
            Dim startTime = DateTime.Now
            While True
                ' Check if we've exceeded timeout
                If DateTime.Now.Subtract(startTime).TotalMinutes > timeoutMinutes Then
                    Throw New System.TimeoutException($"Timeout waiting for task {taskName}")
                End If

                ' Check task status
                Dim _task = GetTask(taskName)
                If _task?.Actions.All(Function(a) a.Status = TaskActionStatus.Completed) Then
                    Return
                End If
                Await Task.Delay(5000) ' Check every 5 seconds
            End While
        End Function


    End Class
End Namespace