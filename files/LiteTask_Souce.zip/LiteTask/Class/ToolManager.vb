Imports System.Net.Http

Namespace LiteTask
    Public Class ToolManager
        Public ReadOnly _toolsPath As String
        Private ReadOnly _tools As Dictionary(Of String, String)
        Private ReadOnly _httpClient As HttpClient
        Private _currentExecutionTool As String = "PsExec.exe" ' Set PsExec as default
        'Private _currentExecutionTool As String = "LiteRun" ' Default to LiteRun

        Public ReadOnly Property ToolsPath As String
            Get
                Return _toolsPath
            End Get
        End Property

        Public Property CurrentExecutionTool As String
            Get
                Return _currentExecutionTool
            End Get
            Set(value As String)
                If _tools.ContainsKey(value) Then
                    _currentExecutionTool = value
                Else
                    Throw New ArgumentException($"Tool '{value}' is not available.")
                End If
            End Set
        End Property


        Public Sub New(toolsPath As String)
            _toolsPath = toolsPath
            _tools = New Dictionary(Of String, String)

            ' Add tools using a method that checks for duplicates
            AddToolSafely("LiteRun.exe", "https://path-to-literun.exe")
            AddToolSafely("PsExec.exe", "https://live.sysinternals.com/PsExec.exe")
            AddToolSafely("PsExec64.exe", "https://live.sysinternals.com/PsExec64.exe")
            AddToolSafely("OSQL.exe", "https://")
            AddToolSafely("osql.rll", "https://")

            _httpClient = New HttpClient()
        End Sub

        Private Sub AddToolSafely(key As String, value As String)
            If Not _tools.ContainsKey(key) Then
                _tools.Add(key, value)
            Else
                ' Optionally log a warning about duplicate key
                ' _logger.LogWarning($"Duplicate tool key found: {key}")
            End If
        End Sub

        Public Function DetectTools() As Dictionary(Of String, Boolean)
            Dim result As New Dictionary(Of String, Boolean)
            For Each tool In _tools.Keys
                result(tool) = File.Exists(Path.Combine(_toolsPath, tool))
            Next
            Return result
        End Function

        Public Sub Dispose()
            _httpClient.Dispose()
        End Sub

        Public Async Function DownloadAndUpdateToolAsync(toolName As String, url As String) As Task(Of Boolean)
            Try
                Dim toolPath = Path.Combine(_toolsPath, toolName)
                Using response As HttpResponseMessage = Await _httpClient.GetAsync(url)
                    If response.IsSuccessStatusCode Then
                        Using stream As Stream = Await response.Content.ReadAsStreamAsync()
                            Using fileStream As New FileStream(toolPath, FileMode.Create, FileAccess.Write, FileShare.None)
                                Await stream.CopyToAsync(fileStream)
                            End Using
                        End Using
                        Return True
                    Else
                        Console.WriteLine($"Error downloading {toolName}: HTTP status code {response.StatusCode}")
                        Return False
                    End If
                End Using
            Catch ex As Exception
                Console.WriteLine($"Error downloading {toolName}: {ex.Message}")
                Return False
            End Try
        End Function

        Public Async Function DownloadAndUpdateAllToolsAsync() As Task(Of Dictionary(Of String, Boolean))
            Dim result As New Dictionary(Of String, Boolean)
            For Each kvp In _tools
                result(kvp.Key) = Await DownloadAndUpdateToolAsync(kvp.Key, kvp.Value)
            Next
            Return result
        End Function
        Public Function GetCurrentToolPath() As String
            Return GetToolPath(_currentExecutionTool)
        End Function

        Public Function GetToolPath(toolName As String) As String
            Return Path.Combine(_toolsPath, toolName)
        End Function

        Public Sub LaunchLitePM(processName As String)
            Dim procExpPath = Path.Combine(_toolsPath, "LitePM.exe")

            ' Launch Process Explorer with a filter for LiteTask processes
            Dim startInfo = New ProcessStartInfo() With {
            .FileName = procExpPath,
            .Arguments = "-filter ""Lite""",
            .UseShellExecute = True
        }

            Process.Start(startInfo)
        End Sub

    End Class
End Namespace