Imports System.Data
Imports System.Net.Mail
Imports LiteTask.LiteTask.ScheduledTask

Namespace LiteTask
    Public Class RunTab
        Private ReadOnly _credentialManager As CredentialManager
        Private ReadOnly _customScheduler As CustomScheduler
        Private ReadOnly _logger As Logger
        Private ReadOnly _xmlManager As XMLManager
        Private ReadOnly _taskrunner As TaskRunner
        Private ReadOnly _liteRunConfig As LiteRunConfig
        Private ReadOnly _emailUtils As EmailUtils
        Private ReadOnly _powerShellPathManager As PowerShellPathManager
        Private _runspace As Runspace
        Private _scriptTextBox As TextBox
        Private _outputTextBox As TextBox
        Private _runButton As Button
        Private _credentialComboBox As ComboBox
        Private _tabPage As TabPage
        Private _requiresElevationCheckBox As CheckBox
        Private _executionModeComboBox As ComboBox
        Private _executionModeLabel As Label
        Private _scriptLabel As Label
        Private _outputLabel As Label
        Private _credentialLabel As Label
        Private _targetTextBox As TextBox
        Private _targetLabel As Label
        Private _executionTypeComboBox As ComboBox
        Private _autoDetectCheckBox As CheckBox
        Private _tableLayoutPanel As TableLayoutPanel
        Private _tabPageInitialized As Boolean = False
        Public Event OutputReceived(sender As Object, e As DataAddedEventArgs)
        Public Event ErrorReceived(sender As Object, e As DataAddedEventArgs)

        Public Sub New(credentialManager As CredentialManager, logger As Logger, taskRunner As TaskRunner, xmlManager As XMLManager, customScheduler As CustomScheduler)
            _credentialManager = credentialManager
            _logger = logger
            _xmlManager = xmlManager
            _taskrunner = taskRunner
            _customScheduler = customScheduler
            _emailUtils = New EmailUtils(logger, xmlManager)
            _liteRunConfig = New LiteRunConfig(xmlManager.GetLiteRunDefaults())
            _powerShellPathManager = New PowerShellPathManager(logger)
            InitializeComponent()
        End Sub


        Private Sub InitializeComponent()
            _tabPage = New TabPage("Run")
            _tableLayoutPanel = New TableLayoutPanel()
            _tableLayoutPanel.Dock = DockStyle.Fill
            _tableLayoutPanel.ColumnCount = 2
            _tableLayoutPanel.RowCount = 8 ' Increased row count
            _tableLayoutPanel.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 20))
            _tableLayoutPanel.ColumnStyles.Add(New ColumnStyle(SizeType.Percent, 80))

            ' Add rows with appropriate sizing
            _tableLayoutPanel.RowStyles.Add(New RowStyle(SizeType.Percent, 35))  ' Script
            _tableLayoutPanel.RowStyles.Add(New RowStyle(SizeType.Percent, 35))  ' Output
            _tableLayoutPanel.RowStyles.Add(New RowStyle(SizeType.Absolute, 30)) ' Target
            _tableLayoutPanel.RowStyles.Add(New RowStyle(SizeType.Absolute, 30)) ' Execution Mode
            _tableLayoutPanel.RowStyles.Add(New RowStyle(SizeType.Absolute, 30)) ' Credential
            _tableLayoutPanel.RowStyles.Add(New RowStyle(SizeType.Absolute, 30)) ' Requires Elevation
            _tableLayoutPanel.RowStyles.Add(New RowStyle(SizeType.Absolute, 40)) ' Run Button

            _scriptTextBox = New TextBox With {
                .Multiline = True,
                .ScrollBars = ScrollBars.Vertical,
                .Dock = DockStyle.Fill
            }
            _outputTextBox = New TextBox With {
                .Multiline = True,
                .ScrollBars = ScrollBars.Vertical,
                .Dock = DockStyle.Fill,
                .ReadOnly = True
            }
            _targetTextBox = New TextBox With {
                .Dock = DockStyle.Fill
            }

            _runButton = New Button With {
                .Text = "Run Script",
                .Dock = DockStyle.Fill,
                .Height = 30
            }

            _credentialComboBox = New ComboBox With {
                .Dock = DockStyle.Fill,
                .DropDownStyle = ComboBoxStyle.DropDownList
            }

            _requiresElevationCheckBox = New CheckBox With {
                .Text = "Run with elevated privileges",
                .Dock = DockStyle.Fill
            }

            _executionModeComboBox = New ComboBox With {
                .Dock = DockStyle.Fill,
                .DropDownStyle = ComboBoxStyle.DropDownList
            }

            _executionTypeComboBox = New ComboBox With {
                .Dock = DockStyle.Fill,
                .DropDownStyle = ComboBoxStyle.DropDownList
            }
            _executionTypeComboBox.Items.AddRange({"Command", "Batch", "Executable", "PowerShell", "SQL"})
            _executionTypeComboBox.SelectedIndex = 0

            _autoDetectCheckBox = New CheckBox With {
                .Text = "Auto-detect execution type",
                .Checked = True,
                .Dock = DockStyle.Fill
            }

            ' Add controls to the TableLayoutPanel
            _tableLayoutPanel.Controls.Add(New Label With {.Text = "Script:", .Dock = DockStyle.Fill}, 0, 0)
            _tableLayoutPanel.Controls.Add(_scriptTextBox, 1, 0)
            _tableLayoutPanel.Controls.Add(New Label With {.Text = "Output:", .Dock = DockStyle.Fill}, 0, 1)
            _tableLayoutPanel.Controls.Add(_outputTextBox, 1, 1)
            _tableLayoutPanel.Controls.Add(New Label With {.Text = "Execution Type:", .Dock = DockStyle.Fill}, 0, 2)
            _tableLayoutPanel.Controls.Add(_executionTypeComboBox, 1, 2)
            _tableLayoutPanel.Controls.Add(_autoDetectCheckBox, 1, 3)
            _tableLayoutPanel.Controls.Add(New Label With {.Text = "Credential:", .Dock = DockStyle.Fill}, 0, 4)
            _tableLayoutPanel.Controls.Add(_credentialComboBox, 1, 4)
            _tableLayoutPanel.Controls.Add(_requiresElevationCheckBox, 1, 5)
            _tableLayoutPanel.Controls.Add(_runButton, 1, 6)

            _tabPage.Controls.Add(_tableLayoutPanel)
            AddHandlers()
        End Sub

        Public Sub AddHandlers()
            AddHandler _executionTypeComboBox.SelectedIndexChanged, AddressOf ExecutionTypeComboBox_SelectedIndexChanged
            AddHandler _autoDetectCheckBox.CheckedChanged, AddressOf AutoDetectCheckBox_CheckedChanged
            AddHandler _runButton.Click, AddressOf RunButton_Click
        End Sub

        Private Sub AutoDetectCheckBox_CheckedChanged(sender As Object, e As EventArgs)
            _executionTypeComboBox.Enabled = Not _autoDetectCheckBox.Checked
        End Sub

        Private Function DetectExecutionType(input As String) As String
            If String.IsNullOrWhiteSpace(input) Then
                Return "Command"
            End If

            If input.Trim().StartsWith("SELECT ", StringComparison.OrdinalIgnoreCase) OrElse
               input.Trim().StartsWith("INSERT ", StringComparison.OrdinalIgnoreCase) OrElse
               input.Trim().StartsWith("UPDATE ", StringComparison.OrdinalIgnoreCase) OrElse
               input.Trim().StartsWith("DELETE ", StringComparison.OrdinalIgnoreCase) Then
                Return "SQL"
            End If

            If input.Trim().StartsWith("$") OrElse input.Contains("Write-Host") OrElse input.Contains("Get-") Then
                Return "PowerShell"
            End If

            If input.Contains(".exe") OrElse input.Contains(".com") Then
                Return "Executable"
            End If

            If input.Contains(".bat") OrElse input.Contains(".cmd") Then
                Return "Batch"
            End If

            Return "Command"
        End Function

        Private Function DataTableToString(dt As DataTable) As String
            Dim result As New StringBuilder()

            ' Add headers
            result.AppendLine(String.Join(vbTab, dt.Columns.Cast(Of DataColumn)().Select(Function(c) c.ColumnName)))

            ' Add rows
            For Each row As DataRow In dt.Rows
                result.AppendLine(String.Join(vbTab, row.ItemArray.Select(Function(item) If(item IsNot Nothing, item.ToString(), ""))))
            Next

            Return result.ToString()
        End Function

        Public Sub Dispose()
            If _runspace IsNot Nothing Then
                _runspace.Dispose()
            End If
        End Sub

        Private Async Function ExecuteCommand(command As String, executionType As String, target As String, credential As CredentialInfo, requiresElevation As Boolean, executionMode As TaskExecutionMode) As Task(Of String)
            Try
                _logger.LogInfo($"Executing command: {command}")
                _logger.LogInfo($"Execution Type: {executionType}, Target: {target}, Requires Elevation: {requiresElevation}, Execution Mode: {executionMode}")

                Select Case executionType.ToUpper()
                    Case "POWERSHELL"
                        ' Initialize PowerShell parameters with module path
                        Dim psParams As New Hashtable()
                        psParams.Add("Command", _powerShellPathManager.CreateInitializationScript() & Environment.NewLine & command)
                        Dim result = String.Join(Environment.NewLine, (Await _taskrunner.RunScriptAsync(command, psParams, False, Nothing)).Select(Function(pso) pso.ToString()))
                        Return result

                    Case "BATCH"
                        Return Await _taskrunner.RunProcessAsync("cmd.exe", $"/c {command}")

                    Case "EXECUTABLE"
                        Return Await _taskrunner.RunProcessAsync(command, String.Empty)

                    Case Else
                        Throw New NotSupportedException($"Execution type {executionType} is not supported")
                End Select

            Catch ex As Exception
                _logger.LogError($"Error in ExecuteCommandAsync: {ex.Message}")
                _logger.LogError($"StackTrace: {ex.StackTrace}")
                Throw New Exception($"Command execution failed. Error: {ex.Message}", ex)
            End Try
        End Function

        Private Sub ExecutionTypeComboBox_SelectedIndexChanged(sender As Object, e As EventArgs)
            _executionTypeComboBox.Enabled = Not _autoDetectCheckBox.Checked
        End Sub

        Private Function ExtractStoredProcedureName(sqlContent As String) As String
            sqlContent = sqlContent.Trim()

            If sqlContent.StartsWith("EXEC ", StringComparison.OrdinalIgnoreCase) Then
                sqlContent = sqlContent.Substring(5)
            ElseIf sqlContent.StartsWith("EXECUTE ", StringComparison.OrdinalIgnoreCase) Then
                sqlContent = sqlContent.Substring(8)
            End If

            If sqlContent.StartsWith("[") AndAlso sqlContent.Contains("]") Then
                sqlContent = sqlContent.Substring(1, sqlContent.IndexOf("]") - 1)
            End If

            Dim spaceIndex = sqlContent.IndexOf(" "c)
            Dim parenIndex = sqlContent.IndexOf("("c)

            If spaceIndex > 0 AndAlso parenIndex > 0 Then
                Return sqlContent.Substring(0, Math.Min(spaceIndex, parenIndex))
            ElseIf spaceIndex > 0 Then
                Return sqlContent.Substring(0, spaceIndex)
            ElseIf parenIndex > 0 Then
                Return sqlContent.Substring(0, parenIndex)
            End If

            Return sqlContent
        End Function

        Public Function GetTabPage() As TabPage
            If Not _tabPageInitialized Then
                InitializeComponent()
                PopulateCredentialComboBox()
                PopulateExecutionTypeComboBox()
                _tabPageInitialized = True
            End If
            Return _tabPage
        End Function

        Private Sub OnErrorReceived(sender As Object, e As DataAddedEventArgs)
            Dim errorRecord As ErrorRecord = CType(sender, PSDataCollection(Of ErrorRecord))(e.Index)
            _logger.LogError($"PowerShell Error: {errorRecord.Exception.Message}")
            RaiseEvent ErrorReceived(sender, e)
        End Sub

        Private Sub OnOutputReceived(sender As Object, e As DataAddedEventArgs)
            Dim informationRecord As InformationRecord = CType(sender, PSDataCollection(Of InformationRecord))(e.Index)
            _logger.LogInfo($"PowerShell Output: {informationRecord.MessageData}")
            RaiseEvent OutputReceived(sender, e)
        End Sub

        Private Sub PopulateCredentialComboBox()
            _credentialComboBox.Items.Clear()
            _credentialComboBox.Items.Add("(None)")
            Dim targets = _credentialManager.GetAllCredentialTargets()
            For Each target In targets
                _credentialComboBox.Items.Add(target)
            Next
            _credentialComboBox.SelectedIndex = 0
        End Sub

        Private Sub PopulateExecutionTypeComboBox()
            _executionModeComboBox.Items.Clear()
            _executionModeComboBox.Items.AddRange({"Local", "Remote", "CredSSP"})
            _executionModeComboBox.SelectedIndex = 0
        End Sub

        Private Async Sub RunButton_Click(sender As Object, e As EventArgs)
            Try
                _logger.LogInfo("Starting execution")

                If String.IsNullOrWhiteSpace(_scriptTextBox.Text) Then
                    MessageBox.Show("Please enter a valid script or command.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    Return
                End If

                Dim scriptOrCommand = _scriptTextBox.Text
                Dim selectedCredential = If(_credentialComboBox?.SelectedItem?.ToString(), "(None)")
                Dim target = _targetTextBox?.Text.Trim()
                Dim executionType = If(_autoDetectCheckBox.Checked,
                              DetectExecutionType(scriptOrCommand),
                              _executionTypeComboBox.SelectedItem.ToString())

                _logger.LogInfo($"Executing: {scriptOrCommand}")
                _logger.LogInfo($"Selected Credential: {selectedCredential}")
                _logger.LogInfo($"Target: {target}")
                _logger.LogInfo($"Execution Type: {executionType}")

                Dim credential As CredentialInfo = Nothing
                If selectedCredential <> "(None)" Then
                    credential = _credentialManager.GetCredential(selectedCredential, "Windows Vault")
                End If

                Dim result As String = ""

                Select Case executionType.ToUpper()
                    Case "SQL"
                        If scriptOrCommand.Trim().StartsWith("EXEC ", StringComparison.OrdinalIgnoreCase) OrElse
                   scriptOrCommand.Trim().StartsWith("EXECUTE ", StringComparison.OrdinalIgnoreCase) Then

                            Dim spName = ExtractStoredProcedureName(scriptOrCommand)
                            result = Await _taskrunner.ExecuteStoredProcedureWithOSQL(spName, target,
                            If(_targetTextBox?.Text, "master"), credential)
                        Else
                            Dim sqlResult = Await _taskrunner.ExecuteQueryAsync(scriptOrCommand, Nothing, selectedCredential)
                            result = If(sqlResult.Success,
                              DataTableToString(sqlResult.Data),
                              $"Error executing query: {sqlResult.Message}")
                        End If

                    Case Else
                        result = Await ExecuteCommand(scriptOrCommand, executionType, target, credential,
                        _requiresElevationCheckBox.Checked, _executionModeComboBox.SelectedValue)
                End Select

                _outputTextBox.Text = result
                _logger.LogInfo("Execution completed successfully")
                _logger.LogInfo($"Output: {result}")

                ' Send email report if enabled
                If _xmlManager.GetEmailSettings()("NotificationsEnabled") = "True" Then
                    Dim emailSubject = $"{executionType} Execution Report"
                    Dim emailBody = $"{executionType} execution completed.{Environment.NewLine}{Environment.NewLine}Output:{Environment.NewLine}{result}"
                    SendEmailReport(emailSubject, emailBody)
                End If

            Catch ex As Exception
                Dim errorMessage = $"Error during execution: {ex.Message}"
                _outputTextBox.Text = errorMessage
                _logger.LogError($"Error in RunButton_Click: {ex.Message}")
                _logger.LogError($"StackTrace: {ex.StackTrace}")

                If _xmlManager.GetEmailSettings()("NotificationsEnabled") = "True" Then
                    Dim emailSubject = "ERROR: Execution Failed"
                    Dim emailBody = $"Execution failed.{Environment.NewLine}{Environment.NewLine}Error:{Environment.NewLine}{errorMessage}"
                    SendEmailReport(emailSubject, emailBody)
                End If
            End Try
        End Sub

        Private Sub SendEmailReport(subject As String, body As String)
            Try
                Dim emailSettings = _xmlManager.GetEmailSettings()
                Dim smtpServer = emailSettings("SmtpServer")
                Dim smtpPort = Integer.Parse(emailSettings("SmtpPort"))
                Dim emailFrom = emailSettings("EmailFrom")
                Dim emailTo = emailSettings("EmailTo")

                Using mail As New MailMessage()
                    mail.From = New MailAddress(emailFrom)
                    For Each recipient In emailTo.Split(";"c)
                        mail.To.Add(recipient.Trim())
                    Next
                    mail.Subject = subject
                    mail.Body = body

                    Using smtp As New SmtpClient(smtpServer, smtpPort)
                        smtp.Send(mail)
                    End Using
                End Using

                _logger.LogInfo($"Email report sent: {subject}")
            Catch ex As Exception
                _logger.LogError($"Failed to send email report: {ex.Message}")
            End Try
        End Sub

    End Class
End Namespace