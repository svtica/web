Imports System.Collections.Concurrent
Imports System.Net.Mail
Imports System.Threading.Tasks

Namespace LiteTask
    Public Class NotificationManager
        Implements IDisposable

        Private _disposed As Boolean
        Private ReadOnly _logger As Logger
        Private ReadOnly _xmlManager As XMLManager
        Private _emailSettings As Dictionary(Of String, String)
        Private _smtpClient As SmtpClient
        Private _isInitialized As Boolean = False
        Private ReadOnly _emailQueue As New ConcurrentQueue(Of EmailMessage)
        Private _processingTask As Task
        Private _cancellationTokenSource As New CancellationTokenSource()
        Private disposedValue As Boolean

        Public Sub New(logger As Logger, xmlManager As XMLManager)
            _logger = logger
            _xmlManager = xmlManager
            InitializeEmailSettings()
            StartEmailProcessor()
        End Sub

        Protected Overridable Sub Dispose(disposing As Boolean)
            If Not _disposed Then
                If disposing Then
                    Try
                        ' Cancel any pending operations
                        If _cancellationTokenSource IsNot Nothing Then
                            _cancellationTokenSource.Cancel()
                            _cancellationTokenSource.Dispose()
                            _cancellationTokenSource = Nothing
                        End If

                        ' Wait for processing task to complete
                        If _processingTask IsNot Nothing Then
                            Try
                                _processingTask.Wait(TimeSpan.FromSeconds(5))
                            Catch ex As Exception
                                _logger?.LogError($"Error waiting for processing task: {ex.Message}")
                            End Try
                            _processingTask = Nothing
                        End If

                        ' Dispose of SMTP client
                        If _smtpClient IsNot Nothing Then
                            _smtpClient.Dispose()
                            _smtpClient = Nothing
                        End If

                        ' Clear email queue
                        While _emailQueue.TryDequeue(Nothing)
                            ' Just empty the queue
                        End While

                        ' Clear settings
                        If _emailSettings IsNot Nothing Then
                            _emailSettings.Clear()
                            _emailSettings = Nothing
                        End If
                    Catch ex As Exception
                        _logger?.LogError($"Error during NotificationManager disposal: {ex.Message}")
                    End Try
                End If

                _disposed = True
            End If
        End Sub

        Public Sub Dispose() Implements IDisposable.Dispose
            Dispose(disposing:=True)
            GC.SuppressFinalize(Me)
        End Sub

        Protected Overrides Sub Finalize()
            Dispose(disposing:=False)
            MyBase.Finalize()
        End Sub

        Private Sub InitializeEmailSettings()
            Try
                _emailSettings = _xmlManager.GetEmailSettings()
                If Boolean.Parse(_emailSettings("NotificationsEnabled")) Then
                    _smtpClient = New SmtpClient(_emailSettings("SmtpServer"), Integer.Parse(_emailSettings("SmtpPort"))) With {
                        .EnableSsl = True,
                        .DeliveryMethod = SmtpDeliveryMethod.Network,
                        .Timeout = 10000
                    }
                    _isInitialized = True
                    _logger.LogInfo("Email notification system initialized successfully")
                End If
            Catch ex As Exception
                _logger.LogError($"Failed to initialize email settings: {ex.Message}")
                _isInitialized = False
            End Try
        End Sub

        Private Sub StartEmailProcessor()
            Try
                _processingTask = Task.Run(Async Function()
                                               While Not _cancellationTokenSource.Token.IsCancellationRequested
                                                   Try
                                                       Dim message As EmailMessage = Nothing
                                                       If _emailQueue.TryDequeue(message) Then
                                                           Await ProcessEmailMessageAsync(message)
                                                       Else
                                                           ' Use non-async delay in catch block
                                                           Thread.Sleep(5000)
                                                       End If
                                                   Catch ex As Exception
                                                       _logger.LogError($"Error processing email queue: {ex.Message}")
                                                       Thread.Sleep(5000) ' Use non-async delay in catch block
                                                   End Try
                                               End While
                                           End Function, _cancellationTokenSource.Token)
            Catch ex As Exception
                _logger.LogError($"Error starting email processor: {ex.Message}")
            End Try
        End Sub

        Private Async Function ProcessEmailMessageAsync(message As EmailMessage) As Task
            Try
                Using mail As New MailMessage()
                    mail.From = New MailAddress(_emailSettings("EmailFrom"))
                    For Each recipient In _emailSettings("EmailTo").Split(";"c)
                        mail.To.Add(recipient.Trim())
                    Next
                    mail.Subject = message.Subject
                    mail.Body = $"{message.Body}{Environment.NewLine}{Environment.NewLine}Timestamp: {message.Timestamp}"
                    mail.Priority = If(message.Priority = NotificationPriority.High,
                             MailPriority.High, MailPriority.Normal)

                    Await _smtpClient.SendMailAsync(mail)
                    _logger.LogInfo($"Email sent successfully: {message.Subject}")
                End Using
            Catch ex As Exception
                _logger.LogError($"Failed to send email: {ex.Message}")
                If message.RetryCount < 3 Then
                    message.RetryCount += 1
                    _emailQueue.Enqueue(message)
                End If
            End Try
        End Function

        Public Sub QueueNotification(subject As String, body As String, priority As NotificationPriority)
                ThrowIfDisposed()

                Try
                    If Not _isInitialized OrElse Not Boolean.Parse(_emailSettings("NotificationsEnabled")) Then
                        Return
                    End If

                    Dim message = New EmailMessage With {
                        .Subject = subject,
                        .Body = body,
                        .Priority = priority,
                        .Timestamp = DateTime.Now
                    }

                    _emailQueue.Enqueue(message)
                    _logger.LogInfo($"Email notification queued: {subject}")
                Catch ex As Exception
                    _logger.LogError($"Error queueing notification: {ex.Message}")
                End Try
            End Sub

        Public Async Function SendEmailAsync(message As EmailMessage) As Task
            Try
                Using mail As New MailMessage()
                    mail.From = New MailAddress(_emailSettings("EmailFrom"))
                    For Each recipient In _emailSettings("EmailTo").Split(";"c)
                        mail.To.Add(recipient.Trim())
                    Next
                    mail.Subject = message.Subject
                    mail.Body = $"{message.Body}{Environment.NewLine}{Environment.NewLine}Timestamp: {message.Timestamp}"
                    mail.Priority = If(message.Priority = NotificationPriority.High,
                                     MailPriority.High, MailPriority.Normal)

                    Await _smtpClient.SendMailAsync(mail)
                    _logger.LogInfo($"Email sent successfully: {message.Subject}")
                End Using
            Catch ex As Exception
                _logger.LogError($"Failed to send email: {ex.Message}")
                If message.RetryCount < 3 Then
                    message.RetryCount += 1
                    _emailQueue.Enqueue(message)
                End If
            End Try
        End Function

        Private Sub ThrowIfDisposed()
            If _disposed Then
                Throw New ObjectDisposedException(GetType(NotificationManager).FullName)
            End If
        End Sub

    End Class

    Public Enum NotificationPriority
        Normal
        High
    End Enum

    Public Class EmailMessage
        Public Property Subject As String
        Public Property Body As String
        Public Property Priority As NotificationPriority
        Public Property Timestamp As DateTime
        Public Property RetryCount As Integer = 0
    End Class
End Namespace