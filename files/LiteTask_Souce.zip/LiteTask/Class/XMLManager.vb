Imports System.Xml
Imports LiteTask.LiteTask.ScheduledTask

Namespace LiteTask
    Public Class XMLManager
        Private _filePath As String
        Private _logger As Logger

        Public Sub New(filePath As String)
            Try
                If String.IsNullOrWhiteSpace(filePath) Then
                    Throw New ArgumentException("File path cannot be null or empty.", NameOf(filePath))
                End If

                _filePath = filePath
                EnsureConfigFileExists()

            Catch ex As Exception
                Dim errorMessage = $"Error initializing XMLManager with file path '{filePath}': {ex.Message}"
                Console.WriteLine(errorMessage)
                Console.WriteLine($"StackTrace: {ex.StackTrace}")
                Throw New InvalidOperationException(errorMessage, ex)
            End Try
        End Sub

        Private Sub AddElement(xmlDoc As XmlDocument, parent As XmlElement, name As String, value As String)
            If Not String.IsNullOrEmpty(value) Then
                Dim element As XmlElement = xmlDoc.CreateElement(name)
                element.InnerText = value
                parent.AppendChild(element)
            End If
        End Sub

        Private Sub CreateDefaultConfig()
            Try
                Dim xmlDoc As New XmlDocument()
                Dim declaration = xmlDoc.CreateXmlDeclaration("1.0", "UTF-8", Nothing)
                xmlDoc.AppendChild(declaration)

                Dim root = xmlDoc.CreateElement("LiteTaskSettings")
                xmlDoc.AppendChild(root)

                ' Add Logging section with all required settings
                Dim loggingSection = xmlDoc.CreateElement("Logging")
                loggingSection.AppendChild(CreateElement(xmlDoc, "LogFolder", Path.Combine(Application.StartupPath, "LiteTaskData", "logs")))
                loggingSection.AppendChild(CreateElement(xmlDoc, "LogLevel", "Info"))
                loggingSection.AppendChild(CreateElement(xmlDoc, "MaxLogSize", "10"))
                loggingSection.AppendChild(CreateElement(xmlDoc, "LogRetentionDays", "30"))
                loggingSection.AppendChild(CreateElement(xmlDoc, "AlertLevel", "Error"))
                root.AppendChild(loggingSection)

                ' Add Email section with all required settings
                Dim emailSection = xmlDoc.CreateElement("EmailSettings")
                emailSection.AppendChild(CreateElement(xmlDoc, "NotificationsEnabled", "False"))
                emailSection.AppendChild(CreateElement(xmlDoc, "SmtpServer", ""))
                emailSection.AppendChild(CreateElement(xmlDoc, "SmtpPort", "25"))
                emailSection.AppendChild(CreateElement(xmlDoc, "UseSSL", "True"))
                emailSection.AppendChild(CreateElement(xmlDoc, "EmailFrom", ""))
                emailSection.AppendChild(CreateElement(xmlDoc, "EmailTo", ""))
                emailSection.AppendChild(CreateElement(xmlDoc, "UseCredentials", "False"))
                emailSection.AppendChild(CreateElement(xmlDoc, "CredentialTarget", ""))
                emailSection.AppendChild(CreateElement(xmlDoc, "AlertLevel", "Error"))
                root.AppendChild(emailSection)

                xmlDoc.Save(_filePath)
            Catch ex As Exception
                _logger?.LogError($"Error creating default configuration: {ex.Message}")
                Throw New Exception("Failed to create default configuration file", ex)
            End Try
        End Sub

        Private Function CreateElement(xmlDoc As XmlDocument, name As String, value As String) As XmlElement
            Dim element = xmlDoc.CreateElement(name)
            element.InnerText = value
            Return element
        End Function

        Public Sub DeleteTask(taskName As String)
            Try
                _logger.LogInfo($"Attempting to delete task: {taskName}")

                If String.IsNullOrEmpty(taskName) Then
                    Throw New ArgumentException("Task name cannot be null or empty", NameOf(taskName))
                End If

                ' Load XML document
                Dim xmlDoc As New XmlDocument()
                If Not File.Exists(_filePath) Then
                    _logger.LogWarning($"XML file not found at {_filePath}")
                    Return
                End If

                xmlDoc.Load(_filePath)

                ' Find the task node
                Dim taskNode As XmlNode = xmlDoc.SelectSingleNode($"LiteTaskSettings/Tasks/Task[@Name='{taskName}']")
                If taskNode IsNot Nothing Then
                    ' Check if Tasks parent node exists
                    Dim tasksNode = taskNode.ParentNode
                    If tasksNode Is Nothing Then
                        _logger.LogError("Tasks parent node not found")
                        Return
                    End If

                    ' Remove the task node
                    tasksNode.RemoveChild(taskNode)

                    ' Save the document
                    xmlDoc.Save(_filePath)
                    _logger.LogInfo($"Task {taskName} deleted successfully from XML")

                    ' Optional: Save a backup of the XML file
                    Dim backupPath = Path.Combine(
                Path.GetDirectoryName(_filePath),
                $"backup_{Path.GetFileNameWithoutExtension(_filePath)}_{DateTime.Now:yyyyMMddHHmmss}.xml")
                    xmlDoc.Save(backupPath)
                    _logger.LogInfo($"XML backup created at: {backupPath}")
                Else
                    _logger.LogWarning($"Task {taskName} not found in XML file")
                End If

            Catch ex As Exception
                _logger.LogError($"Error deleting task {taskName} from XML: {ex.Message}")
                _logger.LogError($"StackTrace: {ex.StackTrace}")
                Throw New Exception($"Failed to delete task from XML: {ex.Message}", ex)
            End Try
        End Sub

        Private Sub EnsureConfigFileExists()
            If Not File.Exists(_filePath) Then
                CreateDefaultConfig()
            End If
        End Sub

        Public Sub ExportTasks(filePath As String, tasks As IEnumerable(Of ScheduledTask))
            Try
                _logger.LogInfo($"Exporting tasks to file: {filePath}")

                ' Create new XML document for export
                Dim xmlDoc As New XmlDocument()
                xmlDoc.AppendChild(xmlDoc.CreateXmlDeclaration("1.0", "UTF-8", Nothing))

                ' Create root element specifically for tasks
                Dim root = xmlDoc.CreateElement("LiteTaskExport")
                xmlDoc.AppendChild(root)

                ' Create Tasks container
                Dim tasksElement = xmlDoc.CreateElement("Tasks")
                root.AppendChild(tasksElement)

                ' Export each task
                For Each task In tasks
                    Dim taskElement As XmlElement = xmlDoc.CreateElement("Task")
                    taskElement.SetAttribute("Name", task.Name)

                    ' Add basic task info
                    AddElement(xmlDoc, taskElement, "Description", task.Description)
                    AddElement(xmlDoc, taskElement, "StartTime", task.StartTime.ToString("o"))
                    AddElement(xmlDoc, taskElement, "RecurrenceType", CType(task.Schedule, Integer).ToString())
                    AddElement(xmlDoc, taskElement, "Interval", task.Interval.TotalMinutes.ToString())
                    AddElement(xmlDoc, taskElement, "DailyTimes", String.Join(",", task.DailyTimes.Select(Function(t) t.ToString())))
                    AddElement(xmlDoc, taskElement, "NextRunTime", task.NextRunTime.ToString("o"))
                    AddElement(xmlDoc, taskElement, "CredentialTarget", task.CredentialTarget)
                    AddElement(xmlDoc, taskElement, "AccountType", task.AccountType)
                    AddElement(xmlDoc, taskElement, "UserSid", task.UserSid)
                    AddElement(xmlDoc, taskElement, "ExecutionMode", CType(task.ExecutionMode, Integer).ToString())

                    If task.NextTaskId.HasValue Then
                        AddElement(xmlDoc, taskElement, "NextTaskId", task.NextTaskId.Value.ToString())
                    End If

                    ' Export actions
                    Dim actionsElement = xmlDoc.CreateElement("Actions")
                    For Each action In task.Actions
                        Dim actionElement = xmlDoc.CreateElement("Action")
                        AddElement(xmlDoc, actionElement, "Name", action.Name)
                        AddElement(xmlDoc, actionElement, "Order", action.Order.ToString())
                        AddElement(xmlDoc, actionElement, "Type", CType(action.Type, Integer).ToString())
                        AddElement(xmlDoc, actionElement, "Target", action.Target)
                        AddElement(xmlDoc, actionElement, "Parameters", action.Parameters)
                        AddElement(xmlDoc, actionElement, "RequiresElevation", action.RequiresElevation.ToString())
                        AddElement(xmlDoc, actionElement, "DependsOn", action.DependsOn)
                        AddElement(xmlDoc, actionElement, "WaitForCompletion", action.WaitForCompletion.ToString())
                        AddElement(xmlDoc, actionElement, "TimeoutMinutes", action.TimeoutMinutes.ToString())
                        AddElement(xmlDoc, actionElement, "RetryCount", action.RetryCount.ToString())
                        AddElement(xmlDoc, actionElement, "RetryDelayMinutes", action.RetryDelayMinutes.ToString())
                        AddElement(xmlDoc, actionElement, "ContinueOnError", action.ContinueOnError.ToString())
                        actionsElement.AppendChild(actionElement)
                    Next

                    taskElement.AppendChild(actionsElement)
                    tasksElement.AppendChild(taskElement)
                Next

                ' Save to file
                xmlDoc.Save(filePath)
                _logger.LogInfo($"Successfully exported {tasks.Count()} tasks to {filePath}")

            Catch ex As Exception
                _logger.LogError($"Error exporting tasks: {ex.Message}")
                _logger.LogError($"StackTrace: {ex.StackTrace}")
                Throw
            End Try
        End Sub

        Public Function GetAllTaskNames() As List(Of String)
            Try
                _logger?.LogInfo("Getting all task names")
                Dim taskNames As New List(Of String)

                If String.IsNullOrEmpty(_filePath) Then
                    _logger?.LogError("File path is null or empty")
                    Return taskNames
                End If

                If Not File.Exists(_filePath) Then
                    _logger?.LogError($"XML file does not exist: {_filePath}")
                    Return taskNames
                End If

                Dim xmlDoc As New XmlDocument()
                xmlDoc.Load(_filePath)

                Dim tasksNode As XmlNode = xmlDoc.SelectSingleNode("LiteTaskSettings/Tasks")
                If tasksNode IsNot Nothing Then
                    Dim taskNodes As XmlNodeList = tasksNode.SelectNodes("Task")
                    For Each taskNode As XmlNode In taskNodes
                        Dim nameAttribute As XmlAttribute = taskNode.Attributes("Name")
                        If nameAttribute IsNot Nothing Then
                            taskNames.Add(nameAttribute.Value)
                        End If
                    Next
                Else
                    _logger?.LogInfo("No 'Tasks' node found in the XML file")
                End If

                _logger?.LogInfo($"Found {taskNames.Count} tasks")
                Return taskNames
            Catch ex As Exception
                _logger?.LogError($"Error getting all task names: {ex.Message}")
                _logger?.LogError($"StackTrace: {ex.StackTrace}")
                Return New List(Of String)() ' Return an empty list instead of throwing
            End Try
        End Function

        Private Function GetDefaultEmailSettings() As Dictionary(Of String, String)
            Return New Dictionary(Of String, String) From {
            {"NotificationsEnabled", "False"},
            {"SmtpServer", ""},
            {"SmtpPort", "25"},
            {"UseSSL", "True"},
            {"EmailFrom", ""},
            {"EmailTo", ""},
            {"UseCredentials", "False"},
            {"CredentialTarget", ""},
            {"AlertLevel", "Error"}
        }
        End Function

        Private Function GetDefaultLogSettings() As Dictionary(Of String, String)
            Return New Dictionary(Of String, String) From {
            {"LogFolder", Path.Combine(Application.StartupPath, "LiteTaskData", "logs")},
            {"LogLevel", "Info"},
            {"MaxLogSize", "10"},
            {"LogRetentionDays", "30"},
            {"AlertLevel", "Error"}
        }
        End Function

        Public Function GetElementValue(node As XmlNode, elementName As String, Optional defaultValue As String = "") As String
            Try
                Dim element As XmlNode = node.SelectSingleNode(elementName)
                Return If(element IsNot Nothing AndAlso Not String.IsNullOrEmpty(element.InnerText),
                     element.InnerText,
                     defaultValue)
            Catch ex As Exception
                _logger?.LogError($"Error getting element value for {elementName}: {ex.Message}")
                Return defaultValue
            End Try
        End Function

        Public Function GetEmailSettings() As Dictionary(Of String, String)
            Try
                Dim settings As New Dictionary(Of String, String)
                Dim xmlDoc As New XmlDocument()

                ' Return default settings if file doesn't exist
                If Not File.Exists(_filePath) Then
                    Return GetDefaultEmailSettings()
                End If

                xmlDoc.Load(_filePath)
                Dim emailNode = xmlDoc.SelectSingleNode("LiteTaskSettings/EmailSettings")

                If emailNode IsNot Nothing Then
                    settings("NotificationsEnabled") = GetElementValue(emailNode, "NotificationsEnabled", "False")
                    settings("SmtpServer") = GetElementValue(emailNode, "SmtpServer", "")
                    settings("SmtpPort") = GetElementValue(emailNode, "SmtpPort", "25")
                    settings("UseSSL") = GetElementValue(emailNode, "UseSSL", "True")
                    settings("EmailFrom") = GetElementValue(emailNode, "EmailFrom", "")
                    settings("EmailTo") = GetElementValue(emailNode, "EmailTo", "")
                    settings("UseCredentials") = GetElementValue(emailNode, "UseCredentials", "False")
                    settings("CredentialTarget") = GetElementValue(emailNode, "CredentialTarget", "")
                    settings("AlertLevel") = GetElementValue(emailNode, "AlertLevel", "Error")
                Else
                    Return GetDefaultEmailSettings()
                End If

                Return settings
            Catch ex As Exception
                _logger?.LogError($"Error reading email settings: {ex.Message}")
                Return GetDefaultEmailSettings()
            End Try
        End Function

        Public Function GetLiteRunDefaults() As Dictionary(Of String, String)
            Dim defaults As New Dictionary(Of String, String)
            defaults("Timeout") = ReadValue("LiteRunDefaults", "Timeout", "300")
            defaults("LogOutputPath") = ReadValue("LiteRunDefaults", "LogOutputPath", Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "LiteRunLogs"))
            ' Add more default parameters as needed
            Return defaults
        End Function

        Public Function GetLogSettings() As Dictionary(Of String, String)
            Try
                Dim settings As New Dictionary(Of String, String)
                Dim xmlDoc As New XmlDocument()

                ' Return default settings if file doesn't exist
                If Not File.Exists(_filePath) Then
                    Return GetDefaultLogSettings()
                End If

                xmlDoc.Load(_filePath)
                Dim loggingNode = xmlDoc.SelectSingleNode("LiteTaskSettings/Logging")

                If loggingNode IsNot Nothing Then
                    settings("LogFolder") = GetElementValue(loggingNode, "LogFolder", Path.Combine(Application.StartupPath, "LiteTaskData", "logs"))
                    settings("LogLevel") = GetElementValue(loggingNode, "LogLevel", "Info")
                    settings("MaxLogSize") = GetElementValue(loggingNode, "MaxLogSize", "10")
                    settings("LogRetentionDays") = GetElementValue(loggingNode, "LogRetentionDays", "30")
                    settings("AlertLevel") = GetElementValue(loggingNode, "AlertLevel", "Error")
                Else
                    Return GetDefaultLogSettings()
                End If

                Return settings
            Catch ex As Exception
                _logger?.LogError($"Error reading log settings: {ex.Message}")
                Return GetDefaultLogSettings()
            End Try
        End Function

        Public Function LoadTask(taskName As String) As ScheduledTask
            Try
                _logger?.LogInfo($"Loading task: {taskName}")
                Dim xmlDoc As New XmlDocument()
                xmlDoc.Load(_filePath)

                Dim taskNode As XmlNode = xmlDoc.SelectSingleNode($"LiteTaskSettings/Tasks/Task[@Name='{taskName}']")
                If taskNode Is Nothing Then
                    _logger?.LogWarning($"Task {taskName} not found")
                    Return Nothing
                End If

                Dim task As New ScheduledTask With {
                .Name = taskName,
                .Description = GetElementValue(taskNode, "Description"),
                .StartTime = DateTime.Parse(GetElementValue(taskNode, "StartTime", DateTime.Now.ToString("o"))),
                .Schedule = CType(Integer.Parse(GetElementValue(taskNode, "RecurrenceType", "0")), RecurrenceType),
                .Interval = TimeSpan.FromMinutes(Double.Parse(GetElementValue(taskNode, "Interval", "0"))),
                .NextRunTime = DateTime.Parse(GetElementValue(taskNode, "NextRunTime", DateTime.Now.ToString("o"))),
                .CredentialTarget = GetElementValue(taskNode, "CredentialTarget"),
                .AccountType = GetElementValue(taskNode, "AccountType", "Current User"),
                .UserSid = GetElementValue(taskNode, "UserSid"),
                .ExecutionMode = CType(Integer.Parse(GetElementValue(taskNode, "ExecutionMode", "0")), TaskExecutionMode)
            }

                ' Load daily times
                Dim dailyTimesString = GetElementValue(taskNode, "DailyTimes")
                If Not String.IsNullOrWhiteSpace(dailyTimesString) Then
                    task.DailyTimes = dailyTimesString.Split(",").
                    Where(Function(t) Not String.IsNullOrWhiteSpace(t)).
                    Select(Function(t) TimeSpan.Parse(t.Trim())).
                    ToList()
                End If

                ' Load next task ID if present
                Dim nextTaskIdString = GetElementValue(taskNode, "NextTaskId")
                If Not String.IsNullOrEmpty(nextTaskIdString) Then
                    task.NextTaskId = Integer.Parse(nextTaskIdString)
                End If

                ' Load actions
                Dim actionsNode = taskNode.SelectSingleNode("Actions")
                If actionsNode IsNot Nothing Then
                    For Each actionNode As XmlNode In actionsNode.SelectNodes("Action")
                        Dim action As New TaskAction With {
                        .Name = GetElementValue(actionNode, "Name"),
                        .Order = Integer.Parse(GetElementValue(actionNode, "Order", "1")),
                        .Type = CType(Integer.Parse(GetElementValue(actionNode, "Type", "0")), TaskType),
                        .Target = GetElementValue(actionNode, "Target"),
                        .Parameters = GetElementValue(actionNode, "Parameters"),
                        .RequiresElevation = Boolean.Parse(GetElementValue(actionNode, "RequiresElevation", "False")),
                        .DependsOn = GetElementValue(actionNode, "DependsOn"),
                        .WaitForCompletion = Boolean.Parse(GetElementValue(actionNode, "WaitForCompletion", "True")),
                        .TimeoutMinutes = Integer.Parse(GetElementValue(actionNode, "TimeoutMinutes", "60")),
                        .RetryCount = Integer.Parse(GetElementValue(actionNode, "RetryCount", "0")),
                        .RetryDelayMinutes = Integer.Parse(GetElementValue(actionNode, "RetryDelayMinutes", "5")),
                        .ContinueOnError = Boolean.Parse(GetElementValue(actionNode, "ContinueOnError", "False"))
                    }
                        task.Actions.Add(action)
                    Next
                End If

                Return task
            Catch ex As Exception
                _logger?.LogError($"Error loading task {taskName}: {ex.Message}")
                _logger?.LogError($"StackTrace: {ex.StackTrace}")
                Return Nothing
            End Try
        End Function

        Public Function ReadValue(section As String, key As String, defaultValue As String) As String
            Try
                Dim xmlDoc As New XmlDocument()
                xmlDoc.Load(_filePath)

                Dim node As XmlNode = xmlDoc.SelectSingleNode($"LiteTaskSettings/{section}/{key}")
                If node IsNot Nothing Then
                    Return node.InnerText
                Else
                    Return defaultValue
                End If
            Catch ex As Exception
                _logger.LogError($"Error reading value for {section}/{key}: {ex.Message}")
                Return defaultValue
            End Try
        End Function

        Public Sub SaveEmailSettings(smtpServer As String, smtpPort As Integer, emailFrom As String, emailTo As String,
                               enabled As Boolean, useSSL As Boolean)
            Try
                WriteValue("EmailSettings", "NotificationsEnabled", enabled.ToString())
                WriteValue("EmailSettings", "SmtpServer", smtpServer)
                WriteValue("EmailSettings", "SmtpPort", smtpPort.ToString())
                WriteValue("EmailSettings", "UseSSL", useSSL.ToString())
                WriteValue("EmailSettings", "EmailFrom", emailFrom)
                WriteValue("EmailSettings", "EmailTo", emailTo)
            Catch ex As Exception
                _logger?.LogError($"Error saving email settings: {ex.Message}")
                Throw
            End Try
        End Sub

        Public Sub SaveLogSettings(logFolder As String, logLevel As String, maxLogSize As Integer, retentionDays As Integer)
            Try
                WriteValue("Logging", "LogFolder", logFolder)
                WriteValue("Logging", "LogLevel", logLevel)
                WriteValue("Logging", "MaxLogSize", maxLogSize.ToString())
                WriteValue("Logging", "LogRetentionDays", retentionDays.ToString())
            Catch ex As Exception
                _logger?.LogError($"Error saving log settings: {ex.Message}")
                Throw
            End Try
        End Sub

        Public Sub SaveTask(task As ScheduledTask)
            Try
                Dim xmlDoc As New XmlDocument()
                If Not File.Exists(_filePath) Then
                    xmlDoc.LoadXml("<LiteTaskSettings><Tasks></Tasks></LiteTaskSettings>")
                Else
                    xmlDoc.Load(_filePath)
                End If

                Dim tasksNode As XmlNode = xmlDoc.SelectSingleNode("LiteTaskSettings/Tasks")
                If tasksNode Is Nothing Then
                    tasksNode = xmlDoc.CreateElement("Tasks")
                    xmlDoc.DocumentElement.AppendChild(tasksNode)
                End If

                ' Remove existing task if it exists
                Dim existingTask As XmlNode = tasksNode.SelectSingleNode($"Task[@Name='{task.Name}']")
                If existingTask IsNot Nothing Then
                    tasksNode.RemoveChild(existingTask)
                End If

                ' Create new task element
                Dim taskElement As XmlElement = xmlDoc.CreateElement("Task")
                taskElement.SetAttribute("Name", task.Name)

                ' Save basic task info
                AddElement(xmlDoc, taskElement, "Description", task.Description)
                AddElement(xmlDoc, taskElement, "StartTime", task.StartTime.ToString("o"))
                AddElement(xmlDoc, taskElement, "RecurrenceType", CType(task.Schedule, Integer).ToString())
                AddElement(xmlDoc, taskElement, "Interval", task.Interval.TotalMinutes.ToString())
                AddElement(xmlDoc, taskElement, "DailyTimes", String.Join(",", task.DailyTimes.Select(Function(t) t.ToString())))
                AddElement(xmlDoc, taskElement, "NextRunTime", task.NextRunTime.ToString("o"))
                AddElement(xmlDoc, taskElement, "CredentialTarget", task.CredentialTarget)
                AddElement(xmlDoc, taskElement, "AccountType", task.AccountType)
                AddElement(xmlDoc, taskElement, "UserSid", task.UserSid)
                AddElement(xmlDoc, taskElement, "ExecutionMode", CType(task.ExecutionMode, Integer).ToString())

                If task.NextTaskId.HasValue Then
                    AddElement(xmlDoc, taskElement, "NextTaskId", task.NextTaskId.Value.ToString())
                End If

                ' Save actions
                Dim actionsElement As XmlElement = xmlDoc.CreateElement("Actions")
                For Each action In task.Actions
                    Dim actionElement As XmlElement = xmlDoc.CreateElement("Action")
                    AddElement(xmlDoc, actionElement, "Name", action.Name)
                    AddElement(xmlDoc, actionElement, "Order", action.Order.ToString())
                    AddElement(xmlDoc, actionElement, "Type", CType(action.Type, Integer).ToString())
                    AddElement(xmlDoc, actionElement, "Target", action.Target)
                    AddElement(xmlDoc, actionElement, "Parameters", action.Parameters)
                    AddElement(xmlDoc, actionElement, "RequiresElevation", action.RequiresElevation.ToString())

                    ' Add dependency information
                    If action.DependsOn IsNot Nothing Then
                        AddElement(xmlDoc, actionElement, "DependsOn", action.DependsOn)
                    End If
                    AddElement(xmlDoc, actionElement, "WaitForCompletion", action.WaitForCompletion.ToString())
                    AddElement(xmlDoc, actionElement, "TimeoutMinutes", action.TimeoutMinutes.ToString())
                    AddElement(xmlDoc, actionElement, "RetryCount", action.RetryCount.ToString())
                    AddElement(xmlDoc, actionElement, "RetryDelayMinutes", action.RetryDelayMinutes.ToString())
                    AddElement(xmlDoc, actionElement, "ContinueOnError", action.ContinueOnError.ToString())

                    actionsElement.AppendChild(actionElement)
                Next
                taskElement.AppendChild(actionsElement)

                tasksNode.AppendChild(taskElement)
                xmlDoc.Save(_filePath)
            Catch ex As Exception
                _logger?.LogError($"Error saving task {task?.Name}: {ex.Message}")
                _logger?.LogError($"StackTrace: {ex.StackTrace}")
                Throw
            End Try
        End Sub

        Public Sub WriteValue(section As String, key As String, value As String)
            Try
                Dim xmlDoc As New XmlDocument()
                xmlDoc.Load(_filePath)

                Dim sectionNode As XmlNode = xmlDoc.SelectSingleNode($"LiteTaskSettings/{section}")
                If sectionNode Is Nothing Then
                    sectionNode = xmlDoc.CreateElement(section)
                    xmlDoc.DocumentElement.AppendChild(sectionNode)
                End If

                Dim keyNode As XmlNode = sectionNode.SelectSingleNode(key)
                If keyNode Is Nothing Then
                    keyNode = xmlDoc.CreateElement(key)
                    sectionNode.AppendChild(keyNode)
                End If

                keyNode.InnerText = value
                xmlDoc.Save(_filePath)
            Catch ex As Exception
                _logger.LogError($"Error writing value for {section}/{key}: {ex.Message}")
            End Try
        End Sub

    End Class
End Namespace