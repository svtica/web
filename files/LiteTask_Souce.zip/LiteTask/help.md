# LiteTask Help

This document provides detailed information on how to use LiteTask, a lightweight task scheduling application for Windows.

## Table of Contents

1. [Task Types](#task-types)
2. [Creating Tasks](#creating-tasks)
3. [Task Chaining](#task-chaining)
4. [Scheduling Options](#scheduling-options)
5. [Credential Management](#credential-management)
6. [Remote Execution](#remote-execution)
7. [Command-line Interface](#command-line-interface)
8. [Tool Management](#tool-management)
9. [PowerShell Module Management](#powershell-module-management)
10. [Troubleshooting](#troubleshooting)

## Task Types

LiteTask supports the following task types:

1. **PowerShell**: Execute PowerShell scripts with support for parameter filtering and CredSSP authentication.
2. **Batch**: Run batch files or command scripts.
3. **SQL**: Execute SQL scripts using OSQL with support for Windows and SQL authentication.
4. **Remote Execution**: Run tasks on remote machines using various methods.
5. **Executable**: Run any executable file with specified arguments.

## Actions System

LiteTask uses a powerful Action system that allows complex task execution flows:

### Action Properties
- **Name**: Unique identifier for the action
- **Type**: The type of action (PowerShell, Batch, SQL, etc.)
- **Target**: Path or target of the action
- **Parameters**: Additional parameters for execution
- **Requires Elevation**: Whether the action needs administrative privileges

### Action Dependencies
Actions can be configured with dependencies:
- **Depends On**: Specify other tasks that must complete before this action
- **Wait for Completion**: Whether to wait for dependent tasks to finish
- **Timeout**: Maximum time to wait for completion (in minutes)
- **Retry Count**: Number of retry attempts if action fails
- **Retry Delay**: Time to wait between retries (in minutes)
- **Continue on Error**: Whether to continue with next action if this one fails

### Action Order
- Actions are executed in the order defined
- Dependencies are respected during execution
- Actions can be moved up/down to change execution order
- Parallel execution is supported when dependencies allow

### Managing Actions
1. In the task editor, use the Actions tab to manage actions
2. Use Add/Edit/Delete buttons to modify actions
3. Use Move Up/Down to change execution order
4. Configure dependencies in the action properties
5. Set retry and error handling options as needed

## Creating Tasks

To create a new task:

1. Click the "Create Task" button in the ribbon menu.
2. Fill in the task details:
   - Name: A unique identifier for the task
   - Description: A brief explanation of the task's purpose
   - Type: Select the task type from the dropdown
   - File Path: Path to the script or executable
   - Arguments: Any command-line arguments for the task
   - Schedule: Set the execution schedule (see Scheduling Options)
   - Credentials: Select the credentials to use for execution
   - Requires Elevation: Check if the task needs administrative privileges
   - Remote Execution: Configure settings for remote tasks
   - Next Task: Optionally select a task to run after this one completes

## Task Chaining

LiteTask supports task chaining, allowing you to create sequences of tasks that run one after another.

To chain tasks:

1. When creating or editing a task, use the "Next Task" dropdown to select another task to run after the current one completes.
2. Tasks will execute in the order they are chained.
3. To end a chain, leave the "Next Task" as "(None)" for the last task in the sequence.

Notes:
- A task cannot be chained to itself.
- Circular chains are not allowed and will be prevented by the UI.
- If a task in the chain fails, subsequent tasks will not be executed.

## Scheduling Options

LiteTask offers three scheduling options:

1. **One Time**: Execute the task once at a specified date and time.
2. **Interval**: Run the task repeatedly at a fixed interval (e.g., every 30 minutes).
3. **Daily**: Execute the task at specific times each day.

To set up a schedule:

1. Select the desired recurrence type.
2. For One Time tasks, set the date and time for execution.
3. For Interval tasks, specify the interval in minutes.
4. For Daily tasks, add one or more execution times.

## Credential Management

LiteTask provides a secure credential management system:

1. Open the Credential Manager from the Tools tab.
2. Add, edit, or delete credentials for different account types:
   - Current User
   - Service Account
   - Windows Vault
   - Stored Account

When creating or editing tasks, you can select the appropriate credentials to use for execution.

## Remote Execution

LiteTask supports various methods for remote execution:

1. **SecureChannel**: A custom implementation for secure remote communication.
2. **PSRemoting**: Use PowerShell remoting for task execution.
3. **CredSSP**: Utilize Credential Security Support Provider for enhanced security.
4. **OSQL**: Execute SQL tasks remotely using OSQL.

To configure remote execution:

1. When creating or editing a task, check the "Execute Remotely" option.
2. Enter the remote server URL.
3. Select the remote execution method.
4. Ensure the necessary credentials are set up in the Credential Manager.

## Command-line Interface

LiteTask can be controlled via command-line for automation and advanced usage:

- `LiteTask.exe -register`: Register the Windows service
- `LiteTask.exe -unregister`: Unregister the Windows service
- `LiteTask.exe -start`: Start the service
- `LiteTask.exe -stop`: Stop the service
- `LiteTask.exe -runtask TaskName`: Run a specific task
- `LiteTask.exe -debug`: Run in debug mode
- `LiteTask.exe -console`: Run in console mode
- `LiteTask.exe -runas username taskname`: Run a task as a specific user

## Tool Management

LiteTask includes built-in tool management for required utilities:

1. Access the Tools tab in the ribbon menu.
2. Use "Check Tools" to verify the presence of required tools.
3. Click "Update Tools" to download and update the necessary utilities.

Managed tools include:
- Process Explorer (procexp.exe)
- LiteRun
- OSQL

## PowerShell Module Management

LiteTask now includes PowerShell module management capabilities:

1. Access the Tools menu and select "Install PowerShell Modules".
2. Choose from available modules to install:
   - Az: Azure PowerShell module for managing Azure resources
   - AzureAD: Azure Active Directory management
   - MSOnline: Microsoft 365 management
   - PSWindowsUpdate: Windows Update management
   - PSBlueTeam: Security and hardening tools
   - Pester: Testing framework for PowerShell
   - ImportExcel: Excel import/export capabilities
   - VMware.PowerCLI: VMware infrastructure management
   - SqlServer: SQL Server management
   - AWS.Tools.Common: AWS PowerShell tools

Installed modules are automatically available for:
- PowerShell tasks
- PowerShell scripts run from the Run tab
- Remote PowerShell execution

Modules are installed to the LiteTaskData\Modules directory and are isolated from system-wide PowerShell modules.

## Troubleshooting

If you encounter issues:

1. Check the application log file (app_log.txt) in the LiteTask directory for error messages.
2. Ensure all required tools are present and up-to-date.
3. Verify that the necessary permissions are granted for task execution, especially for elevated or remote tasks.
4. For remote execution issues, check network connectivity and firewall settings.
5. If using SQL tasks, ensure the OSQL utility is properly configured and accessible.
6. When using task chaining, verify that all tasks in the chain exist and are correctly configured.
7. For PowerShell module issues, check the ModuleInstall.log in the LiteTaskData directory.
8. Review action-specific logs in the logs directory.
9. Verify action dependencies are correctly configured.
10. Check retry settings for failed actions.
11. Monitor action execution order and timing.
12. Review timeout settings for long-running actions.

For further assistance, please check the [GitHub issues](https://github.com/svtica/LiteTask/issues) or submit a new issue if you encounter a bug or have a feature request.