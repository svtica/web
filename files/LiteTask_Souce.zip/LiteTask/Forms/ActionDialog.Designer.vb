Imports System.Drawing
Imports LiteTask.LiteTask.ScheduledTask

Namespace LiteTask
    <Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
    Partial Class ActionDialog
        Inherits System.Windows.Forms.Form

        'Form overrides dispose to clean up the component list.
        <System.Diagnostics.DebuggerNonUserCode()>
        Protected Overrides Sub Dispose(ByVal disposing As Boolean)
            Try
                If disposing AndAlso components IsNot Nothing Then
                    components.Dispose()
                End If
            Finally
                MyBase.Dispose(disposing)
            End Try
        End Sub

        'Required by the Windows Form Designer
        Private components As System.ComponentModel.IContainer

        'NOTE: The following procedure is required by the Windows Form Designer
        'It can be modified using the Windows Form Designer.  
        'Do not modify it using the code editor.
        <System.Diagnostics.DebuggerStepThrough()>
        Private Sub InitializeComponent()
            mainLayout = New TableLayoutPanel()
            _nameTextBox = New TextBox()
            _typeComboBox = New ComboBox()
            _targetTextBox = New TextBox()
            _browseButton = New Button()
            _parametersTextBox = New TextBox()
            _dependsOnCombo = New ComboBox()
            _waitForCompletionCheck = New CheckBox()
            _timeoutNumeric = New NumericUpDown()
            _retryCountNumeric = New NumericUpDown()
            _requiresElevationCheckBox = New CheckBox()
            _retryDelayNumeric = New NumericUpDown()
            _continueOnErrorCheck = New CheckBox()
            buttonPanel = New FlowLayoutPanel()
            _cancelButton = New Button()
            _okButton = New Button()
            mainLayout.SuspendLayout()
            CType(_timeoutNumeric, ISupportInitialize).BeginInit()
            CType(_retryCountNumeric, ISupportInitialize).BeginInit()
            CType(_retryDelayNumeric, ISupportInitialize).BeginInit()
            buttonPanel.SuspendLayout()
            SuspendLayout()
            ' 
            ' mainLayout
            ' 
            mainLayout.ColumnStyles.Add(New ColumnStyle(SizeType.Absolute, 20F))
            mainLayout.ColumnStyles.Add(New ColumnStyle(SizeType.Absolute, 20F))
            mainLayout.ColumnStyles.Add(New ColumnStyle(SizeType.Absolute, 20F))
            mainLayout.Controls.Add(_nameTextBox, 1, 0)
            mainLayout.Controls.Add(_typeComboBox, 1, 1)
            mainLayout.Controls.Add(_targetTextBox, 1, 2)
            mainLayout.Controls.Add(_browseButton, 2, 2)
            mainLayout.Controls.Add(_parametersTextBox, 1, 3)
            mainLayout.Controls.Add(_dependsOnCombo, 1, 4)
            mainLayout.Controls.Add(_waitForCompletionCheck, 1, 5)
            mainLayout.Controls.Add(_timeoutNumeric, 1, 6)
            mainLayout.Controls.Add(_retryCountNumeric, 1, 7)
            mainLayout.Location = New Point(0, 0)
            mainLayout.Name = "mainLayout"
            mainLayout.RowStyles.Add(New RowStyle(SizeType.Absolute, 20F))
            mainLayout.RowStyles.Add(New RowStyle(SizeType.Absolute, 20F))
            mainLayout.RowStyles.Add(New RowStyle(SizeType.Absolute, 20F))
            mainLayout.RowStyles.Add(New RowStyle(SizeType.Absolute, 20F))
            mainLayout.RowStyles.Add(New RowStyle(SizeType.Absolute, 20F))
            mainLayout.RowStyles.Add(New RowStyle(SizeType.Absolute, 20F))
            mainLayout.RowStyles.Add(New RowStyle(SizeType.Absolute, 20F))
            mainLayout.RowStyles.Add(New RowStyle(SizeType.Absolute, 20F))
            mainLayout.Size = New Size(200, 100)
            mainLayout.TabIndex = 0
            ' 
            ' _nameTextBox
            ' 
            _nameTextBox.Location = New Point(23, 3)
            _nameTextBox.Name = "_nameTextBox"
            _nameTextBox.Size = New Size(14, 23)
            _nameTextBox.TabIndex = 1
            ' 
            ' _typeComboBox
            ' 
            _typeComboBox.Items.AddRange(New Object() {"PowerShell", "Batch", "SQL", "RemoteExecution", "Executable"})
            _typeComboBox.Location = New Point(23, 23)
            _typeComboBox.Name = "_typeComboBox"
            _typeComboBox.Size = New Size(14, 23)
            _typeComboBox.TabIndex = 3
            ' 
            ' _targetTextBox
            ' 
            _targetTextBox.Location = New Point(23, 43)
            _targetTextBox.Name = "_targetTextBox"
            _targetTextBox.Size = New Size(14, 23)
            _targetTextBox.TabIndex = 5
            ' 
            ' _browseButton
            ' 
            _browseButton.Location = New Point(43, 43)
            _browseButton.Name = "_browseButton"
            _browseButton.Size = New Size(75, 14)
            _browseButton.TabIndex = 6
            ' 
            ' _parametersTextBox
            ' 
            mainLayout.SetColumnSpan(_parametersTextBox, 2)
            _parametersTextBox.Location = New Point(23, 63)
            _parametersTextBox.Name = "_parametersTextBox"
            _parametersTextBox.Size = New Size(100, 23)
            _parametersTextBox.TabIndex = 8
            ' 
            ' _dependsOnCombo
            ' 
            _dependsOnCombo.Items.AddRange(New Object() {"(None)"})
            _dependsOnCombo.Location = New Point(23, 83)
            _dependsOnCombo.Name = "_dependsOnCombo"
            _dependsOnCombo.Size = New Size(14, 23)
            _dependsOnCombo.TabIndex = 10
            ' 
            ' _waitForCompletionCheck
            ' 
            _waitForCompletionCheck.Location = New Point(23, 103)
            _waitForCompletionCheck.Name = "_waitForCompletionCheck"
            _waitForCompletionCheck.Size = New Size(14, 14)
            _waitForCompletionCheck.TabIndex = 11
            ' 
            ' _timeoutNumeric
            ' 
            _timeoutNumeric.Location = New Point(23, 123)
            _timeoutNumeric.Name = "_timeoutNumeric"
            _timeoutNumeric.Size = New Size(14, 23)
            _timeoutNumeric.TabIndex = 13
            ' 
            ' _retryCountNumeric
            ' 
            _retryCountNumeric.Location = New Point(23, 143)
            _retryCountNumeric.Name = "_retryCountNumeric"
            _retryCountNumeric.Size = New Size(14, 23)
            _retryCountNumeric.TabIndex = 15
            ' 
            ' _requiresElevationCheckBox
            ' 
            _requiresElevationCheckBox.Location = New Point(0, 0)
            _requiresElevationCheckBox.Name = "_requiresElevationCheckBox"
            _requiresElevationCheckBox.Size = New Size(104, 24)
            _requiresElevationCheckBox.TabIndex = 0
            ' 
            ' _retryDelayNumeric
            ' 
            _retryDelayNumeric.Location = New Point(0, 0)
            _retryDelayNumeric.Name = "_retryDelayNumeric"
            _retryDelayNumeric.Size = New Size(120, 23)
            _retryDelayNumeric.TabIndex = 0
            ' 
            ' _continueOnErrorCheck
            ' 
            _continueOnErrorCheck.Location = New Point(0, 0)
            _continueOnErrorCheck.Name = "_continueOnErrorCheck"
            _continueOnErrorCheck.Size = New Size(104, 24)
            _continueOnErrorCheck.TabIndex = 0
            ' 
            ' buttonPanel
            ' 
            buttonPanel.Controls.Add(_cancelButton)
            buttonPanel.Controls.Add(_okButton)
            buttonPanel.Location = New Point(0, 0)
            buttonPanel.Name = "buttonPanel"
            buttonPanel.Size = New Size(200, 100)
            buttonPanel.TabIndex = 1
            ' 
            ' _cancelButton
            ' 
            _cancelButton.Location = New Point(3, 3)
            _cancelButton.Name = "_cancelButton"
            _cancelButton.Size = New Size(75, 23)
            _cancelButton.TabIndex = 0
            ' 
            ' _okButton
            ' 
            _okButton.Location = New Point(84, 3)
            _okButton.Name = "_okButton"
            _okButton.Size = New Size(75, 23)
            _okButton.TabIndex = 1
            ' 
            ' ActionDialog
            ' 
            ClientSize = New Size(584, 461)
            Controls.Add(mainLayout)
            Controls.Add(buttonPanel)
            FormBorderStyle = FormBorderStyle.FixedDialog
            MaximizeBox = False
            MinimizeBox = False
            Name = "ActionDialog"
            StartPosition = FormStartPosition.CenterParent
            Text = "Action properties"
            mainLayout.ResumeLayout(False)
            mainLayout.PerformLayout()
            CType(_timeoutNumeric, ISupportInitialize).EndInit()
            CType(_retryCountNumeric, ISupportInitialize).EndInit()
            CType(_retryDelayNumeric, ISupportInitialize).EndInit()
            buttonPanel.ResumeLayout(False)
            ResumeLayout(False)

            'Catch ex As Exception
            '    _logger?.LogError($"Error in InitializeComponent: {ex.Message}")
            '    Throw
            'End Try
        End Sub

        Friend WithEvents mainLayout As TableLayoutPanel
        Friend WithEvents buttonPanel As FlowLayoutPanel


    End Class
End Namespace