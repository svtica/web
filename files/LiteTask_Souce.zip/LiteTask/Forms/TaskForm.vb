Imports System.Drawing
Imports LiteTask.LiteTask.ScheduledTask

Namespace LiteTask
    Public Class TaskForm
        Inherits Form

        Private ReadOnly _credentialManager As CredentialManager
        Private ReadOnly _customScheduler As CustomScheduler
        Private ReadOnly _logger As Logger
        Private _isEditMode As Boolean
        Private _task As ScheduledTask



        Public Sub New(credentialManager As CredentialManager,
                  customScheduler As CustomScheduler,
                  logger As Logger,
                  Optional existingTask As ScheduledTask = Nothing)

            ' This call is required by the designer and must be first
            InitializeComponent()

            Try
                ' Store dependencies
                _credentialManager = credentialManager
                _customScheduler = customScheduler
                _logger = logger

                ' Determine if we're in edit mode
                _isEditMode = (existingTask IsNot Nothing)
                Me.Text = If(_isEditMode, "Edit Task", "Create Task")

                ' Initialize task based on mode
                If _isEditMode Then
                    ' Clone the existing task to avoid modifying the original until save
                    _task = existingTask.Clone()
                Else
                    ' Create new task with default values
                    _task = New ScheduledTask() With {
                    .Actions = New List(Of TaskAction)(),
                    .DailyTimes = New List(Of TimeSpan)(),
                    .Parameters = New Hashtable(),
                    .Schedule = RecurrenceType.OneTime,
                    .StartTime = DateTime.Now,
                    .AccountType = "Current User"
                }
                End If

                ' Initialize form controls with data
                InitializeFormData()
                InitializeActionsGrid()

                ' Add event handlers
                AddEventHandlers()

                _logger?.LogInfo("TaskForm initialized successfully")

            Catch ex As Exception
                _logger?.LogError($"Error initializing TaskForm: {ex.Message}")
                _logger?.LogError($"StackTrace: {ex.StackTrace}")
                Throw New InvalidOperationException("Failed to initialize TaskForm", ex)
            End Try
        End Sub

        Private Sub AddActionButton_Click(sender As Object, e As EventArgs)
            Using dialog As New ActionDialog()
                If dialog.ShowDialog() = DialogResult.OK Then
                    Dim action = dialog.Action
                    action.Order = _task.Actions.Count + 1
                    _task.Actions.Add(action)
                    RefreshActionsList()
                End If
            End Using
        End Sub

        Private Sub AddEventHandlers()
            ' Add handlers for schedule controls
            AddHandler _recurringCheckBox.CheckedChanged, AddressOf RecurringCheckBox_CheckedChanged
            AddHandler _recurrenceTypeCombo.SelectedIndexChanged, AddressOf RecurrenceTypeCombo_SelectedIndexChanged

            ' Add handlers for daily time controls
            AddHandler _addTimeButton.Click, AddressOf AddTimeButton_Click
            AddHandler _removeTimeButton.Click, AddressOf RemoveTimeButton_Click

            ' Add handlers for action controls
            AddHandler _addActionButton.Click, AddressOf AddActionButton_Click
            AddHandler _editActionButton.Click, AddressOf EditActionButton_Click
            AddHandler _deleteActionButton.Click, AddressOf DeleteActionButton_Click
            AddHandler _moveUpButton.Click, AddressOf MoveUpButton_Click
            AddHandler _moveDownButton.Click, AddressOf MoveDownButton_Click
            'AddHandler _actionsGrid.SelectionChanged, AddressOf ActionsGrid_SelectionChanged

            ' Add handlers for form buttons
            AddHandler _okButton.Click, AddressOf OkButton_Click
        End Sub

        Private Sub AddTimeButton_Click(sender As Object, e As EventArgs)
            Dim newTime = _dailyTimePicker.Value.ToString("HH:mm")
            If Not _dailyTimeList.Items.Contains(newTime) Then
                _dailyTimeList.Items.Add(newTime)
                ' Sort times
                Dim times = _dailyTimeList.Items.Cast(Of String)().
                    OrderBy(Function(t) TimeSpan.Parse(t)).
                    ToArray()
                _dailyTimeList.Items.Clear()
                _dailyTimeList.Items.AddRange(times)
            End If
        End Sub

        Private Sub DeleteActionButton_Click(sender As Object, e As EventArgs)
            If _actionsGrid.SelectedRows.Count = 0 Then Return

            Dim index = _actionsGrid.SelectedRows(0).Index
            _task.Actions.RemoveAt(index)
            ReorderActions()
            LoadActions()
        End Sub

        Private Sub EditActionButton_Click(sender As Object, e As EventArgs)
            If _actionsGrid.SelectedRows.Count = 0 Then Return

            Dim index = _actionsGrid.SelectedRows(0).Index
            Dim action = _task.Actions(index)

            Using dialog As New ActionDialog(action)
                If dialog.ShowDialog() = DialogResult.OK Then
                    _task.Actions(index) = dialog.Action
                    RefreshActionsList()
                End If
            End Using
        End Sub

        Private Sub InitializeActionsGrid()
            _actionsGrid.Columns.Clear()
            _actionsGrid.Columns.AddRange(New DataGridViewColumn() {
                New DataGridViewTextBoxColumn() With {
                    .HeaderText = "Order",
                    .Name = "OrderColumn",
                    .Width = 60,
                    .ReadOnly = True
                },
                New DataGridViewTextBoxColumn() With {
                    .HeaderText = "Name",
                    .Name = "NameColumn",
                    .Width = 100,
                    .ReadOnly = True
                },
                New DataGridViewTextBoxColumn() With {
                    .HeaderText = "Type",
                    .Name = "TypeColumn",
                    .Width = 100,
                    .ReadOnly = True
                },
                New DataGridViewTextBoxColumn() With {
                    .HeaderText = "Target",
                    .Name = "TargetColumn",
                    .Width = 200,
                    .ReadOnly = True
                },
                New DataGridViewTextBoxColumn() With {
                    .HeaderText = "Depends On",
                    .Name = "DependsOnColumn",
                    .Width = 100,
                    .ReadOnly = True
                },
                New DataGridViewTextBoxColumn() With {
                    .HeaderText = "Status",
                    .Name = "StatusColumn",
                    .Width = 80,
                    .ReadOnly = True
                }
            })

            RefreshActionsList()
        End Sub

        Private Sub InitializeFormData()
            Try
                ' Initialize credentials combo
                _credentialComboBox.Items.Clear()
                _credentialComboBox.Items.Add("(None)")
                _credentialComboBox.Items.AddRange(_credentialManager.GetAllCredentialTargets().ToArray())
                _credentialComboBox.SelectedIndex = 0

                ' Initialize recurrence type combo
                _recurrenceTypeCombo.Items.Clear()
                _recurrenceTypeCombo.Items.AddRange([Enum].GetNames(GetType(RecurrenceType)))
                _recurrenceTypeCombo.SelectedIndex = 0

                ' Set default date/time values
                _scheduleDatePicker.Value = DateTime.Now.Date
                _scheduleTimePicker.Value = DateTime.Now

                ' Load existing task data if in edit mode
                If _isEditMode Then
                    LoadExistingTaskData()
                End If

                UpdateRecurrenceControls()
                UpdateActionButtons()

            Catch ex As Exception
                _logger?.LogError($"Error in InitializeFormData: {ex.Message}")
                Throw
            End Try
        End Sub

        Private Sub LoadActions()
            _actionsGrid.Rows.Clear()
            For Each action In _task.Actions.OrderBy(Function(a) a.Order)
                _actionsGrid.Rows.Add(
                action.Order,
                action.Type.ToString(),
                action.Target,
                action.Parameters,
                action.RequiresElevation
            )
            Next
            UpdateActionButtons()
        End Sub

        Private Sub LoadExistingTaskData()
            Try
                _logger.LogInfo($"Loading existing task data for task: {_task.Name}")

                ' Load basic task info
                _nameTextBox.Text = _task.Name
                _descriptionTextBox.Text = _task.Description
                _scheduleDatePicker.Value = _task.StartTime.Date
                _scheduleTimePicker.Value = _task.StartTime

                ' Load schedule info
                If _task.Schedule <> RecurrenceType.OneTime Then
                    _recurringCheckBox.Checked = True
                    _recurrenceTypeCombo.SelectedIndex = CInt(_task.Schedule)

                    Select Case _task.Schedule
                        Case RecurrenceType.Interval
                            _intervalTextBox.Text = _task.Interval.TotalMinutes.ToString()
                        Case RecurrenceType.Daily
                            For Each time In _task.DailyTimes
                                _dailyTimeList.Items.Add(time.ToString("HH:mm"))
                            Next
                    End Select
                End If

                ' Load credential settings
                If Not String.IsNullOrEmpty(_task.CredentialTarget) Then
                    Dim credentialIndex = _credentialComboBox.Items.IndexOf(_task.CredentialTarget)
                    If credentialIndex >= 0 Then
                        _credentialComboBox.SelectedIndex = credentialIndex
                    End If
                End If

                _requiresElevationCheckBox.Checked = _task.RequiresElevation

                ' Load actions
                LoadActions()

            Catch ex As Exception
                _logger?.LogError($"Error loading existing task data: {ex.Message}")
                Throw
            End Try
        End Sub

        Private Sub MoveDownButton_Click(sender As Object, e As EventArgs)
            If _actionsGrid.SelectedRows.Count = 0 OrElse _actionsGrid.SelectedRows(0).Index = _task.Actions.Count - 1 Then Return

            Dim index = _actionsGrid.SelectedRows(0).Index
            Dim action = _task.Actions(index)
            _task.Actions.RemoveAt(index)
            _task.Actions.Insert(index + 1, action)
            ReorderActions()
            LoadActions()
            _actionsGrid.Rows(index + 1).Selected = True
        End Sub


        Private Sub MoveUpButton_Click(sender As Object, e As EventArgs)
            If _actionsGrid.SelectedRows.Count = 0 OrElse _actionsGrid.SelectedRows(0).Index = 0 Then Return

            Dim index = _actionsGrid.SelectedRows(0).Index
            Dim action = _task.Actions(index)
            _task.Actions.RemoveAt(index)
            _task.Actions.Insert(index - 1, action)
            ReorderActions()
            LoadActions()
            _actionsGrid.Rows(index - 1).Selected = True
        End Sub

        Private Sub OkButton_Click(sender As Object, e As EventArgs)
            Try
                If Not ValidateInput() Then
                    DialogResult = DialogResult.None
                    Return
                End If

                UpdateTaskFromForm()

                If _isEditMode Then
                    _customScheduler.UpdateTask(_task)
                Else
                    _customScheduler.AddTask(_task)
                End If

                DialogResult = DialogResult.OK
                Close()

            Catch ex As Exception
                _logger?.LogError($"Error saving task: {ex.Message}")
                MessageBox.Show($"Error saving task: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                DialogResult = DialogResult.None
            End Try
        End Sub

        Private Sub RecurrenceTypeCombo_SelectedIndexChanged(sender As Object, e As EventArgs)
            UpdateRecurrenceControls()
        End Sub

        Private Sub RecurringCheckBox_CheckedChanged(sender As Object, e As EventArgs)
            _recurrenceTypeCombo.Enabled = _recurringCheckBox.Checked
            UpdateRecurrenceControls()
        End Sub

        Private Sub RefreshActionsList()
            _actionsGrid.Rows.Clear()
            For Each action In _task.Actions.OrderBy(Function(a) a.Order)
                _actionsGrid.Rows.Add(
                        action.Order,
                        action.Name,
                        action.Type.ToString(),
                        action.Target,
                        If(action.DependsOn, "(None)"),
                        action.Status.ToString()
                    )
            Next
            UpdateActionButtons()
        End Sub

        Private Sub RemoveTimeButton_Click(sender As Object, e As EventArgs)
            If _dailyTimeList.SelectedIndex <> -1 Then
                _dailyTimeList.Items.RemoveAt(_dailyTimeList.SelectedIndex)
            End If
        End Sub

        Private Sub ReorderActions()
            For i As Integer = 0 To _task.Actions.Count - 1
                _task.Actions(i).Order = i + 1
            Next
        End Sub

        Private Sub UpdateActionButtons()
            Dim hasSelection = _actionsGrid.SelectedRows.Count > 0
            Dim selectedIndex = If(hasSelection, _actionsGrid.SelectedRows(0).Index, -1)

            _editActionButton.Enabled = hasSelection
            _deleteActionButton.Enabled = hasSelection
            _moveUpButton.Enabled = hasSelection AndAlso selectedIndex > 0
            _moveDownButton.Enabled = hasSelection AndAlso selectedIndex < _actionsGrid.Rows.Count - 1
        End Sub

        Private Sub UpdateDailyTimes()
            _task.DailyTimes.Clear()
            For Each item In _dailyTimeList.Items
                _task.DailyTimes.Add(TimeSpan.Parse(item.ToString()))
            Next
            _task.DailyTimes.Sort()
        End Sub

        Private Sub UpdateRecurrenceControls()
            Try
                If _intervalPanel Is Nothing OrElse _dailyPanel Is Nothing OrElse
           _recurringCheckBox Is Nothing OrElse _recurrenceTypeCombo Is Nothing Then
                    _logger?.LogError("One or more recurrence controls are not initialized")
                    Return
                End If

                _intervalPanel.Visible = False
                _dailyPanel.Visible = False

                If _recurringCheckBox.Checked AndAlso _recurrenceTypeCombo.SelectedIndex >= 0 Then
                    Select Case _recurrenceTypeCombo.SelectedItem.ToString()
                        Case "Interval"
                            _intervalPanel.Visible = True
                        Case "Daily"
                            _dailyPanel.Visible = True
                    End Select
                End If
            Catch ex As Exception
                _logger?.LogError($"Error in UpdateRecurrenceControls: {ex.Message}")
                _logger?.LogError($"StackTrace: {ex.StackTrace}")
            End Try
        End Sub

        Private Sub UpdateTaskFromForm()
            _task.Name = _nameTextBox.Text.Trim()
            _task.Description = _descriptionTextBox.Text.Trim()

            ' Update schedule
            Dim scheduleDate = _scheduleDatePicker.Value.Date
            Dim scheduleTime = _scheduleTimePicker.Value.TimeOfDay
            _task.StartTime = scheduleDate.Add(scheduleTime)

            ' Update recurrence
            If _recurringCheckBox.Checked Then
                _task.Schedule = CType([Enum].Parse(GetType(RecurrenceType), _recurrenceTypeCombo.SelectedItem.ToString()), RecurrenceType)
                If _task.Schedule = RecurrenceType.Interval Then
                    _task.Interval = TimeSpan.FromMinutes(Double.Parse(_intervalTextBox.Text))
                    _task.DailyTimes.Clear()
                ElseIf _task.Schedule = RecurrenceType.Daily Then
                    _task.Interval = TimeSpan.Zero
                    UpdateDailyTimes()
                End If
            Else
                _task.Schedule = RecurrenceType.OneTime
                _task.Interval = TimeSpan.Zero
                _task.DailyTimes.Clear()
            End If

            ' Update credential and elevation
            _task.CredentialTarget = If(_credentialComboBox.SelectedIndex > 0,
                                _credentialComboBox.SelectedItem.ToString(),
                                "")
            _task.RequiresElevation = _requiresElevationCheckBox.Checked

            ' Calculate next run time
            _task.NextRunTime = _task.CalculateNextRunTime()
        End Sub

        Private Function ValidateInput() As Boolean
            If String.IsNullOrWhiteSpace(_nameTextBox.Text) Then
                MessageBox.Show("Task name is required.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return False
            End If

            If _recurringCheckBox.Checked Then
                Select Case _recurrenceTypeCombo.SelectedItem.ToString()
                    Case "Interval"
                        Dim interval As Double
                        If Not Double.TryParse(_intervalTextBox.Text, interval) OrElse interval <= 0 Then
                            MessageBox.Show("Please enter a valid interval greater than zero.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                            Return False
                        End If
                    Case "Daily"
                        If _dailyTimeList.Items.Count = 0 Then
                            MessageBox.Show("Please add at least one daily time.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                            Return False
                        End If
                End Select
            End If

            If _actionsGrid.Rows.Count = 0 Then
                MessageBox.Show("Please add at least one action.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return False
            End If

            Return True
        End Function


        'NEW





    End Class
End Namespace