Imports System.Drawing
Imports LiteTask.LiteTask.ScheduledTask


Namespace LiteTask
    Partial Public Class ActionDialog
        Inherits Form

        Private ReadOnly _logger As Logger
        Private _existingAction As TaskAction
        Private _isEditMode As Boolean

        ' UI Controls
        Private _nameTextBox As TextBox
        Private _typeComboBox As ComboBox
        Private _targetTextBox As TextBox
        Private _parametersTextBox As TextBox
        Private _requiresElevationCheckBox As CheckBox
        Private _browseButton As Button
        Private _okButton As Button
        Private _cancelButton As Button

        ' Dependency Controls
        Private _dependsOnCombo As ComboBox
        Private _waitForCompletionCheck As CheckBox
        Private _timeoutNumeric As NumericUpDown
        Private _retryCountNumeric As NumericUpDown
        Private _retryDelayNumeric As NumericUpDown
        Private _continueOnErrorCheck As CheckBox

        Public Property Action As TaskAction

        Public Sub New(Optional existingAction As TaskAction = Nothing)
            Try
                _logger = ApplicationContainer.GetService(Of Logger)()
                _existingAction = existingAction
                _isEditMode = (existingAction IsNot Nothing)

                InitializeComponent()
                InitializeData()

            Catch ex As Exception
                _logger?.LogError($"Error initializing ActionDialog: {ex.Message}")
                Throw New InvalidOperationException("Failed to initialize action dialog", ex)
            End Try
        End Sub


        Private Sub InitializeData()
            Try
                If _existingAction IsNot Nothing Then
                    _nameTextBox.Text = _existingAction.Name
                    _typeComboBox.SelectedItem = _existingAction.Type.ToString()
                    _targetTextBox.Text = _existingAction.Target
                    _parametersTextBox.Text = _existingAction.Parameters
                    _requiresElevationCheckBox.Checked = _existingAction.RequiresElevation

                    ' Load dependency settings
                    If _existingAction.DependsOn IsNot Nothing Then
                        Dim index = _dependsOnCombo.Items.IndexOf(_existingAction.DependsOn)
                        If index >= 0 Then
                            _dependsOnCombo.SelectedIndex = index
                        End If
                    End If
                    _waitForCompletionCheck.Checked = _existingAction.WaitForCompletion
                    _timeoutNumeric.Value = _existingAction.TimeoutMinutes
                    _retryCountNumeric.Value = _existingAction.RetryCount
                    _retryDelayNumeric.Value = _existingAction.RetryDelayMinutes
                    _continueOnErrorCheck.Checked = _existingAction.ContinueOnError
                Else
                    _typeComboBox.SelectedIndex = 0
                    _dependsOnCombo.SelectedIndex = 0
                End If

                UpdateDependencyControls(Nothing, EventArgs.Empty)
                PopulateDependencyCombo()

            Catch ex As Exception
                _logger?.LogError($"Error initializing data: {ex.Message}")
                Throw
            End Try
        End Sub

        Private Sub AddEventsHandlers()
            AddHandler _typeComboBox.SelectedIndexChanged, AddressOf TypeComboBox_SelectedIndexChanged
            AddHandler _browseButton.Click, AddressOf BrowseButton_Click
            AddHandler _okButton.Click, AddressOf OkButton_Click
            AddHandler _waitForCompletionCheck.CheckedChanged, AddressOf UpdateDependencyControls
        End Sub

        Private Sub PopulateDependencyCombo()
            Try
                _dependsOnCombo.Items.Clear()
                _dependsOnCombo.Items.Add("(None)")

                ' Get all tasks from scheduler
                Dim scheduler = ApplicationContainer.GetService(Of CustomScheduler)()
                For Each task In scheduler.GetAllTasks()
                    _dependsOnCombo.Items.Add(task.Name)
                Next

                _dependsOnCombo.SelectedIndex = 0

            Catch ex As Exception
                _logger.LogError($"Error populating dependency combo: {ex.Message}")
            End Try
        End Sub

        Private Sub UpdateDependencyControls(sender As Object, e As EventArgs)
            _timeoutNumeric.Enabled = _waitForCompletionCheck.Checked
            _retryCountNumeric.Enabled = _waitForCompletionCheck.Checked
            _retryDelayNumeric.Enabled = _waitForCompletionCheck.Checked
        End Sub

        Private Sub TypeComboBox_SelectedIndexChanged(sender As Object, e As EventArgs)
            _browseButton.Enabled = True
        End Sub

        Private Sub BrowseButton_Click(sender As Object, e As EventArgs)
            Try
                Using openFileDialog As New OpenFileDialog()
                    Select Case _typeComboBox.SelectedItem.ToString()
                        Case "PowerShell"
                            openFileDialog.Filter = "PowerShell Scripts (*.ps1)|*.ps1|All files (*.*)|*.*"
                        Case "SQL"
                            openFileDialog.Filter = "SQL Files (*.sql)|*.sql|All files (*.*)|*.*"
                        Case "Executable"
                            openFileDialog.Filter = "Executable Files (*.exe)|*.exe|All files (*.*)|*.*"
                        Case "Batch"
                            openFileDialog.Filter = "Batch Files (*.bat;*.cmd)|*.bat;*.cmd|All files (*.*)|*.*"
                        Case Else
                            openFileDialog.Filter = "All files (*.*)|*.*"
                    End Select

                    If openFileDialog.ShowDialog() = DialogResult.OK Then
                        _targetTextBox.Text = openFileDialog.FileName
                    End If
                End Using
            Catch ex As Exception
                _logger.LogError($"Error in file browse dialog: {ex.Message}")
                MessageBox.Show($"Error selecting file: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End Sub

        Private Sub OkButton_Click(sender As Object, e As EventArgs)
            Try
                If Not ValidateInput() Then
                    DialogResult = DialogResult.None
                    Return
                End If

                ' Create or update action
                If Action Is Nothing Then
                    Action = New TaskAction()
                End If

                ' Set basic properties
                Action.Name = _nameTextBox.Text.Trim()
                Action.Type = CType([Enum].Parse(GetType(TaskType), _typeComboBox.SelectedItem.ToString()), TaskType)
                Action.Target = _targetTextBox.Text.Trim()
                Action.Parameters = _parametersTextBox.Text.Trim()
                Action.RequiresElevation = _requiresElevationCheckBox.Checked

                ' Set dependency properties
                Action.DependsOn = If(_dependsOnCombo.SelectedIndex > 0, _dependsOnCombo.SelectedItem.ToString(), Nothing)
                Action.WaitForCompletion = _waitForCompletionCheck.Checked
                Action.TimeoutMinutes = Convert.ToInt32(_timeoutNumeric.Value)
                Action.RetryCount = Convert.ToInt32(_retryCountNumeric.Value)
                Action.RetryDelayMinutes = Convert.ToInt32(_retryDelayNumeric.Value)
                Action.ContinueOnError = _continueOnErrorCheck.Checked

            Catch ex As Exception
                _logger.LogError($"Error saving action: {ex.Message}")
                MessageBox.Show($"Error saving action: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                DialogResult = DialogResult.None
            End Try
        End Sub

        Private Function ValidateInput() As Boolean
            If String.IsNullOrWhiteSpace(_nameTextBox.Text) Then
                MessageBox.Show("Please enter a name for the action.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Return False
            End If

            If String.IsNullOrWhiteSpace(_targetTextBox.Text) Then
                MessageBox.Show("Please specify a target.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                Return False
            End If

            Return True
        End Function


    End Class
End Namespace