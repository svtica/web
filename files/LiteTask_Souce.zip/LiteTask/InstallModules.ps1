[CmdletBinding()]
param (
    [Parameter(Mandatory=$false)]
    [string[]]$Modules,
    [Parameter(Mandatory=$false)]
    [string]$LogPath = "$env:TEMP\LiteTask_ModuleInstall.log",
    [Parameter(Mandatory=$false)]
    [string]$Destination = ".\LiteTaskData\Modules"
)

# Initialize logging with fallback to temp directory
function Write-LogMessage {
    param(
        [string]$Message,
        [string]$Level = "INFO"
    )
    try {
        $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
        $logMessage = "$timestamp [$Level] $Message"
        $Message | Out-Host # Always output to console
        
        if ($LogPath) {
            try {
                Add-Content -Path $LogPath -Value $logMessage -ErrorAction Stop
            }
            catch {
                # If we can't write to the specified log, try temp directory
                $tempLogPath = Join-Path $env:TEMP "LiteTask_ModuleInstall.log"
                Add-Content -Path $tempLogPath -Value $logMessage
                # Update LogPath to the temp location
                $script:LogPath = $tempLogPath
            }
        }
    }
    catch {
        Write-Host "Failed to write log: $_"
    }
}

# Create log directory if it doesn't exist
try {
    $logDir = Split-Path $LogPath -Parent
    if (-not (Test-Path $logDir)) {
        New-Item -ItemType Directory -Path $logDir -Force | Out-Null
    }
}
catch {
    Write-Host "Failed to create log directory, falling back to temp directory"
    $LogPath = Join-Path $env:TEMP "LiteTask_ModuleInstall.log"
}

# Create destination directory if it doesn't exist
try {
    $Destination = [System.IO.Path]::GetFullPath($Destination)
    if (-not (Test-Path $Destination)) {
        New-Item -ItemType Directory -Path $Destination -Force | Out-Null
        Write-LogMessage "Created destination directory: $Destination"
    }
}
catch {
    Write-LogMessage "Error creating destination directory: $_" -Level "ERROR"
    throw
}

Write-LogMessage "Starting PowerShell module installation process"
Write-LogMessage "Installation location: $Destination"
Write-LogMessage "Log file location: $LogPath"

# Set PSModulePath to include our custom location
$env:PSModulePath = $Destination + [System.IO.Path]::PathSeparator + $env:PSModulePath

# Ensure NuGet is available
try {
    Write-LogMessage "Checking NuGet provider..."
    $provider = Get-PackageProvider -Name NuGet -ErrorAction SilentlyContinue
    if (-not $provider) {
        Install-PackageProvider -Name NuGet -Force | Out-Null
        Write-LogMessage "NuGet provider installed successfully"
    }
} catch {
    Write-LogMessage "Error installing NuGet provider: $_" -Level "ERROR"
    throw
}

# Ensure PowerShellGet is up to date
try {
    Write-LogMessage "Checking PowerShellGet module..."
    $null = Install-Module -Name PowerShellGet -Force -AllowClobber -Scope CurrentUser -ErrorAction Stop
    Write-LogMessage "PowerShellGet module updated successfully"
} catch {
    Write-LogMessage "Error updating PowerShellGet: $_" -Level "ERROR"
    throw
}

# Function to install a single module with retry logic
function Install-ModuleWithRetry {
    param (
        [string]$ModuleName,
        [int]$MaxRetries = 3
    )
    
    for ($i = 1; $i -le $MaxRetries; $i++) {
        try {
            Write-LogMessage "Checking if module $ModuleName is already installed..."
            $existingModule = Get-Module -ListAvailable -Name $ModuleName
            
            if ($existingModule) {
                Write-LogMessage "Module $ModuleName is already installed (Version: $($existingModule.Version))"
                return $true
            }
            
            Write-LogMessage "Installing module $ModuleName (Attempt $i of $MaxRetries)..."
            Install-Module -Name $ModuleName -Force -AllowClobber -Scope CurrentUser -ErrorAction Stop -Destination $Destination
            
            # Verify installation
            $verifyModule = Get-Module -ListAvailable -Name $ModuleName
            if ($verifyModule) {
                Write-LogMessage "Successfully installed module $ModuleName (Version: $($verifyModule.Version))"
                return $true
            }
            
            throw "Module installation verification failed"
        }
        catch {
            Write-LogMessage "Attempt $i failed: $_" -Level "WARNING"
            if ($i -eq $MaxRetries) {
                Write-LogMessage "Failed to install module $ModuleName after $MaxRetries attempts" -Level "ERROR"
                return $false
            }
            Start-Sleep -Seconds ($i * 2) # Exponential backoff
        }
    }
    return $false
}

# Initialize counters and arrays
$successCount = 0
$failureCount = 0
$failedModules = @()
$installedModules = @()

# Process modules
if (-not $Modules) {
    $Modules = @("Az", "AzureAD", "MSOnline", "PSWindowsUpdate", "PSBlueTeam")
}

foreach ($module in $Modules) {
    Write-LogMessage "Processing module: $module"
    if (Install-ModuleWithRetry -ModuleName $module) {
        $successCount++
        $installedModules += $module
    } else {
        $failureCount++
        $failedModules += $module
    }
}

# Report results
Write-LogMessage "Module installation complete."
Write-LogMessage "Successfully installed modules ($successCount): $($installedModules -join ', ')"
if ($failedModules.Count -gt 0) {
    Write-LogMessage "Failed modules ($failureCount): $($failedModules -join ', ')" -Level "WARNING"
}

# Set exit code based on results
if ($failureCount -gt 0) {
    Write-LogMessage "Some modules failed to install. Check the log file for details." -Level "WARNING"
    exit 1
} else {
    Write-LogMessage "All modules installed successfully."
    exit 0
}