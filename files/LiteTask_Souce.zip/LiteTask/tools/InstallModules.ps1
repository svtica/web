<#
.SYNOPSIS
    Installs PowerShell modules to a specified destination directory.

.DESCRIPTION
    This script installs selected PowerShell modules to a custom directory.
    It handles installation with retry logic, proper error handling, and logging.
    Designed to work with LiteTask application for module management.

.PARAMETER Modules
    Array of module names to install. If not specified, installs default modules:
    - Az
    - AzureAD
    - MSOnline
    - PSWindowsUpdate
    - PSBlueTeam
    - Pester
    - ImportExcel
    - VMware.PowerCLI
    - SqlServer
    - AWS.Tools.Common

.PARAMETER LogPath
    Full path where the log file should be created.
    Example: "C:\Scripts\LiteApps\LiteTaskData\logs\ModuleInstall_20241022.log"

.PARAMETER Destination
    Full path where modules should be installed.
    Example: "C:\Scripts\LiteApps\LiteTaskData\Modules"

.EXAMPLE
    .\InstallModules.ps1 -Modules "Az","AzureAD" -Destination "C:\MyModules" -LogPath "C:\Logs\install.log"

.EXAMPLE
    .\InstallModules.ps1 -Destination "C:\MyModules" -LogPath "C:\Logs\install.log"
    # Installs all default modules

.NOTES
    Author: Dominic Ricard
    Version: 1.0
    Date: 2024-10-22
    Requirements:
    - PowerShell 5.1 or later
    - Internet connection for module download
    - Write permissions to Destination and LogPath directories

.OUTPUTS
    - Log file at specified LogPath
    - Installed modules in Destination directory
    - Exit code 0 for success, 1 for any failures
#>

[CmdletBinding()]
param (
    [Parameter(Mandatory=$false)]
    [string[]]$Modules,
    
    [Parameter(Mandatory=$true)]
    [string]$LogPath,
    
    [Parameter(Mandatory=$true)]
    [string]$Destination
)

# Initialize logging
function Write-LogMessage {
    param(
        [string]$Message,
        [string]$Level = "INFO"
    )
    
    try {
        $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
        $logMessage = "$timestamp [$Level] $Message"
        
        # Always write to console first (this will be captured by the parent process)
        Write-Host $logMessage
        
        # Only try to write to file if LogPath is provided
        if ($LogPath) {
            try {
                # Create directory if it doesn't exist
                $logDir = Split-Path -Parent $LogPath
                if (-not (Test-Path $logDir)) {
                    New-Item -ItemType Directory -Path $logDir -Force | Out-Null
                }
                
                # Write to log file using Out-File instead of Add-Content
                $logMessage | Out-File -FilePath $LogPath -Append -Encoding UTF8 -ErrorAction Stop
            }
            catch {
                Write-Host "Warning: Could not write to log file: $_"
            }
        }
    }
    catch {
        Write-Host "Error in Write-LogMessage: $_"
    }
}

# Function to safely create directory
function New-SafeDirectory {
    param([string]$Path)
    
    try {
        if (-not (Test-Path $Path)) {
            New-Item -ItemType Directory -Path $Path -Force | Out-Null
            Write-LogMessage "Created directory: $Path"
        }
        return $true
    }
    catch {
        Write-LogMessage "Failed to create directory $Path : $_" -Level "ERROR"
        return $false
    }
}

# Initialize logging and directories at script start
try {
    # Create base directories first
    $logDir = Split-Path -Parent $LogPath
    $success = New-SafeDirectory -Path $logDir
    
    if (-not $success) {
        Write-Host "Warning: Unable to create log directory. Continuing without file logging."
        $LogPath = $null
    }
    
    Write-LogMessage "Script started"
    Write-LogMessage "Log Path: $LogPath"
    Write-LogMessage "Destination: $Destination"
    
    # Create module destination directory
    $success = New-SafeDirectory -Path $Destination
    if (-not $success) {
        throw "Unable to create destination directory"
    }
}
catch {
    Write-Host "Critical initialization error: $_"
    exit 1
}
else {
    Write-LogMessage "All modules installed successfully."
    exit 0
}