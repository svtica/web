Namespace LiteTask
    Public Class Impersonation
        Private Const LOGON32_LOGON_INTERACTIVE As Integer = 2
        Private Const LOGON32_PROVIDER_DEFAULT As Integer = 0
        Private Const TOKEN_DUPLICATE As Integer = &H2
        Private Const TOKEN_QUERY As Integer = &H8
        Private Const TOKEN_ADJUST_DEFAULT As Integer = &H80
        Private Const TOKEN_ASSIGN_PRIMARY As Integer = &H1
        Private Const TOKEN_ALL_ACCESS As Integer = &HF01FF

        Private Const LOGON_WITH_PROFILE As Integer = 1
        Private Const CREATE_UNICODE_ENVIRONMENT As Integer = &H400

        Private ReadOnly _toolManager As ToolManager
        Private ReadOnly _credentialManager As CredentialManager
        Private ReadOnly _logger As Logger
        Private ReadOnly _toolsPath As String

        Public Sub New(credentialManager As CredentialManager, logger As Logger, toolsPath As String)
            _credentialManager = credentialManager
            _logger = logger
            _toolsPath = toolsPath
            _toolManager = ApplicationContainer.GetService(Of ToolManager)()
        End Sub

        'Public Function CreateProcessAsImpersonatedUser(username As String, domain As String, password As String, applicationName As String, commandLine As String, Optional workingDirectory As String = Nothing) As Boolean
        '    Try
        '        _logger.LogInfo($"Attempting to create process as user: {username}")

        '        ' Get the current execution tool path
        '        Dim executionToolPath = _toolManager.GetCurrentToolPath()
        '        If Not File.Exists(executionToolPath) Then
        '            Throw New FileNotFoundException($"Execution tool not found in tools directory: {_toolManager.CurrentExecutionTool}", executionToolPath)
        '        End If

        '        _logger.LogInfo($"Using execution tool: {_toolManager.CurrentExecutionTool}")

        '        Dim tempLogFile = Path.GetTempFileName()
        '        Dim arguments As String

        '        If _toolManager.CurrentExecutionTool.Equals("PsExec.exe", StringComparison.OrdinalIgnoreCase) Then
        '            ' PsExec command format
        '            arguments = $"-h -accepteula -nobanner -i "
        '            If Not String.IsNullOrEmpty(username) Then
        '                arguments += $"-u ""{username}"" -p ""{password}"" "
        '            End If
        '            arguments += $"""{applicationName}"" {commandLine}"
        '        Else
        '            ' LiteRun command format
        '            arguments = If(Not String.IsNullOrEmpty(username),
        '            $"-u {username} -p {password} ",
        '            "")

        '            If Not String.IsNullOrEmpty(domain) Then
        '                arguments += $"-d {domain} "
        '            End If

        '            arguments += $"-lo ""{tempLogFile}"" "
        '            If Not String.IsNullOrEmpty(workingDirectory) Then
        '                arguments += $"-w ""{workingDirectory}"" "
        '            End If
        '            arguments += $"""{applicationName}"" {commandLine}"
        '        End If

        '        ' Create process to run the execution tool
        '        Dim startInfo = New ProcessStartInfo(executionToolPath) With {
        '        .Arguments = arguments,
        '        .UseShellExecute = False,
        '        .RedirectStandardOutput = True,
        '        .RedirectStandardError = True,
        '        .CreateNoWindow = True,
        '        .WorkingDirectory = If(workingDirectory, _toolsPath)
        '    }

        '        Using process As New Process()
        '            process.StartInfo = startInfo
        '            process.Start()
        '            Dim output = process.StandardOutput.ReadToEnd()
        '            Dim errors = process.StandardError.ReadToEnd()
        '            process.WaitForExit()

        '            _logger.LogInfo($"Process output: {output}")
        '            If Not String.IsNullOrEmpty(errors) Then
        '                _logger.LogWarning($"Process errors: {errors}")
        '            End If

        '            If process.ExitCode = 0 Then
        '                _logger.LogInfo($"Process completed successfully with exit code: {process.ExitCode}")
        '                Return True
        '            Else
        '                _logger.LogError($"Process failed with exit code: {process.ExitCode}")
        '                Return False
        '            End If
        '        End Using

        '    Catch ex As Exception
        '        _logger.LogError($"Error in CreateProcessAsImpersonatedUser: {ex.Message}")
        '        _logger.LogError($"StackTrace: {ex.StackTrace}")
        '        Return False
        '    End Try
        'End Function

    End Class

End Namespace