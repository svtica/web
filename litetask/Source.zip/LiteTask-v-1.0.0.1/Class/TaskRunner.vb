Imports System.Collections.ObjectModel
Imports System.Data
Imports System.Data.SqlClient
Imports System.Text.RegularExpressions

Namespace LiteTask
    Public Class TaskRunner

        ' TODO: Phase 2 Security Improvements
        ' - Implement connection string encryption
        ' - Add input parameter validation for SQL queries
        ' - Implement query whitelisting for allowed operations
        ' - Add timeout settings for long-running queries
        ' - Implement audit logging for all database operations

        Private ReadOnly _logger As Logger
        Private ReadOnly _credentialManager As CredentialManager
        Private ReadOnly _runspace As Runspace
        Private ReadOnly _liteRunConfig As LiteRunConfig
        Private ReadOnly _toolManager As ToolManager
        Private ReadOnly _xmlManager As XMLManager
        Private ReadOnly _logPath As String
        Private ReadOnly _powerShellPathManager As PowerShellPathManager
        Private ReadOnly _sqlTab As SqlTab
        Private ReadOnly _sanitizer As New SqlCommandSanitizer()
        Private _connectionStringBase As String
        Private _sqlConfig As Dictionary(Of String, String)
        Public Event OutputReceived(sender As Object, e As DataAddedEventArgs)
        Public Event ErrorReceived(sender As Object, e As DataAddedEventArgs)

        Public Sub New(logger As Logger, credentialManager As CredentialManager, toolManager As ToolManager, logPath As String, XMLManager As XMLManager)
            If logger Is Nothing Then
                Throw New ArgumentNullException(NameOf(logger))
            End If
            If credentialManager Is Nothing Then
                Throw New ArgumentNullException(NameOf(credentialManager))
            End If
            If toolManager Is Nothing Then
                Throw New ArgumentNullException(NameOf(toolManager))
            End If
            If String.IsNullOrEmpty(logPath) Then
                Throw New ArgumentNullException(NameOf(logPath))
            End If
            If XMLManager Is Nothing Then
                Throw New ArgumentNullException(NameOf(XMLManager))
            End If

            _logger = logger
            _credentialManager = credentialManager
            _toolManager = toolManager
            _logPath = logPath
            _xmlManager = XMLManager
            _powerShellPathManager = New PowerShellPathManager(logger)
            '_xmlManager = ApplicationContainer.GetService(Of XMLManager)()
            _sqlConfig = _xmlManager.GetSqlConfiguration()

            ' Ensure required directories exist
            Directory.CreateDirectory(_logPath)
            Directory.CreateDirectory(_toolManager._toolsPath)

            ' Verify required tools
            VerifyRequiredTools()

            ' Initialize PowerShell environment
            '_powerShellPathManager = ApplicationContainer.GetService(Of PowerShellPathManager)()
            _powerShellPathManager.EnsureModulePathExists()
            Dim initialSessionState As InitialSessionState = InitialSessionState.CreateDefault2()
            initialSessionState.ExecutionPolicy = ExecutionPolicy.Bypass
            initialSessionState.ImportPSModule(Directory.GetDirectories(_powerShellPathManager.GetModulePath()))
            _runspace = RunspaceFactory.CreateRunspace(initialSessionState)
            _runspace.Open()
        End Sub

        Private Function DataTableToString(dt As DataTable) As String
            ' TODO: Phase 2 Security Improvements
            ' - Add data masking for sensitive columns
            ' - Implement output size limits
            ' - Add data type validation
            ' - Remove potentially dangerous content from output

            Try
                Dim result As New StringBuilder()

                ' Add headers with basic sanitization
                result.AppendLine(String.Join(vbTab,
                dt.Columns.Cast(Of DataColumn)().
                Select(Function(c) _sanitizer.SanitizeColumnName(c.ColumnName))))

                ' Add rows with basic sanitization
                For Each row As DataRow In dt.Rows
                    result.AppendLine(String.Join(vbTab,
                    row.ItemArray.Select(Function(item) _sanitizer.SanitizeOutput(
                                If(item Is Nothing OrElse item Is DBNull.Value, "[NULL]", item.ToString())))))
                Next

                Return result.ToString()
            Catch ex As Exception
                _logger.LogError($"Error converting DataTable to string: {ex.Message}")
                Return String.Empty
            End Try
        End Function

        Public Sub Dispose()
            If _runspace IsNot Nothing Then
                _runspace.Dispose()
            End If
        End Sub

        Public Async Function ExecutePsExecSecurely(command As String, credential As CredentialInfo, requiresElevation As Boolean, Optional workingDirectory As String = Nothing) As Task(Of (ExitCode As Integer, Output As String, Err As String))
            Try
                Dim psExecPath = Path.Combine(_toolManager._toolsPath, "PsExec.exe")
                Dim baseArgs = "-accepteula -nobanner -i"
                If requiresElevation Then baseArgs &= " -h"

                ' Build command with password directly (more reliable than file)
                Dim fullCommand = $"{baseArgs} -u ""{credential.Username}"" -p ""{credential.Password}"" {command.Trim(""""c)}"

                Using process As New Process With {
            .StartInfo = New ProcessStartInfo(psExecPath) With {
                .Arguments = fullCommand,
                .UseShellExecute = False,
                .RedirectStandardOutput = True,
                .RedirectStandardError = True,
                .CreateNoWindow = True,
                .WorkingDirectory = If(workingDirectory, Environment.CurrentDirectory)
            }
        }
                    Dim output As New StringBuilder()
                    Dim err As New StringBuilder()

                    AddHandler process.OutputDataReceived, Sub(sender, e)
                                                               If e.Data IsNot Nothing Then
                                                                   output.AppendLine(e.Data)
                                                                   _logger.LogInfo($"Process output: {If(e.Data.Contains("password"), "[MASKED]", e.Data)}")
                                                               End If
                                                           End Sub

                    AddHandler process.ErrorDataReceived, Sub(sender, e)
                                                              If e.Data IsNot Nothing Then
                                                                  If e.Data.Contains("Connecting") OrElse e.Data.Contains("Starting") OrElse
                       e.Data.Contains("Copying") OrElse e.Data.Contains("exited") Then
                                                                      _logger.LogInfo($"PsExec status: {e.Data}")
                                                                  Else
                                                                      err.AppendLine(e.Data)
                                                                      _logger.LogWarning($"Process error: {e.Data}")
                                                                  End If
                                                              End If
                                                          End Sub

                    process.Start()
                    process.BeginOutputReadLine()
                    process.BeginErrorReadLine()
                    Await process.WaitForExitAsync()

                    If process.ExitCode <> 0 Then
                        _logger.LogError($"Process exited with code: {process.ExitCode}")
                    End If

                    Return (process.ExitCode, output.ToString(), err.ToString())
                End Using

            Finally
                If credential?.Password IsNot Nothing Then
                    credential.Password = Nothing
                End If
            End Try
        End Function

        Private Async Function ExecuteProcessWithOutput(process As Process) As Task(Of String)
            Dim output As New StringBuilder()
            Dim err As New StringBuilder()

            ' Set encoding for process output
            process.StartInfo.StandardOutputEncoding = Encoding.UTF8
            process.StartInfo.StandardErrorEncoding = Encoding.UTF8

            AddHandler process.OutputDataReceived, Sub(sender, e)
                                                       If e.Data IsNot Nothing Then
                                                           output.AppendLine(e.Data)
                                                           _logger.LogInfo($"sqlcmd output: {e.Data}")
                                                       End If
                                                   End Sub

            AddHandler process.ErrorDataReceived, Sub(sender, e)
                                                      If Not String.IsNullOrWhiteSpace(e.Data) Then
                                                          err.AppendLine(e.Data)
                                                          _logger.LogError($"sqlcmd error: {e.Data}")
                                                      End If
                                                  End Sub

            process.Start()
            process.BeginOutputReadLine()
            process.BeginErrorReadLine()
            Await process.WaitForExitAsync()

            If process.ExitCode <> 0 Then
                Dim errorMessage = err.ToString()
                Return If(String.IsNullOrWhiteSpace(errorMessage),
                 $"Error: Process exited with code {process.ExitCode}",
                 $"Error: {errorMessage}")
            End If

            _logger.LogInfo("Query executed successfully")
            Return output.ToString()
        End Function

        Public Async Function ExecuteSqlCommandWithSqlCmd(query As String, server As String, database As String, credential As CredentialInfo) As Task(Of String)
            Try
                _logger.LogInfo($"Executing SQL command on {server}.{database} using sqlcmd")

                Dim tempDir = Path.Combine(Application.StartupPath, "LiteTaskData", "temp")
                Directory.CreateDirectory(tempDir)
                Dim tempFile = Path.Combine(tempDir, $"sqlcmd_{DateTime.Now:yyyyMMddHHmmss}.sql")

                Try
                    Await File.WriteAllTextAsync(tempFile, query)
                    _logger.LogInfo($"Created temporary SQL file: {tempFile}")

                    Dim sqlcmdPath = Path.Combine(_toolManager._toolsPath, "sqlcmd.exe")
                    Dim sqlcmdArgs As String

                    If credential IsNot Nothing Then
                        sqlcmdArgs = $"""-S"" ""{server}"" ""-d"" ""{database}"" ""-I"" ""-h-1"" ""-i"" ""{tempFile}"" -U ""{credential.Username}"" -P ""{credential.Password}"""
                        _logger.LogInfo($"Executing with SQL credentials for user: {credential.Username}")
                    Else
                        sqlcmdArgs = $"""-S"" ""{server}"" ""-d"" ""{database}"" ""-I"" ""-h-1"" ""-i"" ""{tempFile}"" -E"
                        _logger.LogInfo("Executing with integrated security")
                    End If

                    Using process As New Process With {
                .StartInfo = New ProcessStartInfo(sqlcmdPath) With {
                    .Arguments = sqlcmdArgs,
                    .UseShellExecute = False,
                    .RedirectStandardOutput = True,
                    .RedirectStandardError = True,
                    .CreateNoWindow = True,
                    .WorkingDirectory = _toolManager._toolsPath
                }
            }
                        Return Await ExecuteProcessWithOutput(process)
                    End Using

                Finally
                    If File.Exists(tempFile) Then
                        Try
                            File.Delete(tempFile)
                            _logger.LogInfo($"Deleted temporary SQL file: {tempFile}")
                        Catch ex As Exception
                            _logger.LogWarning($"Failed to delete temp file {tempFile}: {ex.Message}")
                        End Try
                    End If
                End Try

            Catch ex As Exception
                _logger.LogError($"Error executing SQL command: {ex.Message}")
                Throw
            End Try
        End Function

        Async Function ExecuteSqlTask(taskAction As TaskAction, credential As CredentialInfo) As Task(Of Boolean)
            Try
                _logger.LogInfo($"Executing SQL task: {taskAction.Name}")
                Dim sqlContent = File.ReadAllText(taskAction.Target)
                Dim sqlInfo = ExtractSqlInfo(sqlContent)
                Dim sqlConfig = _xmlManager.GetSqlConfiguration()
                Dim parameters = If(Not String.IsNullOrEmpty(taskAction.Parameters),
                          ParseSqlParameters(taskAction.Parameters),
                          New Dictionary(Of String, String))

                Dim server = If(parameters.ContainsKey("server"), parameters("server"),
                    If(Not String.IsNullOrEmpty(sqlInfo.ServerName), sqlInfo.ServerName,
                    sqlConfig("DefaultServer")))

                Dim database = If(parameters.ContainsKey("database"), parameters("database"),
                       If(Not String.IsNullOrEmpty(sqlInfo.DatabaseName), sqlInfo.DatabaseName,
                       sqlConfig("DefaultDatabase")))

                If String.IsNullOrEmpty(server) OrElse String.IsNullOrEmpty(database) Then
                    Throw New ArgumentException("Server and database must be specified in either task parameters, SQL file, or in configuration")
                End If

                _logger.LogInfo($"Using Server: {server}, Database: {database}")
                _logger.LogInfo($"Using credentials: {If(credential IsNot Nothing, credential.Username, "None")}")

                ' Execute using sqlcmd
                Dim result = Await ExecuteSqlCommandWithSqlCmd(sqlContent, server, database, credential)
                Return True
            Catch ex As Exception
                _logger.LogError($"Error in ExecuteSqlTask: {ex.Message}")
                Return False
            End Try
        End Function


        '    Public Async Function ExecuteStoredProcedureWithOSQL(
        'storedProcedureName As String,
        'server As String,
        'database As String,
        'parameters As Dictionary(Of String, String),
        'credential As CredentialInfo) As Task(Of String)

        '        ' OSQL arguments used:
        '        ' -S: Server name
        '        ' -d: Database name
        '        ' -E: Trusted connection
        '        ' -n: Remove numbering
        '        ' -b: Terminate batch job if there is an error
        '        ' -r: Messages to stderr

        '        ' TODO: Phase 2 Security Improvements
        '        ' - Add stored procedure whitelist
        '        ' - Implement parameter sanitization
        '        ' - Add execution time monitoring
        '        ' - Implement credential caching
        '        ' - Add retry logic with exponential backoff

        '        Dim tempSqlFile As String = Nothing

        '        Try
        '            ' Create temp directory
        '            Dim tempDir = Path.Combine(Application.StartupPath, "LiteTaskData", "temp")
        '            Directory.CreateDirectory(tempDir)
        '            _logger.LogDebug($"Created temp directory: {tempDir}")
        '            ' Create a temporary SQL file in LiteTaskData\temp directory
        '            tempSqlFile = Path.Combine(tempDir, $"sp_{DateTime.Now:yyyyMMddHHmmss}.sql")
        '            _logger.LogDebug($"Creating SQL file at: {tempSqlFile}")

        '            ' Build SQL script
        '            Dim sqlScript = New StringBuilder()
        '            sqlScript.AppendLine($"USE [{database}]")
        '            sqlScript.AppendLine("GO")
        '            sqlScript.AppendLine("SET NOCOUNT ON")
        '            sqlScript.AppendLine("GO")
        '            sqlScript.AppendLine("DECLARE @return_value int")
        '            sqlScript.AppendLine($"EXEC @return_value = {storedProcedureName}")
        '            sqlScript.AppendLine("SELECT 'Return Value' = @return_value")
        '            sqlScript.AppendLine("GO")

        '            ' Split stored procedures by GO statements
        '            Dim procedures = storedProcedureName.Split(New String() {"GO"}, StringSplitOptions.RemoveEmptyEntries)

        '            For Each proc In procedures
        '                Dim trimmedProc = proc.Trim()
        '                If Not String.IsNullOrEmpty(trimmedProc) Then
        '                    ' Check if proc already has USE statement
        '                    If Not trimmedProc.StartsWith("USE", StringComparison.OrdinalIgnoreCase) Then
        '                        sqlScript.AppendLine($"USE [{database}]")
        '                        sqlScript.AppendLine("GO")
        '                    End If

        '                    sqlScript.AppendLine(trimmedProc)
        '                    sqlScript.AppendLine("GO")
        '                End If
        '            Next

        '            ' Write SQL file
        '            Await File.WriteAllTextAsync(tempSqlFile, sqlScript.ToString())

        '            ' Get and verify tool paths
        '            Dim psExecPath = Path.Combine(_toolManager._toolsPath, "PsExec.exe")
        '            Dim osqlPath = Path.Combine(_toolManager._toolsPath, "OSQL.exe")

        '            If Not File.Exists(psExecPath) Then
        '                Throw New FileNotFoundException("PsExec.exe not found in tools directory", psExecPath)
        '            End If
        '            _logger.LogDebug($"Found PsExec at: {psExecPath}")

        '            If Not File.Exists(osqlPath) Then
        '                Throw New FileNotFoundException("OSQL.exe not found in tools directory", osqlPath)
        '            End If
        '            _logger.LogDebug($"Found OSQL at: {osqlPath}")
        '            tempSqlFile = Path.GetFullPath(tempSqlFile)

        '            ' Log paths for debugging
        '            _logger.LogInfo($"PsExec Path: {psExecPath}")
        '            _logger.LogInfo($"OSQL Path: {osqlPath}")
        '            _logger.LogInfo($"SQL Script Path: {tempSqlFile}")
        '            _logger.LogInfo($"Working Directory: {Path.GetDirectoryName(osqlPath)}")

        '            ' Build OSQL arguments
        '            Dim osqlArgs = $"-D {server} -E -n -i ""{tempSqlFile}"""

        '            If credential IsNot Nothing Then
        '                Dim fullCommand = $"-h -accepteula -nobanner -i -u ""{credential.Username}"" -p ""{credential.Password}"" ""{osqlPath}"" {osqlArgs}"
        '                _logger.LogInfo($"Running with credentials - Command structure (password masked): {fullCommand.Replace(credential.Password, "***")}")

        '                Dim startInfo = New ProcessStartInfo(psExecPath) With {
        '            .Arguments = fullCommand,
        '            .RedirectStandardOutput = True,
        '            .RedirectStandardError = True,
        '            .UseShellExecute = False,
        '            .CreateNoWindow = True,
        '            .WorkingDirectory = _toolManager._toolsPath
        '        }

        '                _logger.LogDebug($"Process working directory: {startInfo.WorkingDirectory}")

        '                Using process As New Process With {.StartInfo = startInfo}
        '                    Return Await ExecuteProcessWithOutput(process)
        '                End Using
        '            Else
        '                _logger.LogInfo($"Running without credentials - OSQL arguments: {osqlArgs}")
        '                Dim startInfo = New ProcessStartInfo(osqlPath) With {
        '            .Arguments = osqlArgs,
        '            .RedirectStandardOutput = True,
        '            .RedirectStandardError = True,
        '            .UseShellExecute = False,
        '            .CreateNoWindow = True,
        '            .WorkingDirectory = _toolManager._toolsPath
        '        }

        '                Using process As New Process With {.StartInfo = startInfo}
        '                    Return Await ExecuteProcessWithOutput(process)
        '                End Using
        '            End If

        '        Catch ex As Exception
        '            _logger.LogError($"Error executing stored procedure(s): {ex.Message}")
        '            _logger.LogError($"StackTrace: {ex.StackTrace}")
        '            Return $"Error: {ex.Message}"
        '        Finally
        '            ' Clean up temp file
        '            If tempSqlFile IsNot Nothing AndAlso File.Exists(tempSqlFile) Then
        '                Try
        '                    File.Delete(tempSqlFile)
        '                Catch ex As Exception
        '                    _logger.LogWarning($"Failed to delete temp file {tempSqlFile}: {ex.Message}")
        '                End Try
        '            End If
        '        End Try
        '    End Function

        Public Async Function ExecuteStoredProcedureWithSqlCmd(
            storedProcName As String,
            server As String,
            database As String,
            parameters As Dictionary(Of String, Object),
            credential As CredentialInfo) As Task(Of String)

            Dim tempSqlFile As String = Nothing
            Try
                ' Create temp directory
                Dim tempDir = Path.Combine(Application.StartupPath, "LiteTaskData", "temp")
                Directory.CreateDirectory(tempDir)
                tempSqlFile = Path.Combine(tempDir, $"sp_{DateTime.Now:yyyyMMddHHmmss}.sql")

                ' Build SQL script
                Dim sqlScript As New StringBuilder()
                sqlScript.AppendLine($"USE [{database}]")
                sqlScript.AppendLine("GO")
                sqlScript.AppendLine("SET NOCOUNT ON")
                sqlScript.AppendLine("GO")

                ' Add parameters if provided
                If parameters IsNot Nothing AndAlso parameters.Count > 0 Then
                    For Each param In parameters
                        sqlScript.AppendLine($"DECLARE {param.Key} = {param.Value}")
                    Next
                End If

                sqlScript.AppendLine("DECLARE @return_value int")
                sqlScript.AppendLine($"EXEC @return_value = {storedProcName}")
                sqlScript.AppendLine("SELECT 'Return Value' = @return_value")
                sqlScript.AppendLine("GO")

                ' Write SQL file
                Await File.WriteAllTextAsync(tempSqlFile, sqlScript.ToString())

                ' Execute using sqlcmd
                Return Await ExecuteSqlCommandWithSqlCmd(
            File.ReadAllText(tempSqlFile),
            server,
            database,
            credential)

            Finally
                If tempSqlFile IsNot Nothing AndAlso File.Exists(tempSqlFile) Then
                    Try
                        File.Delete(tempSqlFile)
                    Catch ex As Exception
                        _logger.LogWarning($"Failed to delete temp file {tempSqlFile}: {ex.Message}")
                    End Try
                End If
            End Try
        End Function

        Public Async Function ExecutePowerShellTask(taskAction As TaskAction, credential As CredentialInfo) As Task(Of Boolean)
            Try
                _logger.LogInfo($"Starting PowerShell task execution: {taskAction.Name}")
                _logger.LogInfo($"Script path: {taskAction.Target}")
                _logger.LogInfo($"Using credentials: {If(credential IsNot Nothing, credential.Username, "None")}")

                Using powerShell As PowerShell = _powerShellPathManager.CreatePowerShellInstance()
                    powerShell.AddScript(File.ReadAllText(taskAction.Target))

                    If credential IsNot Nothing Then
                        _logger.LogInfo("Adding credential parameters to PowerShell script")
                        powerShell.AddParameter("username", credential.Username)
                        ' Create new SecureString from password to avoid disposed object
                        Dim securePass = New NetworkCredential("", credential.Password).SecurePassword
                        powerShell.AddParameter("password", New NetworkCredential("", securePass).Password)
                    End If

                    If Not String.IsNullOrEmpty(taskAction.Parameters) Then
                        _logger.LogInfo($"Adding parameters: {taskAction.Parameters}")
                        For Each param In ParseParameters(taskAction.Parameters)
                            powerShell.AddParameter(param.Key, param.Value)
                        Next
                    End If

                    Dim result = Await powerShell.InvokeAsync()
                    _logger.LogInfo($"PowerShell execution completed. Output count: {result?.Count}")

                    ' Log all output and errors
                    For Each item In result
                        _logger.LogInfo($"PowerShell output: {item}")
                    Next

                    For Each info In powerShell.Streams.Information
                        _logger.LogInfo($"PowerShell information: {info}")
                    Next

                    If powerShell.Streams.Error.Count > 0 Then
                        For Each err As ErrorRecord In powerShell.Streams.Error
                            _logger.LogError($"PowerShell error: {err.Exception.Message}")
                            _logger.LogError($"PowerShell error details: {err.ScriptStackTrace}")
                        Next
                        Return False
                    End If

                    Return True  ' If no errors, consider it successful
                End Using

            Catch ex As Exception
                _logger.LogError($"Error in ExecutePowerShellTask: {ex.Message}")
                _logger.LogError($"Stack trace: {ex.StackTrace}")
                Return False
            End Try
        End Function


        Public Async Function ExecuteBatchTask(taskAction As TaskAction, credential As CredentialInfo) As Task(Of Boolean)
            Try
                _logger.LogInfo($"Executing Batch task: {taskAction.Name}")

                ' Read and parse batch file
                Dim batchContent = File.ReadAllText(taskAction.Target)
                Dim tempBatchFile = Path.Combine(Path.GetDirectoryName(taskAction.Target),
            $"temp_{Path.GetFileName(taskAction.Target)}")

                If credential IsNot Nothing Then
                    Try
                        ' Parse UNC paths from copy commands
                        Dim uncPaths = ParseUNCPaths(batchContent)

                        ' Add authentication for each UNC path
                        Dim username = credential.Username
                        Dim password = New NetworkCredential("", credential.SecurePassword).Password

                        'Debug information
                        _logger.LogInfo($"Using credentials for user: {If(credential IsNot Nothing, credential.Username, "None")}")

                        Dim modifiedContent = New StringBuilder("@echo off" & Environment.NewLine)

                        ' Add net use commands for each unique UNC path
                        For Each uncPath In uncPaths.Distinct()
                            modifiedContent.AppendLine($"net use {uncPath} /user:{username} {password}")
                        Next

                        ' Add original content
                        modifiedContent.AppendLine(batchContent)

                        ' Add cleanup
                        For Each uncPath In uncPaths.Distinct()
                            modifiedContent.AppendLine($"net use {uncPath} /delete")
                        Next

                        File.WriteAllText(tempBatchFile, modifiedContent.ToString())

                        Using process As New Process With {
                    .StartInfo = New ProcessStartInfo With {
                        .FileName = "cmd.exe",
                        .Arguments = $"/c ""{tempBatchFile}""",
                        .UseShellExecute = False,
                        .RedirectStandardOutput = True,
                        .RedirectStandardError = True,
                        .CreateNoWindow = True
                    }
                }
                            Return Await RunProcess(process)
                        End Using
                    Finally
                        If File.Exists(tempBatchFile) Then
                            File.Delete(tempBatchFile)
                        End If
                    End Try
                Else
                    ' Execute batch file without credentials
                    Using process As New Process With {
                .StartInfo = New ProcessStartInfo With {
                    .FileName = "cmd.exe",
                    .Arguments = $"/c ""{taskAction.Target}""",
                    .UseShellExecute = False,
                    .RedirectStandardOutput = True,
                    .RedirectStandardError = True,
                    .CreateNoWindow = True
                }
            }
                        Return Await RunProcess(process)
                    End Using
                End If

            Catch ex As Exception
                _logger.LogError($"Error in ExecuteBatchTask: {ex.Message}")
                Return False
            End Try
        End Function

        Private Function ParseParameters(parameters As String) As Dictionary(Of String, String)
            Dim result As New Dictionary(Of String, String)
            Try
                If String.IsNullOrEmpty(parameters) Then Return result

                For Each param In parameters.Split(" "c)
                    Dim parts = param.Split("="c)
                    If parts.Length = 2 Then
                        result(parts(0).Trim()) = parts(1).Trim()
                    End If
                Next

                _logger.LogInfo($"Parsed {result.Count} parameters successfully")
                Return result
            Catch ex As Exception
                _logger.LogError($"Error parsing parameters: {ex.Message}")
                Return result
            End Try
        End Function

        Private Function ParseSqlParameters(command As String) As Dictionary(Of String, Object)
            Dim parameters As New Dictionary(Of String, Object)
            Try
                Dim paramMatch = Regex.Match(command, "EXEC(?:UTE)?\s+\w+\s*(.+)", RegexOptions.IgnoreCase)
                If paramMatch.Success Then
                    For Each param In paramMatch.Groups(1).Value.Split(","c)
                        Dim parts = param.Trim().Split("="c)
                        If parts.Length = 2 Then
                            Dim key = parts(0).Trim().TrimStart("@"c)
                            Dim value = parts(1).Trim().Trim("'"c)
                            parameters.Add(key, value)
                        End If
                    Next
                End If
            Catch ex As Exception
                _logger?.LogError($"Error parsing SQL parameters: {ex.Message}")
            End Try
            Return parameters
        End Function

        Private Function ParseUNCPaths(batchContent As String) As List(Of String)
            Dim paths As New List(Of String)

            ' Match UNC paths: \\server\share
            Dim regex = New Regex("\\\\[^\\]+\\[^\\]+")
            Dim matches = regex.Matches(batchContent)

            For Each match As Match In matches
                paths.Add(match.Value)
            Next

            Return paths.Distinct().ToList()
        End Function

        Public Function ParseStoredProcedures(sqlContent As String) As List(Of String)
            Dim procedures As New List(Of String)
            Dim lines = sqlContent.Split(New String() {Environment.NewLine}, StringSplitOptions.None)
            Dim isInComment = False

            For Each line In lines
                Dim trimmedLine = line.Trim()

                ' Skip empty lines
                If String.IsNullOrWhiteSpace(trimmedLine) Then Continue For

                ' Handle block comments
                If trimmedLine.StartsWith("/*") Then
                    isInComment = True
                    Continue For
                End If
                If trimmedLine.EndsWith("*/") Then
                    isInComment = False
                    Continue For
                End If
                If isInComment Then Continue For

                ' Skip single line comments
                If trimmedLine.StartsWith("--") Then Continue For

                ' Remove inline comments
                Dim commentIndex = trimmedLine.IndexOf("--")
                If commentIndex >= 0 Then
                    trimmedLine = trimmedLine.Substring(0, commentIndex).Trim()
                End If

                ' Extract stored procedure calls
                If trimmedLine.StartsWith("EXEC", StringComparison.OrdinalIgnoreCase) OrElse
           trimmedLine.StartsWith("EXECUTE", StringComparison.OrdinalIgnoreCase) Then
                    Dim spName = ExtractStoredProcedureName(trimmedLine)
                    If Not String.IsNullOrEmpty(spName) Then
                        procedures.Add(spName)
                    End If
                End If
            Next

            Return procedures.Distinct().ToList()
        End Function

        Public Async Function ExecuteExecutableTask(taskAction As TaskAction, credential As CredentialInfo) As Task(Of Boolean)
            Try
                _logger.LogInfo($"Executing Executable task: {taskAction.Name}")

                Dim username As String = credential?.Username
                Dim password As String = If(credential?.SecurePassword IsNot Nothing,
            New NetworkCredential("", credential.SecurePassword).Password,
            String.Empty)

                ' Get the current execution tool path
                Dim executionToolPath = _toolManager.GetCurrentToolPath()
                _logger.LogInfo($"Using execution tool: {_toolManager.CurrentExecutionTool} at path: {executionToolPath}")

                ' Build PsExec arguments with modified syntax
                Dim arguments = "-accepteula -nobanner -i "

                If taskAction.RequiresElevation Then
                    arguments += "-h "
                End If

                ' Handle domain credentials differently
                If Not String.IsNullOrEmpty(username) Then
                    Dim domain As String = ""
                    If username.Contains("\") Then
                        Dim parts = username.Split("\"c)
                        domain = parts(0)
                        username = parts(1)
                        arguments += $"-u {domain}\{username} "
                    Else
                        arguments += $"-u {username} "
                    End If

                    If Not String.IsNullOrEmpty(password) Then
                        arguments += $"-p {password} "
                    End If
                    'Debug line
                    _logger.LogInfo($"Using credentials for user: {If(credential IsNot Nothing, credential.Username, "None")}")
                End If


                ' Add the target executable and its arguments
                arguments += $"""{taskAction.Target}"" {taskAction.Parameters}"

                Using process As New Process()
                    process.StartInfo = New ProcessStartInfo(executionToolPath) With {
                .Arguments = arguments,
                .UseShellExecute = False,
                .RedirectStandardOutput = True,
                .RedirectStandardError = True,
                .CreateNoWindow = True,
                .WorkingDirectory = Path.GetDirectoryName(taskAction.Target)
            }

                    Dim output As New StringBuilder()
                    Dim err As New StringBuilder()

                    AddHandler process.OutputDataReceived, Sub(sender, e)
                                                               If e.Data IsNot Nothing Then
                                                                   output.AppendLine(e.Data)
                                                                   _logger.LogInfo($"Process output: {e.Data}")
                                                               End If
                                                           End Sub

                    AddHandler process.ErrorDataReceived, Sub(sender, e)
                                                              If Not String.IsNullOrWhiteSpace(e.Data) Then
                                                                  If e.Data.Contains("Connecting") OrElse
                      e.Data.Contains("Starting") OrElse
                      e.Data.Contains("Copying") OrElse
                      e.Data.Contains("exited") Then
                                                                      _logger.LogInfo($"Process output: {e.Data}")
                                                                  Else
                                                                      err.AppendLine(e.Data)
                                                                      _logger.LogWarning($"Process error: {e.Data}")
                                                                  End If
                                                              End If
                                                          End Sub

                    process.Start()
                    process.BeginOutputReadLine()
                    process.BeginErrorReadLine()
                    Await process.WaitForExitAsync()

                    If process.ExitCode <> 0 Then
                        _logger.LogError($"Process failed with exit code: {process.ExitCode}")
                        _logger.LogError($"Error output: {err.ToString()}")
                        Return False
                    End If

                    Return True
                End Using

            Catch ex As Exception
                _logger.LogError($"Error in ExecuteExecutableTask: {ex.Message}")
                _logger.LogError($"StackTrace: {ex.StackTrace}")
                Return False
            End Try
        End Function

        Public Function ExtractStoredProcedureName(sqlContent As String) As String
            sqlContent = sqlContent.Trim()

            ' Handle EXEC/EXECUTE with optional schema
            Dim execMatch = Regex.Match(sqlContent, "(?:EXEC(?:UTE)?)\s+(?:@\w+\s*=\s*)?(?:\[?(?:dbo\]?\.)?)?\[?(\w+)\]?", RegexOptions.IgnoreCase)

            If execMatch.Success Then
                Return execMatch.Groups(1).Value
            End If

            Return String.Empty
        End Function

        Private Function ExtractAndRunPsExec(parameters As String) As Process
            'For a furure release - To avoid exposing a sensitive executable on a system

            Dim tempPath = Path.Combine(Path.GetTempPath(), "psexec.exe")

            ' Extract resource to temp file
            'File.WriteAllBytes(tempPath, My.Resources.PsExec)

            ' Run the extracted executable
            Dim proc = New Process()
            proc.StartInfo.FileName = tempPath
            proc.StartInfo.Arguments = parameters
            proc.StartInfo.UseShellExecute = False
            proc.Start()

            ' Clean up temp file when done
            File.Delete(tempPath)
            Return proc
        End Function

        Private Function ExtractSqlInfo(sqlContent As String) As (ServerName As String, DatabaseName As String)
            Try
                ' Look for SQL file comments first
                Dim serverMatch = Regex.Match(sqlContent, "(?i)(?:--\s*|/\*\s*)Server\s*[:=]\s*([^*\r\n]+?)(?:\s*\*/|\r|\n)")
                Dim dbMatch = Regex.Match(sqlContent, "(?i)(?:--\s*|/\*\s*)Database\s*[:=]\s*([^*\r\n]+?)(?:\s*\*/|\r|\n)")

                Dim server = If(serverMatch.Success, serverMatch.Groups(1).Value.Trim(), "")
                Dim database = If(dbMatch.Success, dbMatch.Groups(1).Value.Trim(), "")

                ' Check for USE statement if database not found in comments
                If String.IsNullOrEmpty(database) Then
                    Dim useMatch = Regex.Match(sqlContent, "USE\s+\[?([^\]\s;]+)\]?\s*;?", RegexOptions.IgnoreCase)
                    If useMatch.Success Then
                        database = useMatch.Groups(1).Value
                    End If
                End If

                _logger.LogInfo($"Extracted from SQL file - Server: {If(String.IsNullOrEmpty(server), "Not found", server)}, Database: {If(String.IsNullOrEmpty(database), "Not found", database)}")
                Return (server, database)
            Catch ex As Exception
                _logger.LogInfo($"No information was found in the SQL file or an error occurred: {ex.Message}")
                Return ("", "")
            End Try
        End Function

        Public Function GetConnectionString(credentialTarget As String, Optional parameters As Dictionary(Of String, String) = Nothing, Optional sqlFileContent As String = Nothing) As String
            Try
                Dim builder As New SqlConnectionStringBuilder()
                Dim sqlConfig = _xmlManager.GetSqlConfiguration()
                Dim _sqlTab = ApplicationContainer.GetService(Of SqlTab)()

                ' If executing from SqlTab, use UI values first
                If _sqlTab IsNot Nothing AndAlso _sqlTab.IsExecutingFromSqlTab() Then
                    If Not String.IsNullOrWhiteSpace(_sqlTab._serverTextBox?.Text) Then
                        builder.DataSource = _sqlTab._serverTextBox.Text
                    End If

                    If _sqlTab._databaseComboBox?.SelectedItem IsNot Nothing AndAlso
               _sqlTab._databaseComboBox.SelectedItem.ToString() <> "(Select a database)" Then
                        builder.InitialCatalog = _sqlTab._databaseComboBox.SelectedItem.ToString()
                    End If
                End If

                ' Use parameters if specified
                If parameters IsNot Nothing Then
                    If parameters.ContainsKey("server") AndAlso String.IsNullOrEmpty(builder.DataSource) Then
                        builder.DataSource = parameters("server")
                    End If
                    If parameters.ContainsKey("database") AndAlso String.IsNullOrEmpty(builder.InitialCatalog) Then
                        builder.InitialCatalog = parameters("database")
                    End If
                End If

                ' Finally, use config defaults if still not set
                If String.IsNullOrEmpty(builder.DataSource) Then
                    builder.DataSource = sqlConfig("DefaultServer")
                    If String.IsNullOrEmpty(builder.DataSource) Then
                        Throw New ArgumentException("Server name not specified in UI, parameters, or configuration")
                    End If
                End If

                If String.IsNullOrEmpty(builder.InitialCatalog) Then
                    builder.InitialCatalog = sqlConfig("DefaultDatabase")
                    If String.IsNullOrEmpty(builder.InitialCatalog) Then
                        Throw New ArgumentException("Database not specified in UI, parameters, or configuration")
                    End If
                End If

                ' Handle credentials
                If String.IsNullOrEmpty(credentialTarget) OrElse credentialTarget = "(None)" Then
                    builder.IntegratedSecurity = True
                Else
                    Dim credential = _credentialManager.GetCredential(credentialTarget, "Windows Vault")
                    If credential Is Nothing Then
                        _logger.LogWarning($"Credential not found for {credentialTarget}. Using integrated security")
                        builder.IntegratedSecurity = True
                    Else
                        If credential.Username.Contains("\") Then
                            ' Windows authentication
                            builder.IntegratedSecurity = True
                            _logger.LogInfo($"Using Windows authentication for domain user: {credential.Username}")
                        Else
                            ' SQL authentication
                            builder.IntegratedSecurity = False
                            builder.UserID = credential.Username
                            builder.Password = New NetworkCredential("", credential.SecurePassword).Password
                            _logger.LogInfo($"Using SQL authentication for user: {credential.Username}")
                        End If
                    End If
                End If

                ' Connection settings
                builder.ConnectTimeout = Integer.Parse(sqlConfig("CommandTimeout"))
                builder.ApplicationName = "LiteTask"
                builder.TrustServerCertificate = True
                builder.MultipleActiveResultSets = True
                builder.Encrypt = False

                Dim maskedString = builder.ToString()
                If builder.Password IsNot Nothing AndAlso builder.Password.Length > 0 Then
                    maskedString = maskedString.Replace(builder.Password, "********")
                End If
                _logger.LogInfo($"Built connection string: {maskedString}")

                Return builder.ToString()

            Catch ex As Exception
                _logger?.LogError($"Error building connection string: {ex.Message}")
                Throw
            End Try
        End Function

        Private Function MaskSensitiveData(input As String, password As String) As String
            If String.IsNullOrEmpty(input) OrElse String.IsNullOrEmpty(password) Then Return input
            Return input.Replace(password, "[MASKED]")
        End Function

        Private Sub OnErrorReceived(sender As Object, e As DataAddedEventArgs)
            Dim errorRecord As ErrorRecord = CType(sender, PSDataCollection(Of ErrorRecord))(e.Index)
            _logger.LogError($"PowerShell Error: {errorRecord.Exception.Message}")
        End Sub

        Private Sub OnInformationReceived(sender As Object, e As DataAddedEventArgs)
            Dim informationRecord As InformationRecord = CType(sender, PSDataCollection(Of InformationRecord))(e.Index)
            _logger.LogInfo($"PowerShell Output: {informationRecord.MessageData}")
        End Sub

        Private Function ParseConnectionParameters(parameters As String) As Dictionary(Of String, String)
            Dim result As New Dictionary(Of String, String)

            If String.IsNullOrEmpty(parameters) Then
                ' Default values if no parameters provided
                result("server") = "XCONCENTMDS"
                result("database") = "master"
                Return result
            End If

            For Each param In parameters.Split(" "c)
                Dim parts = param.Split("="c)
                If parts.Length = 2 Then
                    result(parts(0).ToLower()) = parts(1)
                End If
            Next

            Return result
        End Function

        Private Async Function RunProcess(process As Process) As Task(Of Boolean)
            Dim output As New StringBuilder()
            Dim errors As New StringBuilder()

            Try
                AddHandler process.OutputDataReceived, Sub(sender, e)
                                                           If e.Data IsNot Nothing Then
                                                               output.AppendLine(e.Data)
                                                               _logger.LogInfo($"Process output: {e.Data}")
                                                           End If
                                                       End Sub

                AddHandler process.ErrorDataReceived, Sub(sender, e)
                                                          If e.Data IsNot Nothing Then
                                                              errors.AppendLine(e.Data)
                                                              _logger.LogWarning($"Process error: {e.Data}")
                                                          End If
                                                      End Sub

                process.Start()
                process.BeginOutputReadLine()
                process.BeginErrorReadLine()
                Await process.WaitForExitAsync()

                If process.ExitCode <> 0 Then
                    _logger.LogError($"Process failed with exit code: {process.ExitCode}")
                    _logger.LogError($"Error output: {errors.ToString()}")
                    Return False
                End If

                Return True

            Catch ex As Exception
                _logger.LogError($"Error running process: {ex.Message}")
                Return False
            End Try
        End Function

        Public Async Function RunProcessAsync(fileName As String, arguments As String, Optional credential As CredentialInfo = Nothing) As Task(Of String)
            ' TODO: Phase 2 Security Improvements
            ' - Implement process execution whitelist
            ' - Add argument validation and sanitization
            ' - Implement resource usage limits
            ' - Add process isolation
            ' - Implement execution time limits
            Try
                _logger.LogInfo($"Starting process execution: {fileName}")

                ' Get PsExec path
                Dim psExecPath = Path.Combine(_toolManager._toolsPath, "PsExec.exe")

                ' Build PsExec arguments
                Dim psExecArgs = "-h -accepteula -nobanner -i "

                If credential IsNot Nothing Then
                    psExecArgs += $"-u ""{credential.Username}"" -p ""{credential.Password}"" "
                End If

                ' For batch files, wrap in cmd /c
                If fileName.EndsWith(".cmd", StringComparison.OrdinalIgnoreCase) OrElse
           fileName.EndsWith(".bat", StringComparison.OrdinalIgnoreCase) Then
                    psExecArgs += $"cmd.exe /c ""{fileName}"" {arguments}"
                Else
                    psExecArgs += $"""{fileName}"" {arguments}"
                End If

                ' Set up process to run PsExec
                Dim startInfo = New ProcessStartInfo(psExecPath) With {
            .Arguments = psExecArgs,
            .RedirectStandardOutput = True,
            .RedirectStandardError = True,
            .UseShellExecute = False,
            .CreateNoWindow = True,
            .WorkingDirectory = Path.GetDirectoryName(fileName)
        }

                Dim output As New StringBuilder()
                Dim err As New StringBuilder()

                Using process As New Process With {.StartInfo = startInfo}
                    AddHandler process.OutputDataReceived, Sub(sender, e)
                                                               If e.Data IsNot Nothing Then
                                                                   output.AppendLine(e.Data)
                                                                   _logger.LogInfo($"Process output: {e.Data}")
                                                               End If
                                                           End Sub

                    AddHandler process.ErrorDataReceived, Sub(sender, e)
                                                              If e.Data IsNot Nothing Then
                                                                  err.AppendLine(e.Data)
                                                                  _logger.LogWarning($"Process errors: {e.Data}")
                                                              End If
                                                          End Sub

                    process.Start()
                    process.BeginOutputReadLine()
                    process.BeginErrorReadLine()
                    Await process.WaitForExitAsync()

                    If process.ExitCode <> 0 Then
                        _logger.LogError($"Process failed with exit code: {process.ExitCode}")
                        Throw New Exception($"Process exited with code {process.ExitCode}. Error: {err}")
                    End If

                    Return output.ToString()
                End Using

            Catch ex As Exception
                _logger.LogError($"Error in RunProcessAsync: {ex.Message}")
                _logger.LogError($"StackTrace: {ex.StackTrace}")
                Throw
            End Try
        End Function

        Public Async Function RunScriptAsync(scriptPath As String, parameters As Hashtable, Optional useRemoting As Boolean = False, Optional credential As PSCredential = Nothing) As Task(Of Collection(Of PSObject))
            Try
                _logger.LogInfo($"Preparing to run script: {scriptPath}")

                Using powerShell As PowerShell = _powerShellPathManager.CreatePowerShellInstance()
                    powerShell.Runspace = _runspace

                    ' Add initialization script
                    powerShell.AddScript(_powerShellPathManager.CreateInitializationScript())

                    ' Add the actual script
                    If File.Exists(scriptPath) Then
                        powerShell.AddScript(File.ReadAllText(scriptPath))
                    Else
                        powerShell.AddScript(scriptPath)
                    End If

                    For Each param In parameters
                        powerShell.AddParameter(param.Key.ToString(), param.Value)
                    Next

                    If useRemoting Then
                        powerShell.AddCommand("Invoke-Command")
                        If parameters.ContainsKey("ComputerName") Then
                            powerShell.AddParameter("ComputerName", parameters("ComputerName"))
                        End If
                        If credential IsNot Nothing Then
                            powerShell.AddParameter("Credential", credential)
                        End If
                    End If

                    AddHandler powerShell.Streams.Error.DataAdded, AddressOf OnErrorReceived
                    AddHandler powerShell.Streams.Information.DataAdded, AddressOf OnInformationReceived

                    Dim result = Await Task.Run(Function() powerShell.Invoke())

                    If powerShell.HadErrors Then
                        Throw New Exception("PowerShell execution encountered errors. Check the error log for details.")
                    End If

                    Return result
                End Using
            Catch ex As Exception
                _logger.LogError($"Error in RunScriptAsync: {ex.Message}")
                _logger.LogError($"StackTrace: {ex.StackTrace}")
                Throw
            End Try
        End Function

        Private Function SplitSqlCommands(sqlContent As String) As List(Of String)
            Dim commands As New List(Of String)
            Dim currentCommand As New StringBuilder
            Dim isInComment = False

            For Each line In sqlContent.Split(New String() {Environment.NewLine}, StringSplitOptions.None)
                Dim trimmedLine = line.Trim()

                ' Skip empty lines
                If String.IsNullOrWhiteSpace(trimmedLine) Then Continue For

                ' Handle comment blocks
                If trimmedLine.StartsWith("/*") Then isInComment = True
                If trimmedLine.EndsWith("*/") Then
                    isInComment = False
                    Continue For
                End If
                If isInComment Then Continue For

                ' Skip single line comments
                If trimmedLine.StartsWith("--") Then Continue For

                ' Handle GO statements
                If trimmedLine.Equals("GO", StringComparison.OrdinalIgnoreCase) Then
                    If currentCommand.Length > 0 Then
                        commands.Add(currentCommand.ToString().Trim())
                        currentCommand.Clear()
                    End If
                    Continue For
                End If

                currentCommand.AppendLine(line)
            Next

            If currentCommand.Length > 0 Then
                commands.Add(currentCommand.ToString().Trim())
            End If

            Return commands
        End Function

        Public Sub UpdateConnectionString(newConnectionString As String)
            _connectionStringBase = newConnectionString
        End Sub

        Private Sub VerifyRequiredTools()
            ' Check for required tools
            Dim requiredTools = New String() {"PsExec.exe", "OSQL.exe", "osql.rll"}
            Dim missingTools = New List(Of String)

            For Each tool In requiredTools
                Dim toolPath = Path.Combine(_toolManager._toolsPath, tool)
                If Not File.Exists(toolPath) Then
                    missingTools.Add(tool)
                End If
            Next

            If missingTools.Any() Then
                Throw New Exception($"Required tools missing: {String.Join(", ", missingTools)}. Please ensure all required tools are in the tools directory: {_toolManager._toolsPath}")
            End If
        End Sub

    End Class

    Public Class SqlCommandSanitizer
        ' Basic sanitization that won't break existing functionality
        Public Function SanitizeColumnName(columnName As String) As String
            If String.IsNullOrEmpty(columnName) Then Return String.Empty
            Return Regex.Replace(columnName, "[^\w\s\-\[\]]", "")
        End Function

        Public Function SanitizeOutput(output As String) As String
            If String.IsNullOrEmpty(output) Then Return String.Empty
            Return Regex.Replace(output, "[\x00-\x08\x0B\x0C\x0E-\x1F]", "")
        End Function
    End Class

    Public Class SqlExecutionResult
        Public Property Success As Boolean
        Public Property Message As String
        Public Property Data As DataTable
        Public Property RowsAffected As Integer
    End Class

    Public Class SqlFileInfo
        Public Property ServerName As String
        Public Property DatabaseName As String
        Public Property StoredProcedures As List(Of String)
    End Class


End Namespace
